<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="en_GB">
<context>
    <name></name>
    <message>
        <location filename="app.cpp" line="72"/>
        <source>Operate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="74"/>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AboutBox</name>
    <message>
        <location filename="aboutbox.ui" line="13"/>
        <source>About Q Light Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aboutbox.ui" line="54"/>
        <source>Q Light Controller</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aboutbox.ui" line="72"/>
        <source>Version X.X.X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aboutbox.ui" line="88"/>
        <source>This application is licensed under the GNU GPL version 2.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="aboutbox.ui" line="97"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Arial&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:14pt; font-weight:600;&quot;&gt;GNU GENERAL PUBLIC LICENSE&lt;/span&gt;&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:14pt; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:xx-large;&quot;&gt;Version 2, June 1991&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Copyright (C) 1989, 1991 Free Software Foundation, Inc. 675 Mass Ave, Cambridge, MA 02139, USAEveryone is permitted to copy and distribute verbatim copies of this license document, but changing it is not allowed.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:16px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:x-large; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:x-large;&quot;&gt;Preamble&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The licenses for most software are designed to take away your freedom to share and change it.  By contrast, the GNU General Public License is intended to guarantee your freedom to share and change free software--to make sure the software is free for all its users.  This General Public License applies to most of the Free Software Foundation&apos;s software and to any other program whose authors commit tousing it.  (Some other Free Software Foundation software is covered by the GNU Library General Public License instead.)  You can apply it to your programs, too.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;When we speak of free software, we are referring to freedom, not price.  Our General Public Licenses are designed to make sure that you have the freedom to distribute copies of free software (and charge for this service if you wish), that you receive source code or can get it if you want it, that you can change the software or use pieces of it in new free programs; and that you know you can do these things.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;To protect your rights, we need to make restrictions that forbid anyone to deny you these rights or to ask you to surrender the rights. These restrictions translate to certain responsibilities for you if youdistribute copies of the software, or if you modify it.&lt;/p&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For example, if you distribute copies of such a program, whether gratis or for a fee, you must give the recipients all the rights that you have.  You must make sure that they, too, receive or can get thesource code.  And you must show them these terms so they know their rights.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt; We protect your rights with two steps: (1) copyright the software, and (2) offer you this license which gives you legal permission to copy, distribute and/or modify the software.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Also, for each author&apos;s protection and ours, we want to make certain that everyone understands that there is no warranty for this free software.  If the software is modified by someone else and passed on, we want its recipients to know that what they have is not the original, so that any problems introduced by others will not reflect on the original authors&apos; reputations.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Finally, any free program is threatened constantly by software patents.  We wish to avoid the danger that redistributors of a free program will individually obtain patent licenses, in effect making the program proprietary.  To prevent this, we have made it clear that any patent must be licensed for everyone&apos;s free use or not licensed at all.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The precise terms and conditions for copying, distribution and modification follow.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:xx-large; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:xx-large;&quot;&gt;GNU GENERAL PUBLIC LICENSE TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;0. This License applies to any program or other work which containsa notice placed by the copyright holder saying it may be distributedunder the terms of this General Public License.  The &quot;Program&quot;, below,refers to any such program or work, and a &quot;work based on the Program&quot;means either the Program or any derivative work under copyright law:that is to say, a work containing the Program or a portion of it,either verbatim or with modifications and/or translated into anotherlanguage.  (Hereinafter, translation is included without limitation inthe term &quot;modification&quot;.)  Each licensee is addressed as &quot;you&quot;.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Activities other than copying, distribution and modification are notcovered by this License; they are outside its scope.  The act ofrunning the Program is not restricted, and the output from the Programis covered only if its contents constitute a work based on theProgram (independent of having been made by running the Program).Whether that is true depends on what the Program does.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;1. You may copy and distribute verbatim copies of the Program&apos;ssource code as you receive it, in any medium, provided that youconspicuously and appropriately publish on each copy an appropriatecopyright notice and disclaimer of warranty; keep intact all thenotices that refer to this License and to the absence of any warranty;and give any other recipients of the Program a copy of this Licensealong with the Program.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;You may charge a fee for the physical act of transferring a copy, andyou may at your option offer warranty protection in exchange for a fee.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;2. You may modify your copy or copies of the Program or any portionof it, thus forming a work based on the Program, and copy anddistribute such modifications or work under the terms of Section 1above, provided that you also meet all of these conditions:&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) You must cause the modified files to carry prominent notices stating that you changed the files and the date of any change.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) You must cause any work that you distribute or publish, that in whole or in part contains or is derived from the Program or any part thereof, to be licensed as a whole at no charge to all third parties under the terms of this License.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) If the modified program normally reads commands interactively when run, you must cause it, when started running for such interactive use in the most ordinary way, to print or display an announcement including an appropriate copyright notice and a notice that there is no warranty (or else, saying that you provide    a warranty) and that users may redistribute the program under these conditions, and telling the user how to view a copy of this License. (Exception: if the Program itself is interactive but does not normally print such an announcement, your work based on the Program is not required to print an announcement.)&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;These requirements apply to the modified work as a whole.  Ifidentifiable sections of that work are not derived from the Program,and can be reasonably considered independent and separate works inthemselves, then this License, and its terms, do not apply to thosesections when you distribute them as separate works.  But when youdistribute the same sections as part of a whole which is a work basedon the Program, the distribution of the whole must be on the terms ofthis License, whose permissions for other licensees extend to theentire whole, and thus to each and every part regardless of who wrote it.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Thus, it is not the intent of this section to claim rights or contestyour rights to work written entirely by you; rather, the intent is toexercise the right to control the distribution of derivative orcollective works based on the Program.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;In addition, mere aggregation of another work not based on the Programwith the Program (or with a work based on the Program) on a volume ofa storage or distribution medium does not bring the other work underthe scope of this License.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;3. You may copy and distribute the Program (or a work based on it,under Section 2) in object code or executable form under the terms ofSections 1 and 2 above provided that you also do one of the following:&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;a) Accompany it with the complete corresponding machine-readable source code, which must be distributed under the terms of Sections 1 and 2 above on a medium customarily used for software interchange; or, &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;b) Accompany it with a written offer, valid for at least three years, to give any third party, for a charge no more than your cost of physically performing source distribution, a complete machine-readable copy of the corresponding source code, to be distributed under the terms of Sections 1 and 2 above on a medium    customarily used for software interchange; or, &lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;c) Accompany it with the information you received as to the offer to distribute corresponding source code. (This alternative is allowed only for noncommercial distribution and only if you received the program in object code or executable form with such an offer, in accord with Subsection b above.)&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The source code for a work means the preferred form of the work formaking modifications to it.  For an executable work, complete sourcecode means all the source code for all modules it contains, plus anyassociated interface definition files, plus the scripts used tocontrol compilation and installation of the executable.  However, as aspecial exception, the source code distributed need not includeanything that is normally distributed (in either source or binaryform) with the major components (compiler, kernel, and so on) of theoperating system on which the executable runs, unless that componentitself accompanies the executable.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If distribution of executable or object code is made by offeringaccess to copy from a designated place, then offering equivalentaccess to copy the source code from the same place counts asdistribution of the source code, even though third parties are notcompelled to copy the source along with the object code.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;4. You may not copy, modify, sublicense, or distribute the Programexcept as expressly provided under this License.  Any attemptotherwise to copy, modify, sublicense or distribute the Program isvoid, and will automatically terminate your rights under this License.However, parties who have received copies, or rights, from you underthis License will not have their licenses terminated so long as suchparties remain in full compliance.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;5. You are not required to accept this License, since you have notsigned it.  However, nothing else grants you permission to modify ordistribute the Program or its derivative works.  These actions areprohibited by law if you do not accept this License.  Therefore, bymodifying or distributing the Program (or any work based on theProgram), you indicate your acceptance of this License to do so, andall its terms and conditions for copying, distributing or modifyingthe Program or works based on it.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;6. Each time you redistribute the Program (or any work based on theProgram), the recipient automatically receives a license from theoriginal licensor to copy, distribute or modify the Program subject tothese terms and conditions.  You may not impose any furtherrestrictions on the recipients&apos; exercise of the rights granted herein.You are not responsible for enforcing compliance by third parties tothis License.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;7. If, as a consequence of a court judgment or allegation of patentinfringement or for any other reason (not limited to patent issues),conditions are imposed on you (whether by court order, agreement orotherwise) that contradict the conditions of this License, they do notexcuse you from the conditions of this License.  If you cannotdistribute so as to satisfy simultaneously your obligations under thisLicense and any other pertinent obligations, then as a consequence youmay not distribute the Program at all.  For example, if a patentlicense would not permit royalty-free redistribution of the Program byall those who receive copies directly or indirectly through you, thenthe only way you could satisfy both it and this License would be torefrain entirely from distribution of the Program.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;If any portion of this section is held invalid or unenforceable underany particular circumstance, the balance of the section is intended toapply and the section as a whole is intended to apply in othercircumstances.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;It is not the purpose of this section to induce you to infringe anypatents or other property right claims or to contest validity of anysuch claims; this section has the sole purpose of protecting theintegrity of the free software distribution system, which isimplemented by public license practices.  Many people have madegenerous contributions to the wide range of software distributedthrough that system in reliance on consistent application of thatsystem; it is up to the author/donor to decide if he or she is willingto distribute software through any other system and a licensee cannotimpose that choice.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;This section is intended to make thoroughly clear what is believed tobe a consequence of the rest of this License.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;8. If the distribution and/or use of the Program is restricted incertain countries either by patents or by copyrighted interfaces, theoriginal copyright holder who places the Program under this Licensemay add an explicit geographical distribution limitation excludingthose countries, so that distribution is permitted only in or amongcountries not thus excluded.  In such case, this License incorporatesthe limitation as if written in the body of this License.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;9. The Free Software Foundation may publish revised and/or new versionsof the General Public License from time to time.  Such new versions willbe similar in spirit to the present version, but may differ in detail toaddress new problems or concerns.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Each version is given a distinguishing version number.  If the Programspecifies a version number of this License which applies to it and &quot;anylater version&quot;, you have the option of following the terms and conditionseither of that version or of any later version published by the FreeSoftware Foundation.  If the Program does not specify a version number ofthis License, you may choose any version ever published by the Free SoftwareFoundation.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;10. If you wish to incorporate parts of the Program into other freeprograms whose distribution conditions are different, write to the authorto ask for permission.  For software which is copyrighted by the FreeSoftware Foundation, write to the Free Software Foundation; we sometimesmake exceptions for this.  Our decision will be guided by the two goalsof preserving the free status of all derivatives of our free software andof promoting the sharing and reuse of software generally.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:xx-large; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:xx-large;&quot;&gt;NO WARRANTY&lt;/span&gt;&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTYFOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHENOTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIESPROVIDE THE PROGRAM &quot;AS IS&quot; WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSEDOR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OFMERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK ASTO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THEPROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,REPAIR OR CORRECTION.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITINGWILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/ORREDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISINGOUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITEDTO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BYYOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHERPROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THEPOSSIBILITY OF SUCH DAMAGES.&lt;/p&gt;
&lt;p align=&quot;center&quot; style=&quot; margin-top:18px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px; font-size:xx-large; font-weight:600;&quot;&gt;&lt;span style=&quot; font-size:xx-large;&quot;&gt;END OF TERMS AND CONDITIONS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AddFixture</name>
    <message>
        <location filename="addfixture.ui" line="13"/>
        <source>Add fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="26"/>
        <source>Fixture Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="31"/>
        <source>Fixture Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="39"/>
        <source>Fixture Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="45"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="58"/>
        <source>A friendly name for the new fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="65"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="78"/>
        <source>Selected fixture mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="85"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="98"/>
        <source>The starting address of the (first) added fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="111"/>
        <source>Universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="124"/>
        <source>The universe thru which the added fixtures are controlled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="137"/>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="153"/>
        <source>Number of channels in the selected fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="169"/>
        <source>List of channels in the selected fixture mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="185"/>
        <source>Multiple Fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="191"/>
        <source>Amount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="204"/>
        <source>Number of fixtures to add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="217"/>
        <source>Address gap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="addfixture.ui" line="230"/>
        <source>Number of empty channels to leave between added fixtures</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>App</name>
    <message>
        <location filename="app.cpp" line="974"/>
        <source>%1 - New Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="356"/>
        <source>Output Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="400"/>
        <source>Input Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="753"/>
        <source>Design</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="560"/>
        <source>Switch to design mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="595"/>
        <source>Switch to Design Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="598"/>
        <source>There are still running functions.
Really stop them and switch back to Design mode?</source>
        <translation>There are still running functions.
Are you sure you want to stop them and switch to Design mode?</translation>
    </message>
    <message>
        <location filename="app.cpp" line="767"/>
        <source>Operate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="768"/>
        <source>Switch to operate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="701"/>
        <source>New</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="706"/>
        <source>Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="711"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="716"/>
        <source>Save As...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="721"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="727"/>
        <source>Fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="732"/>
        <source>Functions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="737"/>
        <source>Buses</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="742"/>
        <source>Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="747"/>
        <source>Outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="774"/>
        <source>Virtual Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="779"/>
        <source>Monitor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="784"/>
        <source>Toggle Blackout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="790"/>
        <source>Panic!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="796"/>
        <source>Index</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="801"/>
        <source>About QLC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="806"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="827"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="839"/>
        <source>Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="850"/>
        <source>Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="855"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="871"/>
        <source>Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="892"/>
        <source>Blackout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="902"/>
        <source>Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="993"/>
        <source>Do you wish to save the current workspace?
Otherwise you will lose changes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1006"/>
        <source>Open Workspace</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1034"/>
        <source>Unable to open file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1035"/>
        <source>Workspace file might be corrupt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1064"/>
        <source>Save Workspace As</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1119"/>
        <source>Fixture Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1182"/>
        <source>Bus Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1307"/>
        <source>Set background image...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1310"/>
        <source>Clear background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1344"/>
        <source>Open an image file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="app.cpp" line="1345"/>
        <source>Images (*.png *.xpm *.jpg *.gif)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AssignHotKey</name>
    <message>
        <location filename="assignhotkey.ui" line="13"/>
        <source>Assign a key combination to button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="assignhotkey.ui" line="22"/>
        <source>Key combination</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BusManager</name>
    <message>
        <location filename="busmanager.cpp" line="60"/>
        <source>Bus Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busmanager.cpp" line="61"/>
        <source>Edit bus name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busmanager.cpp" line="74"/>
        <source>Bus ID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busmanager.cpp" line="74"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busmanager.cpp" line="94"/>
        <source>Bus #%1 name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="busmanager.cpp" line="95"/>
        <source>Rename bus</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ChaserEditor</name>
    <message>
        <location filename="chasereditor.cpp" line="77"/>
        <source>Chaser editor - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.cpp" line="160"/>
        <source>Chaser editor - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="13"/>
        <source>Chaser editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="21"/>
        <source>Chaser name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="28"/>
        <source>Name of the chaser being edited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="49"/>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="54"/>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="64"/>
        <source>Add step(s) to the current position</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="127"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="84"/>
        <source>Remove the selected step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="104"/>
        <source>Raise the selected step once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="124"/>
        <source>Lower the selected step once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="163"/>
        <source>Run Order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="169"/>
        <source>Run through over and over again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="172"/>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="182"/>
        <source>Run through once and stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="185"/>
        <source>Single Shot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="192"/>
        <source>First run forwards, then backwards, again forwards, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="195"/>
        <source>Ping Pong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="205"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="211"/>
        <source>Start from the first step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="214"/>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="224"/>
        <source>Start from the last step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="chasereditor.ui" line="227"/>
        <source>Backward</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CollectionEditor</name>
    <message>
        <location filename="collectioneditor.ui" line="13"/>
        <source>Collection editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="21"/>
        <source>Collection name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="28"/>
        <source>Name of the function being edited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="52"/>
        <source>Fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="57"/>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="62"/>
        <source>Function Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="72"/>
        <source>Add function(s) to the collection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="collectioneditor.ui" line="92"/>
        <source>Remove the selected function</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConsoleChannel</name>
    <message>
        <location filename="consolechannel.cpp" line="141"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DummyOutPlugin</name>
    <message>
        <location filename="dummyoutplugin.cpp" line="84"/>
        <source>Dummy output configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="dummyoutplugin.cpp" line="85"/>
        <source>This plugin has no configurable options</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>EFXEditor</name>
    <message>
        <location filename="efxeditor.cpp" line="361"/>
        <source>EFX Editor - %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.cpp" line="415"/>
        <source>Remove fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.cpp" line="416"/>
        <source>Do you want to remove the selected fixture(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="13"/>
        <source>EFX Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="26"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="34"/>
        <source>EFX name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="41"/>
        <source>The name of the function being edited</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="63"/>
        <source>Step</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="68"/>
        <source>Fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="73"/>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="134"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="168"/>
        <source>Fixture order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="174"/>
        <source>All fixtures move in parallel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="177"/>
        <source>Parallel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="187"/>
        <source>The pattern propagates to each fixture in a sequential order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="190"/>
        <source>Serial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="200"/>
        <source>Speed bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="206"/>
        <source>Bus that controls the speed of the pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="219"/>
        <source>Movement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="257"/>
        <source>Direction</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="263"/>
        <source>Run the pattern forwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="266"/>
        <source>Forward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="276"/>
        <source>Run the pattern backwards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="279"/>
        <source>Backward</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="302"/>
        <source>Run order</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="308"/>
        <source>Run through over and over again</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="311"/>
        <source>Loop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="321"/>
        <source>Run through once and stop</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="324"/>
        <source>Single shot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="331"/>
        <source>First run forwards, then backwards, again forwards, etc...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="334"/>
        <source>Ping pong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="363"/>
        <source>Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="369"/>
        <source>Pattern for moving the mirror/head</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="379"/>
        <source>Parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="385"/>
        <source>Width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="392"/>
        <source>Value width of the pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="405"/>
        <source>Height</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="412"/>
        <source>Value height of the pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="425"/>
        <source>X offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="432"/>
        <source>Pattern&apos;s center point on the X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="445"/>
        <source>Y offset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="452"/>
        <source>Pattern&apos;s center point on the Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="465"/>
        <source>Rotation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="472"/>
        <source>Rotation of the pattern&apos;s starting point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="498"/>
        <source>X frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="508"/>
        <source>Lissajous pattern&apos;s X frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="524"/>
        <source>Y frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="534"/>
        <source>Lissajous pattern&apos;s Y frequency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="550"/>
        <source>X phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="560"/>
        <source>Lissajous pattern&apos;s X phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="576"/>
        <source>Y phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="586"/>
        <source>Lissajous pattern&apos;s Y phase</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="605"/>
        <source>Initialization</source>
        <translation>Initialisation</translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="611"/>
        <source>Initialize the fixture with the given scene values when the EFX starts</source>
        <translation>Initialise the fixture with the given scene values when the EFX starts</translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="614"/>
        <source>Initialize fixtures</source>
        <translation>Initialise fixtures</translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="678"/>
        <source>Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="650"/>
        <source>De-initialize the fixture with the given scene values when the EFX stops</source>
        <translation>De-initialise the fixture with the given scene values when the EFX stops</translation>
    </message>
    <message>
        <location filename="efxeditor.ui" line="653"/>
        <source>De-initialize fixtures</source>
        <translation>De-initialise fixtures</translation>
    </message>
</context>
<context>
    <name>FixtureList</name>
    <message>
        <location filename="fixturelist.ui" line="13"/>
        <source>Dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturelist.ui" line="20"/>
        <source>Fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturelist.ui" line="25"/>
        <source>Channel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FixtureManager</name>
    <message>
        <location filename="fixturemanager.cpp" line="225"/>
        <source>Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturemanager.cpp" line="338"/>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturemanager.cpp" line="372"/>
        <source>Add fixture...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturemanager.cpp" line="377"/>
        <source>Remove fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturemanager.cpp" line="382"/>
        <source>Configure fixture...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixturemanager.cpp" line="389"/>
        <source>Fixture manager</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FixtureProperties</name>
    <message>
        <location filename="fixtureproperties.cpp" line="87"/>
        <source>Fixture properties - </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.cpp" line="93"/>
        <source>Change fixture definition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="13"/>
        <source>Fixture properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="19"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="26"/>
        <source>Fixture&apos;s friendly name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="33"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="40"/>
        <source>Fixture&apos;s DMX address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="47"/>
        <source>Universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="54"/>
        <source>The universe that the fixture is controlled through</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="61"/>
        <source>Make &amp; Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureproperties.ui" line="75"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FixtureSelection</name>
    <message>
        <location filename="fixtureselection.cpp" line="72"/>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureselection.ui" line="13"/>
        <source>Select fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureselection.ui" line="38"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureselection.ui" line="43"/>
        <source>Manufacturer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="fixtureselection.ui" line="48"/>
        <source>Model</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FunctionManager</name>
    <message>
        <location filename="functionmanager.cpp" line="94"/>
        <source>New scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="99"/>
        <source>New chaser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="104"/>
        <source>New collection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="614"/>
        <source>New EFX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="114"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="120"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="125"/>
        <source>Clone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="130"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="135"/>
        <source>Select all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="148"/>
        <source>Manage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="587"/>
        <source>New Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="596"/>
        <source>New Chaser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionmanager.cpp" line="605"/>
        <source>New Collection</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FunctionSelection</name>
    <message>
        <location filename="functionselection.ui" line="13"/>
        <source>Select Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="35"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="40"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="48"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="54"/>
        <source>Scenes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="61"/>
        <source>Chasers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="68"/>
        <source>EFX&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="functionselection.ui" line="75"/>
        <source>Collections</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputChannelEditor</name>
    <message>
        <location filename="inputchanneleditor.ui" line="13"/>
        <source>Input Channel Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputchanneleditor.ui" line="19"/>
        <source>Input Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputchanneleditor.ui" line="25"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputchanneleditor.ui" line="32"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputchanneleditor.ui" line="39"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputDeviceEditor</name>
    <message>
        <location filename="inputdeviceeditor.cpp" line="80"/>
        <source>File not writable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="84"/>
        <source>You do not have permission to write to the file %1. You might not be able to save your modifications to the device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="159"/>
        <source>Missing information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="160"/>
        <source>Manufacturer and/or model name is missing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="286"/>
        <source>Channel already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="288"/>
        <source>Channel %1 already exists</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="214"/>
        <source>Delete channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="216"/>
        <source>Delete all %1 selected channels?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="327"/>
        <source>Channel wizard activated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="329"/>
        <source>You have enabled the input channel wizard. After </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="330"/>
        <source>clicking OK, wiggle your mapped input device&apos;s </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="331"/>
        <source>controls. They should appear into the list. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="332"/>
        <source>Click the wizard button again to stop channel </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="333"/>
        <source>auto-detection.

Note that the wizard cannot </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="334"/>
        <source>tell the difference between a knob and a slider </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="334"/>
        <source>so you will have to do the change manually.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="381"/>
        <source>Button %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.cpp" line="412"/>
        <source>Slider %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="13"/>
        <source>Input Device Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="23"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="29"/>
        <source>Manufacturer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="36"/>
        <source>The name of the company that made the device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="46"/>
        <source>Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="53"/>
        <source>The device&apos;s model name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="74"/>
        <source>Channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="99"/>
        <source>Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="104"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="109"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="117"/>
        <source>Add a new channel description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="180"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="137"/>
        <source>Remove the selected channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="157"/>
        <source>Edit the selected channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputdeviceeditor.ui" line="177"/>
        <source>Automatically add channels to the list when you wiggle the device&apos;s controls</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputManager</name>
    <message>
        <location filename="inputmanager.cpp" line="103"/>
        <source>Input Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="104"/>
        <source>Edit Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="116"/>
        <source>Universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="117"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="118"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="119"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="119"/>
        <source>Editor universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmanager.cpp" line="132"/>
        <source>%1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputMap</name>
    <message>
        <location filename="inputmap.cpp" line="287"/>
        <source>Unable to configure plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmap.cpp" line="289"/>
        <source>Plugin &quot;%1&quot; not found!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputmap.cpp" line="306"/>
        <source>No information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>InputPatchEditor</name>
    <message>
        <location filename="inputpatcheditor.cpp" line="64"/>
        <source>Mapping properties for input universe %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="222"/>
        <source>No information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="655"/>
        <source>Saving failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="500"/>
        <source>Unable to save the device to %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="536"/>
        <source>Delete device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="538"/>
        <source>Do you wish to permanently delete device &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="565"/>
        <source>File deletion failed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="567"/>
        <source>Unable to delete file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.cpp" line="657"/>
        <source>Unable to save %1 to %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="13"/>
        <source>Input patch editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="23"/>
        <source>Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="30"/>
        <source>Inputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="44"/>
        <source>Input Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="164"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="113"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="121"/>
        <source>Create a new input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="141"/>
        <source>Delete the selected input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="161"/>
        <source>Edit the selected input device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="208"/>
        <source>Use this universe for e.g. scene channel value setting in scene editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="inputpatcheditor.ui" line="211"/>
        <source>Default editor universe</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Monitor</name>
    <message>
        <location filename="monitor.cpp" line="133"/>
        <source>Display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="monitor.cpp" line="134"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="monitor.cpp" line="149"/>
        <source>Relative to fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="monitor.cpp" line="171"/>
        <source>Absolute DMX</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="monitor.cpp" line="177"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputManager</name>
    <message>
        <location filename="outputmanager.cpp" line="76"/>
        <source>Output Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmanager.cpp" line="77"/>
        <source>Edit Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmanager.cpp" line="89"/>
        <source>Universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmanager.cpp" line="90"/>
        <source>Plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmanager.cpp" line="90"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputMap</name>
    <message>
        <location filename="outputmap.cpp" line="320"/>
        <source>Unable to configure plugin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmap.cpp" line="321"/>
        <source>%1 not found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputmap.cpp" line="337"/>
        <source>No information</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>OutputPatchEditor</name>
    <message>
        <location filename="outputpatcheditor.cpp" line="48"/>
        <source>Mapping properties for output universe %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.cpp" line="159"/>
        <source>No information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="13"/>
        <source>Output patch editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="25"/>
        <source>Mapping</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="35"/>
        <source>Plugins/Outputs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="46"/>
        <source>Output Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="52"/>
        <source>Information related to the currently selected plugin or output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="62"/>
        <source>Configure the selected plugin/output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="outputpatcheditor.ui" line="65"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="outputmap.h" line="45"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SceneEditor</name>
    <message>
        <location filename="sceneeditor.cpp" line="89"/>
        <source>Fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="91"/>
        <source>Add fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="492"/>
        <source>Remove fixtures</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="97"/>
        <source>Enable all channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="99"/>
        <source>Disable all channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="105"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="106"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="108"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="111"/>
        <source>Copy to all</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="114"/>
        <source>Enable channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="117"/>
        <source>Disable channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="122"/>
        <source>Color tool</source>
        <translation type="unfinished">Colour tool</translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="375"/>
        <source>Colour components not found</source>
        <translation type="unfinished">Colour components not found</translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="377"/>
        <source>Unable to find channels for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="378"/>
        <source>CMY or RGB colour components </source>
        <translation type="unfinished">CMY or RGB colour components</translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="378"/>
        <source>from current fixture.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="435"/>
        <source>Generic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.cpp" line="493"/>
        <source>Do you want to remove the selected fixture(s)?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="13"/>
        <source>Scene editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="23"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="29"/>
        <source>Scene name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="36"/>
        <source>Name of this scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="62"/>
        <source>Fixtures used in this scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="72"/>
        <source>Add a new fixture to this scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="95"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="sceneeditor.ui" line="92"/>
        <source>Remove the selected fixture(s) from this scene</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SelectInputChannel</name>
    <message>
        <location filename="selectinputchannel.cpp" line="145"/>
        <source>&lt;Double click here to enter channel number manually&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectinputchannel.ui" line="13"/>
        <source>Select input channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="selectinputchannel.ui" line="23"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCButton</name>
    <message>
        <location filename="vcbutton.cpp" line="233"/>
        <source>Select button icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbutton.cpp" line="234"/>
        <source>Images (*.png *.xpm *.jpg *.gif)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbutton.cpp" line="626"/>
        <source>Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbutton.cpp" line="627"/>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbutton.cpp" line="629"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbutton.cpp" line="637"/>
        <source>Set function...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCButtonProperties</name>
    <message>
        <location filename="vcbuttonproperties.cpp" line="189"/>
        <source>%1: Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.cpp" line="203"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="13"/>
        <source>Button properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="19"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="25"/>
        <source>Button label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="32"/>
        <source>Text to display on the button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="39"/>
        <source>Function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="46"/>
        <source>The function that this button controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="56"/>
        <source>Attach a function to this button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="145"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="76"/>
        <source>Detach the button&apos;s function attachment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="99"/>
        <source>Keyboard hotkey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="105"/>
        <source>Key combination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="112"/>
        <source>Keyboard combination that toggles this button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="122"/>
        <source>Set a key combination for this button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="142"/>
        <source>Remove the button&apos;s keyboard shortcut key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="165"/>
        <source>External Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="171"/>
        <source>Input Universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="178"/>
        <source>The input universe that sends data to this widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="188"/>
        <source>Input Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="195"/>
        <source>The particular input channel within the input universe that sends data to this widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="224"/>
        <source>Choose the external input universe &amp; channel that this widget should listen to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="227"/>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="237"/>
        <source>On button press...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="243"/>
        <source>Toggle the assigned function on/off with this button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="246"/>
        <source>Toggle function on/off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="256"/>
        <source>Flash the assigned function with this button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="259"/>
        <source>Flash function</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="269"/>
        <source>Panic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="275"/>
        <source>Stop all running functions when this button is clicked</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcbuttonproperties.ui" line="278"/>
        <source>Stop all running functions</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCCueList</name>
    <message>
        <location filename="vccuelist.cpp" line="67"/>
        <source>Cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelist.cpp" line="182"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCCueListProperties</name>
    <message>
        <location filename="vccuelistproperties.cpp" line="210"/>
        <source>No key binding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="13"/>
        <source>Cue list properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="21"/>
        <source>Cue list name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="28"/>
        <source>The name of the cue list widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="39"/>
        <source>List of scenes that can be activated with this cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="61"/>
        <source>Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="66"/>
        <source>Scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="76"/>
        <source>Add scene(s) to the cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="212"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="96"/>
        <source>Remove selected scene(s) from the cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="116"/>
        <source>Raise the selected scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="136"/>
        <source>Lower the selected scene</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="173"/>
        <source>Next cue key combination</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="179"/>
        <source>The key combination used to step to the next cue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="189"/>
        <source>Bind a key combination to skip to the next cue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vccuelistproperties.ui" line="209"/>
        <source>Clear the key binding</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCDockSlider</name>
    <message>
        <location filename="vcdockslider.ui" line="25"/>
        <source>0.00s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCFrame</name>
    <message>
        <location filename="vcframe.cpp" line="306"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframe.cpp" line="308"/>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframe.cpp" line="310"/>
        <source>XY pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframe.cpp" line="313"/>
        <source>Cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframe.cpp" line="316"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframe.cpp" line="318"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCFrameProperties</name>
    <message>
        <location filename="vcframeproperties.ui" line="13"/>
        <source>Frame properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframeproperties.ui" line="19"/>
        <source>Button behaviour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframeproperties.ui" line="25"/>
        <source>Toggle independently</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcframeproperties.ui" line="32"/>
        <source>One button at a time</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCSliderProperties</name>
    <message>
        <location filename="vcsliderproperties.cpp" line="257"/>
        <source>%1: Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.cpp" line="271"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="13"/>
        <source>Slider properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="26"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="34"/>
        <source>Slider name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="41"/>
        <source>Name of the slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="50"/>
        <source>Operating mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="56"/>
        <source>Use this slider to control a bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="297"/>
        <source>Bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="69"/>
        <source>Use this slider to control the level of selected channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="323"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="472"/>
        <source>Submaster</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="92"/>
        <source>Value display style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="98"/>
        <source>Show exact DMX values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="101"/>
        <source>DMX / Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="111"/>
        <source>Show value as percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="114"/>
        <source>Percentage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="124"/>
        <source>Slider movement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="130"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="140"/>
        <source>Inverted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="150"/>
        <source>External Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="156"/>
        <source>Input universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="163"/>
        <source>The input universe that sends data to this widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="173"/>
        <source>Input channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="180"/>
        <source>The particular input channel within the input universe that sends data to this widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="203"/>
        <source>Choose the external input universe &amp; channel that this widget should listen to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="206"/>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="329"/>
        <source>Value range</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="335"/>
        <source>Low limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="255"/>
        <source>The lowest value that can be set with this slider for a bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="278"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="352"/>
        <source>High limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="275"/>
        <source>The highest value that can be set with this slider for a bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="342"/>
        <source>Lowest DMX value that can be se with this slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="359"/>
        <source>Highest DMX value that can be set with this slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="388"/>
        <source>Set value range from the selected capability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="391"/>
        <source>From capability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="416"/>
        <source>Select all channels</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="419"/>
        <source>All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="426"/>
        <source>Unselect everything</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="429"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="436"/>
        <source>Invert selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="439"/>
        <source>Invert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="459"/>
        <source>Choose channels by channel group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="462"/>
        <source>By group...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcsliderproperties.ui" line="478"/>
        <source>Not implemented yet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCWidget</name>
    <message>
        <location filename="vcwidget.cpp" line="142"/>
        <source>Select background image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcwidget.cpp" line="291"/>
        <source>Rename widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcwidget.cpp" line="292"/>
        <source>Set widget caption:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcwidget.cpp" line="371"/>
        <source>This widget has no properties</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCXYPadProperties</name>
    <message>
        <location filename="vcxypadproperties.ui" line="13"/>
        <source>XY Pad Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="19"/>
        <source>Horizontal axis (X)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="172"/>
        <source>Fixture</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="177"/>
        <source>Channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="182"/>
        <source>Min</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="187"/>
        <source>Max</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="299"/>
        <source>Reverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="56"/>
        <source>Add a channel to this pad&apos;s X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="225"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="76"/>
        <source>Remove the selected channel from this pad&apos;s X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="259"/>
        <source>Minimum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="120"/>
        <source>Lowest value for the selected channel on the X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="276"/>
        <source>Maximum value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="137"/>
        <source>Highest value for the selected channel on the X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="150"/>
        <source>Reverse the selected channel&apos;s X axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="165"/>
        <source>Vertical axis (Y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="202"/>
        <source>Add a channel to this pad&apos;s Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="222"/>
        <source>Remove the selected channel from this pad&apos;s Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="266"/>
        <source>Lowest value for the selected channel on the Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="283"/>
        <source>Highest value for the selected channel on the Y axis</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcxypadproperties.ui" line="296"/>
        <source>Reverse the selected channel&apos;s Y axis</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VirtualConsole</name>
    <message>
        <location filename="virtualconsole.cpp" line="78"/>
        <source>Virtual Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="105"/>
        <source>Button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="110"/>
        <source>Slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="115"/>
        <source>XY pad</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="120"/>
        <source>Cue list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="125"/>
        <source>Frame</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="130"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="136"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="141"/>
        <source>Default sliders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="146"/>
        <source>Stop ALL functions!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="152"/>
        <source>Cut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="157"/>
        <source>Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="162"/>
        <source>Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="167"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="172"/>
        <source>Properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="177"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="199"/>
        <source>Color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="188"/>
        <source>Font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="204"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="210"/>
        <source>Raise</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="215"/>
        <source>Lower</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="234"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="247"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="260"/>
        <source>Tools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="269"/>
        <source>Foreground</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="277"/>
        <source>Background</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="virtualconsole.cpp" line="284"/>
        <source>Stacking order</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VCPropertiesEditor</name>
    <message>
        <location filename="vcproperties.cpp" line="300"/>
        <source>%1: Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.cpp" line="316"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="13"/>
        <source>Virtual Console properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="23"/>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="29"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="35"/>
        <source>Make virtual console to take exclusive keyboard control during operate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="38"/>
        <source>Grab keyboard in operate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="45"/>
        <source>Prevent flickering when a keyboard hotkey has been pressed in operate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="48"/>
        <source>Turn off key repeat in operate mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="58"/>
        <source>Use a grid layout for virtual console widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="61"/>
        <source>Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="70"/>
        <source>Horizontal (X)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="77"/>
        <source>Widget grid layout X resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="103"/>
        <source>px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="93"/>
        <source>Vertical (Y)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="100"/>
        <source>Widget grid layout Y resolution</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="146"/>
        <source>Default sliders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="152"/>
        <source>Default fade slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="268"/>
        <source>Low limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="165"/>
        <source>Lowest value that can be set to the &apos;fade&apos; bus with the default sliders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="298"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="288"/>
        <source>High limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="185"/>
        <source>Highest value that can be set to the &apos;fade&apos; bus with the default sliders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="321"/>
        <source>Input universe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="335"/>
        <source>Input channel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="362"/>
        <source>Choose...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="262"/>
        <source>Default hold slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="275"/>
        <source>Lowest value that can be set to the &apos;hold&apos; bus with the default sliders</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="vcproperties.ui" line="295"/>
        <source>Highest value that can be set to the &apos;hold&apos; bus with the default sliders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
