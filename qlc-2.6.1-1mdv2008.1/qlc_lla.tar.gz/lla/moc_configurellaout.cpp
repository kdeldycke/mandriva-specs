/****************************************************************************
** ConfigureLlaOut meta object code from reading C++ file 'configurellaout.h'
**
** Created: Sun Jan 7 20:18:57 2007
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "configurellaout.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *ConfigureLlaOut::className() const
{
    return "ConfigureLlaOut";
}

QMetaObject *ConfigureLlaOut::metaObj = 0;
static QMetaObjectCleanUp cleanUp_ConfigureLlaOut( "ConfigureLlaOut", &ConfigureLlaOut::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString ConfigureLlaOut::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ConfigureLlaOut", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString ConfigureLlaOut::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ConfigureLlaOut", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* ConfigureLlaOut::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_ConfigureLlaOut::staticMetaObject();
    static const QUMethod slot_0 = {"slotActivateClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotActivateClicked()", &slot_0, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"ConfigureLlaOut", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_ConfigureLlaOut.setMetaObject( metaObj );
    return metaObj;
}

void* ConfigureLlaOut::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "ConfigureLlaOut" ) )
	return this;
    return UI_ConfigureLlaOut::qt_cast( clname );
}

bool ConfigureLlaOut::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotActivateClicked(); break;
    default:
	return UI_ConfigureLlaOut::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool ConfigureLlaOut::qt_emit( int _id, QUObject* _o )
{
    return UI_ConfigureLlaOut::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool ConfigureLlaOut::qt_property( int id, int f, QVariant* v)
{
    return UI_ConfigureLlaOut::qt_property( id, f, v);
}

bool ConfigureLlaOut::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
