/****************************************************************************
** Form implementation generated from reading ui file 'src/editpresetvalue.ui'
**
** Created: Thu Nov 30 00:54:18 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_editpresetvalue.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qframe.h>
#include <qlabel.h>
#include <qspinbox.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_EditPresetValue as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_EditPresetValue::UI_EditPresetValue( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_EditPresetValue" );
    UI_EditPresetValueLayout = new QGridLayout( this, 1, 1, 11, 6, "UI_EditPresetValueLayout"); 

    m_cancelButton = new QPushButton( this, "m_cancelButton" );

    UI_EditPresetValueLayout->addWidget( m_cancelButton, 1, 1 );

    m_okButton = new QPushButton( this, "m_okButton" );
    m_okButton->setDefault( TRUE );

    UI_EditPresetValueLayout->addWidget( m_okButton, 1, 0 );

    m_valueFrame = new QFrame( this, "m_valueFrame" );
    m_valueFrame->setFrameShape( QFrame::StyledPanel );
    m_valueFrame->setFrameShadow( QFrame::Raised );
    m_valueFrameLayout = new QGridLayout( m_valueFrame, 1, 1, 11, 6, "m_valueFrameLayout"); 

    m_maxLabel = new QLabel( m_valueFrame, "m_maxLabel" );

    m_valueFrameLayout->addWidget( m_maxLabel, 0, 1 );

    m_minLabel = new QLabel( m_valueFrame, "m_minLabel" );

    m_valueFrameLayout->addWidget( m_minLabel, 0, 0 );

    m_minSpin = new QSpinBox( m_valueFrame, "m_minSpin" );
    m_minSpin->setMaxValue( 255 );

    m_valueFrameLayout->addWidget( m_minSpin, 1, 0 );

    m_descriptionEdit = new QLineEdit( m_valueFrame, "m_descriptionEdit" );

    m_valueFrameLayout->addWidget( m_descriptionEdit, 1, 2 );

    m_maxSpin = new QSpinBox( m_valueFrame, "m_maxSpin" );
    m_maxSpin->setMaxValue( 255 );

    m_valueFrameLayout->addWidget( m_maxSpin, 1, 1 );

    m_descriptionLabel = new QLabel( m_valueFrame, "m_descriptionLabel" );

    m_valueFrameLayout->addWidget( m_descriptionLabel, 0, 2 );

    UI_EditPresetValueLayout->addMultiCellWidget( m_valueFrame, 0, 0, 0, 1 );
    languageChange();
    resize( QSize(507, 126).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_okButton, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_cancelButton, SIGNAL( clicked() ), this, SLOT( reject() ) );

    // tab order
    setTabOrder( m_minSpin, m_maxSpin );
    setTabOrder( m_maxSpin, m_descriptionEdit );
    setTabOrder( m_descriptionEdit, m_okButton );
    setTabOrder( m_okButton, m_cancelButton );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_EditPresetValue::~UI_EditPresetValue()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_EditPresetValue::languageChange()
{
    setCaption( tr( "Add / Edit Preset Value" ) );
    m_cancelButton->setText( tr( "Cancel" ) );
    m_okButton->setText( tr( "OK" ) );
    m_maxLabel->setText( tr( "Max" ) );
    m_minLabel->setText( tr( "Min" ) );
    m_descriptionLabel->setText( tr( "Description" ) );
}

