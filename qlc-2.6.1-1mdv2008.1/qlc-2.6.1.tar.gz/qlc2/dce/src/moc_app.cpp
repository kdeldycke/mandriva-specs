/****************************************************************************
** App meta object code from reading C++ file 'app.h'
**
** Created: Thu Nov 30 00:54:29 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "app.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *App::className() const
{
    return "App";
}

QMetaObject *App::metaObj = 0;
static QMetaObjectCleanUp cleanUp_App( "App", &App::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString App::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "App", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString App::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "App", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* App::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QMainWindow::staticMetaObject();
    static const QUMethod slot_0 = {"slotEmpty", 0, 0 };
    static const QUMethod slot_1 = {"slotFileNew", 0, 0 };
    static const QUMethod slot_2 = {"slotFileOpen", 0, 0 };
    static const QUMethod slot_3 = {"slotFileSave", 0, 0 };
    static const QUMethod slot_4 = {"slotFileSaveAs", 0, 0 };
    static const QUMethod slot_5 = {"slotFileQuit", 0, 0 };
    static const QUMethod slot_6 = {"slotWindowCascade", 0, 0 };
    static const QUMethod slot_7 = {"slotWindowTile", 0, 0 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotEditMenuActivated", 1, param_slot_8 };
    static const QUMethod slot_9 = {"slotRefreshEditMenu", 0, 0 };
    static const QUMethod slot_10 = {"slotRefreshWindowMenu", 0, 0 };
    static const QUMethod slot_11 = {"slotHelpIndex", 0, 0 };
    static const QUMethod slot_12 = {"slotDocumentBrowserClosed", 0, 0 };
    static const QUMethod slot_13 = {"slotHelpAbout", 0, 0 };
    static const QUMethod slot_14 = {"slotHelpAboutQt", 0, 0 };
    static const QUParameter param_slot_15[] = {
	{ "editor", &static_QUType_ptr, "DeviceClassEditor", QUParameter::In }
    };
    static const QUMethod slot_15 = {"slotEditorClosed", 1, param_slot_15 };
    static const QUParameter param_slot_16[] = {
	{ "item", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_16 = {"slotWindowMenuCallback", 1, param_slot_16 };
    static const QMetaData slot_tbl[] = {
	{ "slotEmpty()", &slot_0, QMetaData::Private },
	{ "slotFileNew()", &slot_1, QMetaData::Private },
	{ "slotFileOpen()", &slot_2, QMetaData::Private },
	{ "slotFileSave()", &slot_3, QMetaData::Private },
	{ "slotFileSaveAs()", &slot_4, QMetaData::Private },
	{ "slotFileQuit()", &slot_5, QMetaData::Private },
	{ "slotWindowCascade()", &slot_6, QMetaData::Private },
	{ "slotWindowTile()", &slot_7, QMetaData::Private },
	{ "slotEditMenuActivated(int)", &slot_8, QMetaData::Private },
	{ "slotRefreshEditMenu()", &slot_9, QMetaData::Private },
	{ "slotRefreshWindowMenu()", &slot_10, QMetaData::Private },
	{ "slotHelpIndex()", &slot_11, QMetaData::Private },
	{ "slotDocumentBrowserClosed()", &slot_12, QMetaData::Private },
	{ "slotHelpAbout()", &slot_13, QMetaData::Private },
	{ "slotHelpAboutQt()", &slot_14, QMetaData::Private },
	{ "slotEditorClosed(DeviceClassEditor*)", &slot_15, QMetaData::Private },
	{ "slotWindowMenuCallback(int)", &slot_16, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"App", parentObject,
	slot_tbl, 17,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_App.setMetaObject( metaObj );
    return metaObj;
}

void* App::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "App" ) )
	return this;
    return QMainWindow::qt_cast( clname );
}

bool App::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotEmpty(); break;
    case 1: slotFileNew(); break;
    case 2: slotFileOpen(); break;
    case 3: slotFileSave(); break;
    case 4: slotFileSaveAs(); break;
    case 5: slotFileQuit(); break;
    case 6: slotWindowCascade(); break;
    case 7: slotWindowTile(); break;
    case 8: slotEditMenuActivated((int)static_QUType_int.get(_o+1)); break;
    case 9: slotRefreshEditMenu(); break;
    case 10: slotRefreshWindowMenu(); break;
    case 11: slotHelpIndex(); break;
    case 12: slotDocumentBrowserClosed(); break;
    case 13: slotHelpAbout(); break;
    case 14: slotHelpAboutQt(); break;
    case 15: slotEditorClosed((DeviceClassEditor*)static_QUType_ptr.get(_o+1)); break;
    case 16: slotWindowMenuCallback((int)static_QUType_int.get(_o+1)); break;
    default:
	return QMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool App::qt_emit( int _id, QUObject* _o )
{
    return QMainWindow::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool App::qt_property( int id, int f, QVariant* v)
{
    return QMainWindow::qt_property( id, f, v);
}

bool App::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
