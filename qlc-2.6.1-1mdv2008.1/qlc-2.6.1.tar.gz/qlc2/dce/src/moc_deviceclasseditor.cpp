/****************************************************************************
** DeviceClassEditor meta object code from reading C++ file 'deviceclasseditor.h'
**
** Created: Thu Nov 30 00:54:30 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "deviceclasseditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DeviceClassEditor::className() const
{
    return "DeviceClassEditor";
}

QMetaObject *DeviceClassEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DeviceClassEditor( "DeviceClassEditor", &DeviceClassEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DeviceClassEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceClassEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DeviceClassEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceClassEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DeviceClassEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_DeviceClassEditor::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotManufacturerEditTextChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotModelEditTextChanged", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotTypeSelected", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotChannelListSelectionChanged", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotPresetListSelectionChanged", 1, param_slot_4 };
    static const QUMethod slot_5 = {"slotAddChannelClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotRemoveChannelClicked", 0, 0 };
    static const QUMethod slot_7 = {"slotEditChannelClicked", 0, 0 };
    static const QUMethod slot_8 = {"slotRaiseChannelClicked", 0, 0 };
    static const QUMethod slot_9 = {"slotLowerChannelClicked", 0, 0 };
    static const QUMethod slot_10 = {"slotAddPresetClicked", 0, 0 };
    static const QUMethod slot_11 = {"slotRemovePresetClicked", 0, 0 };
    static const QUMethod slot_12 = {"slotEditPresetClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotManufacturerEditTextChanged(const QString&)", &slot_0, QMetaData::Public },
	{ "slotModelEditTextChanged(const QString&)", &slot_1, QMetaData::Public },
	{ "slotTypeSelected(const QString&)", &slot_2, QMetaData::Public },
	{ "slotChannelListSelectionChanged(QListViewItem*)", &slot_3, QMetaData::Public },
	{ "slotPresetListSelectionChanged(QListViewItem*)", &slot_4, QMetaData::Public },
	{ "slotAddChannelClicked()", &slot_5, QMetaData::Public },
	{ "slotRemoveChannelClicked()", &slot_6, QMetaData::Public },
	{ "slotEditChannelClicked()", &slot_7, QMetaData::Public },
	{ "slotRaiseChannelClicked()", &slot_8, QMetaData::Public },
	{ "slotLowerChannelClicked()", &slot_9, QMetaData::Public },
	{ "slotAddPresetClicked()", &slot_10, QMetaData::Public },
	{ "slotRemovePresetClicked()", &slot_11, QMetaData::Public },
	{ "slotEditPresetClicked()", &slot_12, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ 0, &static_QUType_ptr, "DeviceClassEditor", QUParameter::In }
    };
    static const QUMethod signal_0 = {"closed", 1, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "closed(DeviceClassEditor*)", &signal_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"DeviceClassEditor", parentObject,
	slot_tbl, 13,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DeviceClassEditor.setMetaObject( metaObj );
    return metaObj;
}

void* DeviceClassEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DeviceClassEditor" ) )
	return this;
    return UI_DeviceClassEditor::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL closed
void DeviceClassEditor::closed( DeviceClassEditor* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

bool DeviceClassEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotManufacturerEditTextChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: slotModelEditTextChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 2: slotTypeSelected((const QString&)static_QUType_QString.get(_o+1)); break;
    case 3: slotChannelListSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 4: slotPresetListSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 5: slotAddChannelClicked(); break;
    case 6: slotRemoveChannelClicked(); break;
    case 7: slotEditChannelClicked(); break;
    case 8: slotRaiseChannelClicked(); break;
    case 9: slotLowerChannelClicked(); break;
    case 10: slotAddPresetClicked(); break;
    case 11: slotRemovePresetClicked(); break;
    case 12: slotEditPresetClicked(); break;
    default:
	return UI_DeviceClassEditor::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DeviceClassEditor::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed((DeviceClassEditor*)static_QUType_ptr.get(_o+1)); break;
    default:
	return UI_DeviceClassEditor::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool DeviceClassEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_DeviceClassEditor::qt_property( id, f, v);
}

bool DeviceClassEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
