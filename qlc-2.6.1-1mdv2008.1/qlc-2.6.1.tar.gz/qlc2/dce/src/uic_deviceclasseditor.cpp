/****************************************************************************
** Form implementation generated from reading ui file 'src/deviceclasseditor.ui'
**
** Created: Thu Nov 30 00:54:16 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_deviceclasseditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qtoolbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_DeviceClassEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
UI_DeviceClassEditor::UI_DeviceClassEditor( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "UI_DeviceClassEditor" );
    UI_DeviceClassEditorLayout = new QVBoxLayout( this, 11, 6, "UI_DeviceClassEditorLayout"); 

    groupBox1 = new QGroupBox( this, "groupBox1" );
    groupBox1->setColumnLayout(0, Qt::Vertical );
    groupBox1->layout()->setSpacing( 6 );
    groupBox1->layout()->setMargin( 11 );
    groupBox1Layout = new QVBoxLayout( groupBox1->layout() );
    groupBox1Layout->setAlignment( Qt::AlignTop );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 

    textLabel1 = new QLabel( groupBox1, "textLabel1" );
    textLabel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel1->sizePolicy().hasHeightForWidth() ) );
    textLabel1->setMinimumSize( QSize( 100, 0 ) );
    textLabel1->setMaximumSize( QSize( 100, 32767 ) );
    layout6->addWidget( textLabel1 );

    m_manufacturerEdit = new QLineEdit( groupBox1, "m_manufacturerEdit" );
    m_manufacturerEdit->setMinimumSize( QSize( 150, 0 ) );
    layout6->addWidget( m_manufacturerEdit );
    groupBox1Layout->addLayout( layout6 );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    textLabel2 = new QLabel( groupBox1, "textLabel2" );
    textLabel2->setMinimumSize( QSize( 100, 0 ) );
    textLabel2->setMaximumSize( QSize( 100, 32767 ) );
    layout8->addWidget( textLabel2 );

    m_modelEdit = new QLineEdit( groupBox1, "m_modelEdit" );
    m_modelEdit->setMinimumSize( QSize( 150, 0 ) );
    layout8->addWidget( m_modelEdit );
    groupBox1Layout->addLayout( layout8 );

    layout5 = new QHBoxLayout( 0, 0, 6, "layout5"); 

    textLabel1_2 = new QLabel( groupBox1, "textLabel1_2" );
    textLabel1_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)5, 0, 0, textLabel1_2->sizePolicy().hasHeightForWidth() ) );
    textLabel1_2->setMinimumSize( QSize( 100, 0 ) );
    textLabel1_2->setMaximumSize( QSize( 100, 32767 ) );
    layout5->addWidget( textLabel1_2 );

    m_typeCombo = new QComboBox( FALSE, groupBox1, "m_typeCombo" );
    m_typeCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_typeCombo->sizePolicy().hasHeightForWidth() ) );
    m_typeCombo->setSizeLimit( 15 );
    layout5->addWidget( m_typeCombo );
    groupBox1Layout->addLayout( layout5 );
    UI_DeviceClassEditorLayout->addWidget( groupBox1 );

    groupBox2 = new QGroupBox( this, "groupBox2" );
    groupBox2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, groupBox2->sizePolicy().hasHeightForWidth() ) );
    groupBox2->setMinimumSize( QSize( 0, 190 ) );
    groupBox2->setMaximumSize( QSize( 32767, 190 ) );
    groupBox2->setColumnLayout(0, Qt::Vertical );
    groupBox2->layout()->setSpacing( 6 );
    groupBox2->layout()->setMargin( 11 );
    groupBox2Layout = new QHBoxLayout( groupBox2->layout() );
    groupBox2Layout->setAlignment( Qt::AlignTop );

    m_channelList = new QListView( groupBox2, "m_channelList" );
    m_channelList->addColumn( tr( "Number" ) );
    m_channelList->addColumn( tr( "Description" ) );
    m_channelList->setAllColumnsShowFocus( TRUE );
    m_channelList->setResizeMode( QListView::LastColumn );
    groupBox2Layout->addWidget( m_channelList );

    layout6_2 = new QVBoxLayout( 0, 0, 6, "layout6_2"); 

    m_addChannelButton = new QToolButton( groupBox2, "m_addChannelButton" );
    m_addChannelButton->setMinimumSize( QSize( 30, 25 ) );
    layout6_2->addWidget( m_addChannelButton );

    m_removeChannelButton = new QToolButton( groupBox2, "m_removeChannelButton" );
    m_removeChannelButton->setMinimumSize( QSize( 30, 25 ) );
    layout6_2->addWidget( m_removeChannelButton );

    m_editChannelButton = new QToolButton( groupBox2, "m_editChannelButton" );
    m_editChannelButton->setMinimumSize( QSize( 30, 25 ) );
    layout6_2->addWidget( m_editChannelButton );

    m_raiseChannelButton = new QToolButton( groupBox2, "m_raiseChannelButton" );
    m_raiseChannelButton->setMinimumSize( QSize( 30, 25 ) );
    layout6_2->addWidget( m_raiseChannelButton );

    m_lowerChannelButton = new QToolButton( groupBox2, "m_lowerChannelButton" );
    m_lowerChannelButton->setMinimumSize( QSize( 30, 25 ) );
    layout6_2->addWidget( m_lowerChannelButton );
    groupBox2Layout->addLayout( layout6_2 );
    UI_DeviceClassEditorLayout->addWidget( groupBox2 );

    groupBox3 = new QGroupBox( this, "groupBox3" );
    groupBox3->setColumnLayout(0, Qt::Vertical );
    groupBox3->layout()->setSpacing( 6 );
    groupBox3->layout()->setMargin( 11 );
    groupBox3Layout = new QHBoxLayout( groupBox3->layout() );
    groupBox3Layout->setAlignment( Qt::AlignTop );

    m_presetList = new QListView( groupBox3, "m_presetList" );
    m_presetList->addColumn( tr( "Minimum Value" ) );
    m_presetList->addColumn( tr( "Maximum Value" ) );
    m_presetList->addColumn( tr( "Description" ) );
    m_presetList->setAllColumnsShowFocus( TRUE );
    m_presetList->setResizeMode( QListView::LastColumn );
    groupBox3Layout->addWidget( m_presetList );

    layout4 = new QVBoxLayout( 0, 0, 6, "layout4"); 

    m_addPresetButton = new QToolButton( groupBox3, "m_addPresetButton" );
    m_addPresetButton->setMinimumSize( QSize( 30, 25 ) );
    layout4->addWidget( m_addPresetButton );

    m_removePresetButton = new QToolButton( groupBox3, "m_removePresetButton" );
    m_removePresetButton->setMinimumSize( QSize( 30, 25 ) );
    layout4->addWidget( m_removePresetButton );

    m_editPresetButton = new QToolButton( groupBox3, "m_editPresetButton" );
    m_editPresetButton->setMinimumSize( QSize( 30, 25 ) );
    layout4->addWidget( m_editPresetButton );
    spacer3 = new QSpacerItem( 30, 124, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout4->addItem( spacer3 );
    groupBox3Layout->addLayout( layout4 );
    UI_DeviceClassEditorLayout->addWidget( groupBox3 );
    languageChange();
    resize( QSize(466, 595).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_manufacturerEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( slotManufacturerEditTextChanged(const QString&) ) );
    connect( m_modelEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( slotModelEditTextChanged(const QString&) ) );
    connect( m_typeCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotTypeSelected(const QString&) ) );
    connect( m_channelList, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotChannelListSelectionChanged(QListViewItem*) ) );
    connect( m_presetList, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotPresetListSelectionChanged(QListViewItem*) ) );
    connect( m_addChannelButton, SIGNAL( clicked() ), this, SLOT( slotAddChannelClicked() ) );
    connect( m_removeChannelButton, SIGNAL( clicked() ), this, SLOT( slotRemoveChannelClicked() ) );
    connect( m_editChannelButton, SIGNAL( clicked() ), this, SLOT( slotEditChannelClicked() ) );
    connect( m_raiseChannelButton, SIGNAL( clicked() ), this, SLOT( slotRaiseChannelClicked() ) );
    connect( m_lowerChannelButton, SIGNAL( clicked() ), this, SLOT( slotLowerChannelClicked() ) );
    connect( m_addPresetButton, SIGNAL( clicked() ), this, SLOT( slotAddPresetClicked() ) );
    connect( m_removePresetButton, SIGNAL( clicked() ), this, SLOT( slotRemovePresetClicked() ) );
    connect( m_editPresetButton, SIGNAL( clicked() ), this, SLOT( slotEditPresetClicked() ) );
    connect( m_presetList, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotEditPresetClicked() ) );
    connect( m_channelList, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotEditChannelClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_DeviceClassEditor::~UI_DeviceClassEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_DeviceClassEditor::languageChange()
{
    setCaption( tr( "UI_DeviceClassEditor" ) );
    groupBox1->setTitle( tr( "General Information" ) );
    textLabel1->setText( tr( "Manufacturer" ) );
    QToolTip::add( m_manufacturerEdit, tr( "Manufacturer of this device class (e.g. FooLight Ltd.)" ) );
    textLabel2->setText( tr( "Model" ) );
    QToolTip::add( m_modelEdit, tr( "Model of this device class (e.g. HyperZapper 2000)" ) );
    textLabel1_2->setText( tr( "Type" ) );
    m_typeCombo->clear();
    m_typeCombo->insertItem( tr( "Color Changer" ) );
    m_typeCombo->insertItem( tr( "Dimmer" ) );
    m_typeCombo->insertItem( tr( "Effect" ) );
    m_typeCombo->insertItem( tr( "Fan" ) );
    m_typeCombo->insertItem( tr( "Flower" ) );
    m_typeCombo->insertItem( tr( "Haze" ) );
    m_typeCombo->insertItem( tr( "Laser" ) );
    m_typeCombo->insertItem( tr( "Moving Head" ) );
    m_typeCombo->insertItem( tr( "Other" ) );
    m_typeCombo->insertItem( tr( "Scanner" ) );
    m_typeCombo->insertItem( tr( "Smoke" ) );
    m_typeCombo->insertItem( tr( "Strobe" ) );
    QToolTip::add( m_typeCombo, tr( "Type of this device class" ) );
    groupBox2->setTitle( tr( "Channels" ) );
    m_channelList->header()->setLabel( 0, tr( "Number" ) );
    m_channelList->header()->setLabel( 1, tr( "Description" ) );
    m_addChannelButton->setText( QString::null );
    QToolTip::add( m_addChannelButton, tr( "Add a new channel" ) );
    m_removeChannelButton->setText( QString::null );
    QToolTip::add( m_removeChannelButton, tr( "Remove the selected channel" ) );
    m_editChannelButton->setText( QString::null );
    QToolTip::add( m_editChannelButton, tr( "Edit the selected channel's name" ) );
    m_raiseChannelButton->setText( QString::null );
    QToolTip::add( m_raiseChannelButton, tr( "Raise the selected channel up by one" ) );
    m_lowerChannelButton->setText( QString::null );
    QToolTip::add( m_lowerChannelButton, tr( "Lower the selected channel down by one" ) );
    groupBox3->setTitle( tr( "Channel Capabilities" ) );
    m_presetList->header()->setLabel( 0, tr( "Minimum Value" ) );
    m_presetList->header()->setLabel( 1, tr( "Maximum Value" ) );
    m_presetList->header()->setLabel( 2, tr( "Description" ) );
    m_addPresetButton->setText( QString::null );
    QToolTip::add( m_addPresetButton, tr( "Add a new capability to the selected channel" ) );
    m_removePresetButton->setText( QString::null );
    QToolTip::add( m_removePresetButton, tr( "Remove the selected capability from the selected channel" ) );
    m_editPresetButton->setText( QString::null );
    QToolTip::add( m_editPresetButton, tr( "Edit the selected capability" ) );
}

void UI_DeviceClassEditor::slotManufacturerEditTextChanged(const QString&)
{
    qWarning( "UI_DeviceClassEditor::slotManufacturerEditTextChanged(const QString&): Not implemented yet" );
}

void UI_DeviceClassEditor::slotModelEditTextChanged(const QString&)
{
    qWarning( "UI_DeviceClassEditor::slotModelEditTextChanged(const QString&): Not implemented yet" );
}

void UI_DeviceClassEditor::slotTypeSelected(const QString&)
{
    qWarning( "UI_DeviceClassEditor::slotTypeSelected(const QString&): Not implemented yet" );
}

void UI_DeviceClassEditor::slotChannelListSelectionChanged(QListViewItem*)
{
    qWarning( "UI_DeviceClassEditor::slotChannelListSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_DeviceClassEditor::slotPresetListSelectionChanged(QListViewItem*)
{
    qWarning( "UI_DeviceClassEditor::slotPresetListSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_DeviceClassEditor::slotAddChannelClicked()
{
    qWarning( "UI_DeviceClassEditor::slotAddChannelClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotRemoveChannelClicked()
{
    qWarning( "UI_DeviceClassEditor::slotRemoveChannelClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotEditChannelClicked()
{
    qWarning( "UI_DeviceClassEditor::slotEditChannelClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotRaiseChannelClicked()
{
    qWarning( "UI_DeviceClassEditor::slotRaiseChannelClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotLowerChannelClicked()
{
    qWarning( "UI_DeviceClassEditor::slotLowerChannelClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotAddPresetClicked()
{
    qWarning( "UI_DeviceClassEditor::slotAddPresetClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotRemovePresetClicked()
{
    qWarning( "UI_DeviceClassEditor::slotRemovePresetClicked(): Not implemented yet" );
}

void UI_DeviceClassEditor::slotEditPresetClicked()
{
    qWarning( "UI_DeviceClassEditor::slotEditPresetClicked(): Not implemented yet" );
}

