/****************************************************************************
** Form interface generated from reading ui file 'src/editpresetvalue.ui'
**
** Created: Thu Nov 30 00:54:18 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_EDITPRESETVALUE_H
#define UI_EDITPRESETVALUE_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QPushButton;
class QFrame;
class QLabel;
class QSpinBox;
class QLineEdit;

class UI_EditPresetValue : public QDialog
{
    Q_OBJECT

public:
    UI_EditPresetValue( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_EditPresetValue();

    QPushButton* m_cancelButton;
    QPushButton* m_okButton;
    QFrame* m_valueFrame;
    QLabel* m_maxLabel;
    QLabel* m_minLabel;
    QSpinBox* m_minSpin;
    QLineEdit* m_descriptionEdit;
    QSpinBox* m_maxSpin;
    QLabel* m_descriptionLabel;

protected:
    QGridLayout* UI_EditPresetValueLayout;
    QGridLayout* m_valueFrameLayout;

protected slots:
    virtual void languageChange();

};

#endif // UI_EDITPRESETVALUE_H
