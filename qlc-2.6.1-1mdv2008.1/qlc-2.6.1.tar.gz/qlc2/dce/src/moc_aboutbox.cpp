/****************************************************************************
** AboutBox meta object code from reading C++ file 'aboutbox.h'
**
** Created: Thu Nov 30 00:54:29 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "aboutbox.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *AboutBox::className() const
{
    return "AboutBox";
}

QMetaObject *AboutBox::metaObj = 0;
static QMetaObjectCleanUp cleanUp_AboutBox( "AboutBox", &AboutBox::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString AboutBox::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "AboutBox", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString AboutBox::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "AboutBox", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* AboutBox::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"slotOKClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotOKClicked()", &slot_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"AboutBox", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_AboutBox.setMetaObject( metaObj );
    return metaObj;
}

void* AboutBox::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "AboutBox" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool AboutBox::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotOKClicked(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool AboutBox::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool AboutBox::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool AboutBox::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
