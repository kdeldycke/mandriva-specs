/****************************************************************************
** Form interface generated from reading ui file 'src/deviceclasseditor.ui'
**
** Created: Thu Nov 30 00:54:16 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_DEVICECLASSEDITOR_H
#define UI_DEVICECLASSEDITOR_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLabel;
class QLineEdit;
class QComboBox;
class QListView;
class QListViewItem;
class QToolButton;

class UI_DeviceClassEditor : public QWidget
{
    Q_OBJECT

public:
    UI_DeviceClassEditor( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~UI_DeviceClassEditor();

    QGroupBox* groupBox1;
    QLabel* textLabel1;
    QLineEdit* m_manufacturerEdit;
    QLabel* textLabel2;
    QLineEdit* m_modelEdit;
    QLabel* textLabel1_2;
    QComboBox* m_typeCombo;
    QGroupBox* groupBox2;
    QListView* m_channelList;
    QToolButton* m_addChannelButton;
    QToolButton* m_removeChannelButton;
    QToolButton* m_editChannelButton;
    QToolButton* m_raiseChannelButton;
    QToolButton* m_lowerChannelButton;
    QGroupBox* groupBox3;
    QListView* m_presetList;
    QToolButton* m_addPresetButton;
    QToolButton* m_removePresetButton;
    QToolButton* m_editPresetButton;

public slots:
    virtual void slotManufacturerEditTextChanged(const QString &);
    virtual void slotModelEditTextChanged(const QString &);
    virtual void slotTypeSelected(const QString &);
    virtual void slotChannelListSelectionChanged(QListViewItem*);
    virtual void slotPresetListSelectionChanged(QListViewItem*);
    virtual void slotAddChannelClicked();
    virtual void slotRemoveChannelClicked();
    virtual void slotEditChannelClicked();
    virtual void slotRaiseChannelClicked();
    virtual void slotLowerChannelClicked();
    virtual void slotAddPresetClicked();
    virtual void slotRemovePresetClicked();
    virtual void slotEditPresetClicked();

protected:
    QVBoxLayout* UI_DeviceClassEditorLayout;
    QVBoxLayout* groupBox1Layout;
    QHBoxLayout* layout6;
    QHBoxLayout* layout8;
    QHBoxLayout* layout5;
    QHBoxLayout* groupBox2Layout;
    QVBoxLayout* layout6_2;
    QHBoxLayout* groupBox3Layout;
    QVBoxLayout* layout4;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // UI_DEVICECLASSEDITOR_H
