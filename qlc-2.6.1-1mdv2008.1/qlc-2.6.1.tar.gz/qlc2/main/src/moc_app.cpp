/****************************************************************************
** App meta object code from reading C++ file 'app.h'
**
** Created: Thu Nov 30 00:57:22 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "app.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *App::className() const
{
    return "App";
}

QMetaObject *App::metaObj = 0;
static QMetaObjectCleanUp cleanUp_App( "App", &App::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString App::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "App", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString App::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "App", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* App::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QMainWindow::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "name", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotChangeInputPlugin", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "name", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotChangeOutputPlugin", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ "plugin", &static_QUType_ptr, "Plugin", QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotPluginActivated", 1, param_slot_2 };
    static const QUMethod slot_3 = {"slotFlashBlackOutIndicator", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::Out }
    };
    static const QUMethod slot_4 = {"slotFileNew", 1, param_slot_4 };
    static const QUMethod slot_5 = {"slotFileOpen", 0, 0 };
    static const QUMethod slot_6 = {"slotFileSave", 0, 0 };
    static const QUMethod slot_7 = {"slotFileSaveAs", 0, 0 };
    static const QUMethod slot_8 = {"slotFileSettings", 0, 0 };
    static const QUMethod slot_9 = {"slotFilePlugins", 0, 0 };
    static const QUMethod slot_10 = {"slotPluginManagerClosed", 0, 0 };
    static const QUMethod slot_11 = {"slotFileQuit", 0, 0 };
    static const QUMethod slot_12 = {"slotViewDeviceManager", 0, 0 };
    static const QUMethod slot_13 = {"slotDeviceManagerViewClosed", 0, 0 };
    static const QUMethod slot_14 = {"slotViewVirtualConsole", 0, 0 };
    static const QUMethod slot_15 = {"slotVirtualConsoleClosed", 0, 0 };
    static const QUMethod slot_16 = {"slotViewFunctionManager", 0, 0 };
    static const QUMethod slot_17 = {"slotFunctionManagerClosed", 0, 0 };
    static const QUMethod slot_18 = {"slotViewBusProperties", 0, 0 };
    static const QUMethod slot_19 = {"slotBusPropertiesClosed", 0, 0 };
    static const QUMethod slot_20 = {"slotViewMonitor", 0, 0 };
    static const QUMethod slot_21 = {"slotMonitorClosed", 0, 0 };
    static const QUMethod slot_22 = {"slotWindowCascade", 0, 0 };
    static const QUMethod slot_23 = {"slotWindowTile", 0, 0 };
    static const QUMethod slot_24 = {"slotHelpIndex", 0, 0 };
    static const QUMethod slot_25 = {"slotDocumentBrowserClosed", 0, 0 };
    static const QUMethod slot_26 = {"slotHelpAbout", 0, 0 };
    static const QUMethod slot_27 = {"slotHelpAboutQt", 0, 0 };
    static const QUMethod slot_28 = {"slotHelpTooltips", 0, 0 };
    static const QUMethod slot_29 = {"slotPanic", 0, 0 };
    static const QUMethod slot_30 = {"slotSetDesignMode", 0, 0 };
    static const QUMethod slot_31 = {"slotSetOperateMode", 0, 0 };
    static const QUMethod slot_32 = {"slotSetMode", 0, 0 };
    static const QUMethod slot_33 = {"slotToggleBlackOut", 0, 0 };
    static const QUParameter param_slot_34[] = {
	{ "item", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_34 = {"slotWindowMenuCallback", 1, param_slot_34 };
    static const QUMethod slot_35 = {"slotRefreshMenus", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotChangeInputPlugin(const QString&)", &slot_0, QMetaData::Private },
	{ "slotChangeOutputPlugin(const QString&)", &slot_1, QMetaData::Private },
	{ "slotPluginActivated(Plugin*)", &slot_2, QMetaData::Private },
	{ "slotFlashBlackOutIndicator()", &slot_3, QMetaData::Private },
	{ "slotFileNew()", &slot_4, QMetaData::Public },
	{ "slotFileOpen()", &slot_5, QMetaData::Public },
	{ "slotFileSave()", &slot_6, QMetaData::Public },
	{ "slotFileSaveAs()", &slot_7, QMetaData::Public },
	{ "slotFileSettings()", &slot_8, QMetaData::Public },
	{ "slotFilePlugins()", &slot_9, QMetaData::Public },
	{ "slotPluginManagerClosed()", &slot_10, QMetaData::Public },
	{ "slotFileQuit()", &slot_11, QMetaData::Public },
	{ "slotViewDeviceManager()", &slot_12, QMetaData::Public },
	{ "slotDeviceManagerViewClosed()", &slot_13, QMetaData::Public },
	{ "slotViewVirtualConsole()", &slot_14, QMetaData::Public },
	{ "slotVirtualConsoleClosed()", &slot_15, QMetaData::Public },
	{ "slotViewFunctionManager()", &slot_16, QMetaData::Public },
	{ "slotFunctionManagerClosed()", &slot_17, QMetaData::Public },
	{ "slotViewBusProperties()", &slot_18, QMetaData::Public },
	{ "slotBusPropertiesClosed()", &slot_19, QMetaData::Public },
	{ "slotViewMonitor()", &slot_20, QMetaData::Public },
	{ "slotMonitorClosed()", &slot_21, QMetaData::Public },
	{ "slotWindowCascade()", &slot_22, QMetaData::Public },
	{ "slotWindowTile()", &slot_23, QMetaData::Public },
	{ "slotHelpIndex()", &slot_24, QMetaData::Public },
	{ "slotDocumentBrowserClosed()", &slot_25, QMetaData::Public },
	{ "slotHelpAbout()", &slot_26, QMetaData::Public },
	{ "slotHelpAboutQt()", &slot_27, QMetaData::Public },
	{ "slotHelpTooltips()", &slot_28, QMetaData::Public },
	{ "slotPanic()", &slot_29, QMetaData::Public },
	{ "slotSetDesignMode()", &slot_30, QMetaData::Public },
	{ "slotSetOperateMode()", &slot_31, QMetaData::Public },
	{ "slotSetMode()", &slot_32, QMetaData::Public },
	{ "slotToggleBlackOut()", &slot_33, QMetaData::Public },
	{ "slotWindowMenuCallback(int)", &slot_34, QMetaData::Private },
	{ "slotRefreshMenus()", &slot_35, QMetaData::Private }
    };
    static const QUMethod signal_0 = {"modeChanged", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "modeChanged()", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"App", parentObject,
	slot_tbl, 36,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_App.setMetaObject( metaObj );
    return metaObj;
}

void* App::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "App" ) )
	return this;
    return QMainWindow::qt_cast( clname );
}

// SIGNAL modeChanged
void App::modeChanged()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool App::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotChangeInputPlugin((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: slotChangeOutputPlugin((const QString&)static_QUType_QString.get(_o+1)); break;
    case 2: slotPluginActivated((Plugin*)static_QUType_ptr.get(_o+1)); break;
    case 3: slotFlashBlackOutIndicator(); break;
    case 4: static_QUType_bool.set(_o,slotFileNew()); break;
    case 5: slotFileOpen(); break;
    case 6: slotFileSave(); break;
    case 7: slotFileSaveAs(); break;
    case 8: slotFileSettings(); break;
    case 9: slotFilePlugins(); break;
    case 10: slotPluginManagerClosed(); break;
    case 11: slotFileQuit(); break;
    case 12: slotViewDeviceManager(); break;
    case 13: slotDeviceManagerViewClosed(); break;
    case 14: slotViewVirtualConsole(); break;
    case 15: slotVirtualConsoleClosed(); break;
    case 16: slotViewFunctionManager(); break;
    case 17: slotFunctionManagerClosed(); break;
    case 18: slotViewBusProperties(); break;
    case 19: slotBusPropertiesClosed(); break;
    case 20: slotViewMonitor(); break;
    case 21: slotMonitorClosed(); break;
    case 22: slotWindowCascade(); break;
    case 23: slotWindowTile(); break;
    case 24: slotHelpIndex(); break;
    case 25: slotDocumentBrowserClosed(); break;
    case 26: slotHelpAbout(); break;
    case 27: slotHelpAboutQt(); break;
    case 28: slotHelpTooltips(); break;
    case 29: slotPanic(); break;
    case 30: slotSetDesignMode(); break;
    case 31: slotSetOperateMode(); break;
    case 32: slotSetMode(); break;
    case 33: slotToggleBlackOut(); break;
    case 34: slotWindowMenuCallback((int)static_QUType_int.get(_o+1)); break;
    case 35: slotRefreshMenus(); break;
    default:
	return QMainWindow::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool App::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: modeChanged(); break;
    default:
	return QMainWindow::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool App::qt_property( int id, int f, QVariant* v)
{
    return QMainWindow::qt_property( id, f, v);
}

bool App::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
