/****************************************************************************
** Form implementation generated from reading ui file 'src/vcframeproperties.ui'
**
** Created: Thu Nov 30 00:55:13 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_vcframeproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VCFrameProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_VCFrameProperties::UI_VCFrameProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_VCFrameProperties" );
    UI_VCFramePropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_VCFramePropertiesLayout"); 

    m_behaviourGroup = new QButtonGroup( this, "m_behaviourGroup" );
    m_behaviourGroup->setEnabled( TRUE );
    m_behaviourGroup->setColumnLayout(0, Qt::Vertical );
    m_behaviourGroup->layout()->setSpacing( 6 );
    m_behaviourGroup->layout()->setMargin( 11 );
    m_behaviourGroupLayout = new QVBoxLayout( m_behaviourGroup->layout() );
    m_behaviourGroupLayout->setAlignment( Qt::AlignTop );

    m_normal = new QRadioButton( m_behaviourGroup, "m_normal" );
    m_behaviourGroupLayout->addWidget( m_normal );

    m_exclusive = new QRadioButton( m_behaviourGroup, "m_exclusive" );
    m_behaviourGroupLayout->addWidget( m_exclusive );
    UI_VCFramePropertiesLayout->addWidget( m_behaviourGroup );

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 
    spacer1 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout1->addItem( spacer1 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout1->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout1->addWidget( m_cancel );
    UI_VCFramePropertiesLayout->addLayout( layout1 );
    languageChange();
    resize( QSize(243, 144).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VCFrameProperties::~UI_VCFrameProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VCFrameProperties::languageChange()
{
    setCaption( tr( "Frame Properties" ) );
    m_behaviourGroup->setTitle( tr( "Button Behaviour" ) );
    m_normal->setText( tr( "&Normal" ) );
    m_normal->setAccel( QKeySequence( tr( "Alt+N" ) ) );
    QToolTip::add( m_normal, tr( "Buttons in this group don't care of each other" ) );
    m_exclusive->setText( tr( "&Exclusive" ) );
    m_exclusive->setAccel( QKeySequence( tr( "Alt+E" ) ) );
    QToolTip::add( m_exclusive, tr( "Buttons in this group are mutually exclusive (only one button can be active at a time)" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

void UI_VCFrameProperties::slotOKClicked()
{
    qWarning( "UI_VCFrameProperties::slotOKClicked(): Not implemented yet" );
}

void UI_VCFrameProperties::slotCancelClicked()
{
    qWarning( "UI_VCFrameProperties::slotCancelClicked(): Not implemented yet" );
}

