/****************************************************************************
** Form implementation generated from reading ui file 'src/dmxaddresstool.ui'
**
** Created: Thu Nov 30 00:54:49 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_dmxaddresstool.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qspinbox.h>
#include <qslider.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_DMXAddressTool as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_DMXAddressTool::UI_DMXAddressTool( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_DMXAddressTool" );
    UI_DMXAddressToolLayout = new QVBoxLayout( this, 11, 6, "UI_DMXAddressToolLayout"); 

    m_decimalValueGroup = new QGroupBox( this, "m_decimalValueGroup" );
    m_decimalValueGroup->setColumnLayout(0, Qt::Vertical );
    m_decimalValueGroup->layout()->setSpacing( 6 );
    m_decimalValueGroup->layout()->setMargin( 11 );
    m_decimalValueGroupLayout = new QVBoxLayout( m_decimalValueGroup->layout() );
    m_decimalValueGroupLayout->setAlignment( Qt::AlignTop );

    m_decimalSpin = new QSpinBox( m_decimalValueGroup, "m_decimalSpin" );
    m_decimalSpin->setMaxValue( 511 );
    m_decimalSpin->setMinValue( 1 );
    m_decimalValueGroupLayout->addWidget( m_decimalSpin );
    UI_DMXAddressToolLayout->addWidget( m_decimalValueGroup );

    m_DIPSettingGroup = new QGroupBox( this, "m_DIPSettingGroup" );
    m_DIPSettingGroup->setColumnLayout(0, Qt::Vertical );
    m_DIPSettingGroup->layout()->setSpacing( 6 );
    m_DIPSettingGroup->layout()->setMargin( 11 );
    m_DIPSettingGroupLayout = new QHBoxLayout( m_DIPSettingGroup->layout() );
    m_DIPSettingGroupLayout->setAlignment( Qt::AlignTop );

    layout13 = new QHBoxLayout( 0, 0, 6, "layout13"); 

    layout2 = new QVBoxLayout( 0, 0, 6, "layout2"); 

    m_256Slider = new QSlider( m_DIPSettingGroup, "m_256Slider" );
    m_256Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_256Slider->sizePolicy().hasHeightForWidth() ) );
    m_256Slider->setMaxValue( 1 );
    m_256Slider->setPageStep( 1 );
    m_256Slider->setOrientation( QSlider::Vertical );
    layout2->addWidget( m_256Slider );

    m_256Label = new QLabel( m_DIPSettingGroup, "m_256Label" );
    m_256Label->setAlignment( int( QLabel::AlignCenter ) );
    layout2->addWidget( m_256Label );
    layout13->addLayout( layout2 );

    layout3 = new QVBoxLayout( 0, 0, 6, "layout3"); 

    m_128Slider = new QSlider( m_DIPSettingGroup, "m_128Slider" );
    m_128Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_128Slider->sizePolicy().hasHeightForWidth() ) );
    m_128Slider->setMaxValue( 1 );
    m_128Slider->setPageStep( 1 );
    m_128Slider->setOrientation( QSlider::Vertical );
    layout3->addWidget( m_128Slider );

    m_128Label = new QLabel( m_DIPSettingGroup, "m_128Label" );
    m_128Label->setAlignment( int( QLabel::AlignCenter ) );
    layout3->addWidget( m_128Label );
    layout13->addLayout( layout3 );

    layout4 = new QVBoxLayout( 0, 0, 6, "layout4"); 

    m_64Slider = new QSlider( m_DIPSettingGroup, "m_64Slider" );
    m_64Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_64Slider->sizePolicy().hasHeightForWidth() ) );
    m_64Slider->setMaxValue( 1 );
    m_64Slider->setPageStep( 1 );
    m_64Slider->setOrientation( QSlider::Vertical );
    layout4->addWidget( m_64Slider );

    m_64Label = new QLabel( m_DIPSettingGroup, "m_64Label" );
    m_64Label->setAlignment( int( QLabel::AlignCenter ) );
    layout4->addWidget( m_64Label );
    layout13->addLayout( layout4 );

    layout5 = new QVBoxLayout( 0, 0, 6, "layout5"); 

    m_32Slider = new QSlider( m_DIPSettingGroup, "m_32Slider" );
    m_32Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_32Slider->sizePolicy().hasHeightForWidth() ) );
    m_32Slider->setMaxValue( 1 );
    m_32Slider->setPageStep( 1 );
    m_32Slider->setOrientation( QSlider::Vertical );
    layout5->addWidget( m_32Slider );

    m_32Label = new QLabel( m_DIPSettingGroup, "m_32Label" );
    m_32Label->setAlignment( int( QLabel::AlignCenter ) );
    layout5->addWidget( m_32Label );
    layout13->addLayout( layout5 );

    layout6 = new QVBoxLayout( 0, 0, 6, "layout6"); 

    m_16Slider = new QSlider( m_DIPSettingGroup, "m_16Slider" );
    m_16Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_16Slider->sizePolicy().hasHeightForWidth() ) );
    m_16Slider->setMaxValue( 1 );
    m_16Slider->setPageStep( 1 );
    m_16Slider->setOrientation( QSlider::Vertical );
    layout6->addWidget( m_16Slider );

    m_16Label = new QLabel( m_DIPSettingGroup, "m_16Label" );
    m_16Label->setMinimumSize( QSize( 25, 0 ) );
    m_16Label->setAlignment( int( QLabel::AlignCenter ) );
    layout6->addWidget( m_16Label );
    layout13->addLayout( layout6 );

    layout7 = new QVBoxLayout( 0, 0, 6, "layout7"); 

    m_8Slider = new QSlider( m_DIPSettingGroup, "m_8Slider" );
    m_8Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_8Slider->sizePolicy().hasHeightForWidth() ) );
    m_8Slider->setMaxValue( 1 );
    m_8Slider->setPageStep( 1 );
    m_8Slider->setOrientation( QSlider::Vertical );
    layout7->addWidget( m_8Slider );

    m_8Label = new QLabel( m_DIPSettingGroup, "m_8Label" );
    m_8Label->setAlignment( int( QLabel::AlignCenter ) );
    layout7->addWidget( m_8Label );
    layout13->addLayout( layout7 );

    layout8 = new QVBoxLayout( 0, 0, 6, "layout8"); 

    m_4Slider = new QSlider( m_DIPSettingGroup, "m_4Slider" );
    m_4Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_4Slider->sizePolicy().hasHeightForWidth() ) );
    m_4Slider->setMaxValue( 1 );
    m_4Slider->setPageStep( 1 );
    m_4Slider->setOrientation( QSlider::Vertical );
    layout8->addWidget( m_4Slider );

    m_4Label = new QLabel( m_DIPSettingGroup, "m_4Label" );
    m_4Label->setAlignment( int( QLabel::AlignCenter ) );
    layout8->addWidget( m_4Label );
    layout13->addLayout( layout8 );

    layout9 = new QVBoxLayout( 0, 0, 6, "layout9"); 

    m_2Slider = new QSlider( m_DIPSettingGroup, "m_2Slider" );
    m_2Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_2Slider->sizePolicy().hasHeightForWidth() ) );
    m_2Slider->setMaxValue( 1 );
    m_2Slider->setPageStep( 1 );
    m_2Slider->setOrientation( QSlider::Vertical );
    layout9->addWidget( m_2Slider );

    m_2Label = new QLabel( m_DIPSettingGroup, "m_2Label" );
    m_2Label->setAlignment( int( QLabel::AlignCenter ) );
    layout9->addWidget( m_2Label );
    layout13->addLayout( layout9 );

    layout10 = new QVBoxLayout( 0, 0, 6, "layout10"); 

    m_1Slider = new QSlider( m_DIPSettingGroup, "m_1Slider" );
    m_1Slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_1Slider->sizePolicy().hasHeightForWidth() ) );
    m_1Slider->setMaxValue( 1 );
    m_1Slider->setPageStep( 1 );
    m_1Slider->setOrientation( QSlider::Vertical );
    layout10->addWidget( m_1Slider );

    m_1Label = new QLabel( m_DIPSettingGroup, "m_1Label" );
    m_1Label->setAlignment( int( QLabel::AlignCenter ) );
    layout10->addWidget( m_1Label );
    layout13->addLayout( layout10 );

    layout12 = new QVBoxLayout( 0, 0, 6, "layout12"); 
    spacer3 = new QSpacerItem( 20, 50, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout12->addItem( spacer3 );

    m_onLabel = new QLabel( m_DIPSettingGroup, "m_onLabel" );
    layout12->addWidget( m_onLabel );
    layout13->addLayout( layout12 );
    m_DIPSettingGroupLayout->addLayout( layout13 );
    UI_DMXAddressToolLayout->addWidget( m_DIPSettingGroup );

    layout12_2 = new QHBoxLayout( 0, 0, 6, "layout12_2"); 
    m_spacer1 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout12_2->addItem( m_spacer1 );

    m_ok = new QPushButton( this, "m_ok" );
    layout12_2->addWidget( m_ok );
    m_spacer2 = new QSpacerItem( 20, 20, QSizePolicy::Minimum, QSizePolicy::Minimum );
    layout12_2->addItem( m_spacer2 );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout12_2->addWidget( m_cancel );
    UI_DMXAddressToolLayout->addLayout( layout12_2 );
    languageChange();
    resize( QSize(379, 242).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_decimalSpin, SIGNAL( valueChanged(const QString&) ), this, SLOT( slotDecimalChanged(const QString&) ) );
    connect( m_256Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_128Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_64Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_32Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_16Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_8Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_4Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_2Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_1Slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_DMXAddressTool::~UI_DMXAddressTool()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_DMXAddressTool::languageChange()
{
    setCaption( tr( "DMX Address Tool" ) );
    m_decimalValueGroup->setTitle( tr( "Decimal &Value" ) );
    m_DIPSettingGroup->setTitle( tr( "&DIP Setting" ) );
    m_256Label->setText( tr( "256" ) );
    m_128Label->setText( tr( "128" ) );
    m_64Label->setText( tr( "064" ) );
    m_32Label->setText( tr( "032" ) );
    m_16Label->setText( tr( "016" ) );
    m_8Label->setText( tr( "008" ) );
    m_4Label->setText( tr( "004" ) );
    m_2Label->setText( tr( "002" ) );
    m_1Label->setText( tr( "001" ) );
    m_onLabel->setText( tr( "ON" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

void UI_DMXAddressTool::slotSliderValueChanged(int)
{
    qWarning( "UI_DMXAddressTool::slotSliderValueChanged(int): Not implemented yet" );
}

void UI_DMXAddressTool::slotDecimalChanged(const QString&)
{
    qWarning( "UI_DMXAddressTool::slotDecimalChanged(const QString&): Not implemented yet" );
}

