/****************************************************************************
** Form interface generated from reading ui file 'src/patterngenerator.ui'
**
** Created: Thu Nov 30 00:54:59 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_PATTERNGENERATOR_H
#define UI_PATTERNGENERATOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QFrame;
class QGroupBox;
class QComboBox;
class QLabel;
class QSpinBox;
class QPushButton;

class UI_PatternGenerator : public QDialog
{
    Q_OBJECT

public:
    UI_PatternGenerator( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_PatternGenerator();

    QFrame* m_generatorFrame;
    QGroupBox* m_patternGroup;
    QComboBox* m_patternCombo;
    QGroupBox* m_parametersGroup;
    QLabel* m_widthLabel;
    QSpinBox* m_widthSpin;
    QLabel* m_heightLabel;
    QSpinBox* m_heightSpin;
    QLabel* m_xOffsetLabel;
    QSpinBox* m_xOffsetSpin;
    QLabel* m_yOffsetLabel;
    QSpinBox* m_yOffsetSpin;
    QLabel* m_densityLabel;
    QSpinBox* m_densitySpin;
    QLabel* m_orientationLabel;
    QSpinBox* m_orientation;
    QGroupBox* m_paraLissa;
    QLabel* m_omegaxLabel;
    QSpinBox* m_omegax;
    QLabel* m_omegayLabel;
    QSpinBox* m_omegay;
    QLabel* m_phasexLabel;
    QSpinBox* m_phasex;
    QLabel* m_phaseyLabel;
    QSpinBox* m_phasey;
    QGroupBox* m_axesGroup;
    QLabel* m_horizontalLabel;
    QComboBox* m_horizontalCombo;
    QLabel* m_verticalLabel;
    QComboBox* m_verticalCombo;
    QFrame* line2;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotHeightSpinChanged( int );
    virtual void slotXOffsetSpinChanged( int );
    virtual void slotYOffsetSpinChanged( int );
    virtual void slotWidthSpinChanged( int );
    virtual void slotDensitySpinChanged( int );
    virtual void slotHorizontalChannelSelected( int );
    virtual void slotVerticalChannelSelected( int );
    virtual void slotPatternSelected( const QString & );
    virtual void slotOrientationChanged( int );
    virtual void slotOmegaXChanged( int );
    virtual void slotOmegaYChanged( int );
    virtual void slotPhaseXChanged( int );
    virtual void slotPhaseYChanged( int );

protected:
    QVBoxLayout* UI_PatternGeneratorLayout;
    QHBoxLayout* layout64;
    QVBoxLayout* layout63;
    QHBoxLayout* m_patternGroupLayout;
    QHBoxLayout* layout62;
    QVBoxLayout* m_parametersGroupLayout;
    QVBoxLayout* layout14;
    QHBoxLayout* layout6;
    QHBoxLayout* layout7;
    QHBoxLayout* layout8;
    QHBoxLayout* layout9;
    QHBoxLayout* layout35;
    QHBoxLayout* layout23;
    QVBoxLayout* m_paraLissaLayout;
    QVBoxLayout* layout15;
    QHBoxLayout* layout13;
    QHBoxLayout* layout14_2;
    QHBoxLayout* layout15_2;
    QHBoxLayout* layout13_2;
    QVBoxLayout* m_axesGroupLayout;
    QHBoxLayout* layout14_3;
    QHBoxLayout* layout15_3;
    QHBoxLayout* layout13_3;
    QSpacerItem* spacer4;

protected slots:
    virtual void languageChange();

};

#endif // UI_PATTERNGENERATOR_H
