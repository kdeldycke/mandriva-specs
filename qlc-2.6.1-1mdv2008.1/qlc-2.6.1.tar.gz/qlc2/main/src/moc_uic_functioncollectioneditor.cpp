/****************************************************************************
** UI_FunctionCollectionEditor meta object code from reading C++ file 'uic_functioncollectioneditor.h'
**
** Created: Thu Nov 30 00:55:29 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_functioncollectioneditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_FunctionCollectionEditor::className() const
{
    return "UI_FunctionCollectionEditor";
}

QMetaObject *UI_FunctionCollectionEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_FunctionCollectionEditor( "UI_FunctionCollectionEditor", &UI_FunctionCollectionEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_FunctionCollectionEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_FunctionCollectionEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_FunctionCollectionEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_FunctionCollectionEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_FunctionCollectionEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"slotAddFunctionClicked", 0, 0 };
    static const QUMethod slot_1 = {"slotRemoveFunctionClicked", 0, 0 };
    static const QUMethod slot_2 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_3 = {"slotCancelClicked", 0, 0 };
    static const QUMethod slot_4 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotAddFunctionClicked()", &slot_0, QMetaData::Public },
	{ "slotRemoveFunctionClicked()", &slot_1, QMetaData::Public },
	{ "slotOKClicked()", &slot_2, QMetaData::Public },
	{ "slotCancelClicked()", &slot_3, QMetaData::Public },
	{ "languageChange()", &slot_4, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_FunctionCollectionEditor", parentObject,
	slot_tbl, 5,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_FunctionCollectionEditor.setMetaObject( metaObj );
    return metaObj;
}

void* UI_FunctionCollectionEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_FunctionCollectionEditor" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_FunctionCollectionEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotAddFunctionClicked(); break;
    case 1: slotRemoveFunctionClicked(); break;
    case 2: slotOKClicked(); break;
    case 3: slotCancelClicked(); break;
    case 4: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_FunctionCollectionEditor::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_FunctionCollectionEditor::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_FunctionCollectionEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
