/****************************************************************************
** Form interface generated from reading ui file 'src/deviceproperties.ui'
**
** Created: Thu Nov 30 00:54:47 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_DEVICEPROPERTIES_H
#define UI_DEVICEPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QSpinBox;
class QPushButton;

class UI_DeviceProperties : public QDialog
{
    Q_OBJECT

public:
    UI_DeviceProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_DeviceProperties();

    QLabel* m_deviceNameLabel;
    QLineEdit* m_deviceNameEdit;
    QLabel* m_addressLabel;
    QSpinBox* m_addressSpin;
    QLabel* m_universeLabel;
    QSpinBox* m_universeSpin;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotDIPClicked();
    virtual void slotOKClicked();

protected:
    QVBoxLayout* UI_DevicePropertiesLayout;
    QHBoxLayout* layout1;
    QHBoxLayout* layout5;
    QHBoxLayout* layout4;
    QHBoxLayout* layout7;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

};

#endif // UI_DEVICEPROPERTIES_H
