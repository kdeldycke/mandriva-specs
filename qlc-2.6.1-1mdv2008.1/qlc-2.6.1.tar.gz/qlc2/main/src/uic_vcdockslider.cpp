/****************************************************************************
** Form implementation generated from reading ui file 'src/vcdockslider.ui'
**
** Created: Thu Nov 30 00:55:11 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_vcdockslider.h"

#include <qvariant.h>
#include <qlabel.h>
#include <qslider.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VCDockSlider which is a child of 'parent', with the
 *  name 'name'.' 
 */
UI_VCDockSlider::UI_VCDockSlider( QWidget* parent,  const char* name )
    : QFrame( parent, name )
{
    if ( !name )
	setName( "UI_VCDockSlider" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMinimumSize( QSize( 55, 0 ) );
    setMaximumSize( QSize( 55, 32767 ) );
    setFrameShape( QFrame::StyledPanel );
    setFrameShadow( QFrame::Sunken );
    UI_VCDockSliderLayout = new QVBoxLayout( this, 2, 0, "UI_VCDockSliderLayout"); 

    m_valueLabel = new QLabel( this, "m_valueLabel" );
    m_valueLabel->setAlignment( int( QLabel::AlignCenter ) );
    UI_VCDockSliderLayout->addWidget( m_valueLabel );

    layout3 = new QHBoxLayout( 0, 0, 6, "layout3"); 
    spacer5 = new QSpacerItem( 10, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum );
    layout3->addItem( spacer5 );

    m_slider = new QSlider( this, "m_slider" );
    m_slider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_slider->sizePolicy().hasHeightForWidth() ) );
    m_slider->setMinValue( 0 );
    m_slider->setMaxValue( 1024 );
    m_slider->setPageStep( 1 );
    m_slider->setValue( 0 );
    m_slider->setOrientation( QSlider::Vertical );
    m_slider->setTickmarks( QSlider::NoMarks );
    m_slider->setTickInterval( 8 );
    layout3->addWidget( m_slider );
    spacer4 = new QSpacerItem( 10, 20, QSizePolicy::MinimumExpanding, QSizePolicy::Minimum );
    layout3->addItem( spacer4 );
    UI_VCDockSliderLayout->addLayout( layout3 );

    m_tapInButton = new QPushButton( this, "m_tapInButton" );
    QFont m_tapInButton_font(  m_tapInButton->font() );
    m_tapInButton_font.setPointSize( 9 );
    m_tapInButton->setFont( m_tapInButton_font ); 
    UI_VCDockSliderLayout->addWidget( m_tapInButton );

    m_infoLabel = new QLabel( this, "m_infoLabel" );
    m_infoLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, m_infoLabel->sizePolicy().hasHeightForWidth() ) );
    QFont m_infoLabel_font(  m_infoLabel->font() );
    m_infoLabel_font.setPointSize( 9 );
    m_infoLabel->setFont( m_infoLabel_font ); 
    m_infoLabel->setAlignment( int( QLabel::WordBreak | QLabel::AlignCenter ) );
    UI_VCDockSliderLayout->addWidget( m_infoLabel );
    languageChange();
    resize( QSize(55, 254).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_slider, SIGNAL( valueChanged(int) ), this, SLOT( slotSliderValueChanged(int) ) );
    connect( m_tapInButton, SIGNAL( clicked() ), this, SLOT( slotTapInButtonClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VCDockSlider::~UI_VCDockSlider()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VCDockSlider::languageChange()
{
    setCaption( tr( "VCDockSlider" ) );
    m_valueLabel->setText( tr( "000" ) );
    m_tapInButton->setText( QString::null );
    QToolTip::add( m_tapInButton, tr( "Tap Speed" ) );
    m_infoLabel->setText( tr( "No Name" ) );
}

void UI_VCDockSlider::slotSliderValueChanged(int)
{
    qWarning( "UI_VCDockSlider::slotSliderValueChanged(int): Not implemented yet" );
}

void UI_VCDockSlider::slotPropertiesButtonClicked()
{
    qWarning( "UI_VCDockSlider::slotPropertiesButtonClicked(): Not implemented yet" );
}

void UI_VCDockSlider::slotFunctionButtonClicked()
{
    qWarning( "UI_VCDockSlider::slotFunctionButtonClicked(): Not implemented yet" );
}

void UI_VCDockSlider::slotTapInButtonClicked()
{
    qWarning( "UI_VCDockSlider::slotTapInButtonClicked(): Not implemented yet" );
}

