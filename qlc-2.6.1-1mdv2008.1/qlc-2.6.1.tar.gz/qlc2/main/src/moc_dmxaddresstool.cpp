/****************************************************************************
** DMXAddressTool meta object code from reading C++ file 'dmxaddresstool.h'
**
** Created: Thu Nov 30 00:57:34 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "dmxaddresstool.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DMXAddressTool::className() const
{
    return "DMXAddressTool";
}

QMetaObject *DMXAddressTool::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DMXAddressTool( "DMXAddressTool", &DMXAddressTool::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DMXAddressTool::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DMXAddressTool", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DMXAddressTool::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DMXAddressTool", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DMXAddressTool::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_DMXAddressTool::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSliderValueChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotDecimalChanged", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "slotSliderValueChanged(int)", &slot_0, QMetaData::Private },
	{ "slotDecimalChanged(const QString&)", &slot_1, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"DMXAddressTool", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DMXAddressTool.setMetaObject( metaObj );
    return metaObj;
}

void* DMXAddressTool::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DMXAddressTool" ) )
	return this;
    return UI_DMXAddressTool::qt_cast( clname );
}

bool DMXAddressTool::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSliderValueChanged((int)static_QUType_int.get(_o+1)); break;
    case 1: slotDecimalChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    default:
	return UI_DMXAddressTool::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DMXAddressTool::qt_emit( int _id, QUObject* _o )
{
    return UI_DMXAddressTool::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool DMXAddressTool::qt_property( int id, int f, QVariant* v)
{
    return UI_DMXAddressTool::qt_property( id, f, v);
}

bool DMXAddressTool::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
