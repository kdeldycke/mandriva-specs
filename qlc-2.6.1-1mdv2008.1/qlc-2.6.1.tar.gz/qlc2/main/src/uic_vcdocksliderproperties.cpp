/****************************************************************************
** Form implementation generated from reading ui file 'src/vcdocksliderproperties.ui'
**
** Created: Thu Nov 30 00:55:09 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_vcdocksliderproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlineedit.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VCDockSliderProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_VCDockSliderProperties::UI_VCDockSliderProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_VCDockSliderProperties" );
    UI_VCDockSliderPropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_VCDockSliderPropertiesLayout"); 

    m_behaviourGroup = new QButtonGroup( this, "m_behaviourGroup" );
    m_behaviourGroup->setFrameShape( QButtonGroup::Box );
    m_behaviourGroup->setFrameShadow( QButtonGroup::Sunken );
    m_behaviourGroup->setProperty( "selectedId", -1 );
    m_behaviourGroup->setColumnLayout(0, Qt::Vertical );
    m_behaviourGroup->layout()->setSpacing( 6 );
    m_behaviourGroup->layout()->setMargin( 11 );
    m_behaviourGroupLayout = new QVBoxLayout( m_behaviourGroup->layout() );
    m_behaviourGroupLayout->setAlignment( Qt::AlignTop );

    m_speedRadio = new QRadioButton( m_behaviourGroup, "m_speedRadio" );
    m_behaviourGroup->insert( m_speedRadio, 0 );
    m_behaviourGroupLayout->addWidget( m_speedRadio );

    m_busGroup = new QGroupBox( m_behaviourGroup, "m_busGroup" );
    m_busGroup->setEnabled( FALSE );
    m_busGroup->setColumnLayout(0, Qt::Vertical );
    m_busGroup->layout()->setSpacing( 6 );
    m_busGroup->layout()->setMargin( 11 );
    m_busGroupLayout = new QVBoxLayout( m_busGroup->layout() );
    m_busGroupLayout->setAlignment( Qt::AlignTop );

    layout3 = new QHBoxLayout( 0, 0, 6, "layout3"); 

    textLabel1 = new QLabel( m_busGroup, "textLabel1" );
    textLabel1->setMinimumSize( QSize( 70, 0 ) );
    layout3->addWidget( textLabel1 );

    m_busCombo = new QComboBox( FALSE, m_busGroup, "m_busCombo" );
    m_busCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_busCombo->sizePolicy().hasHeightForWidth() ) );
    layout3->addWidget( m_busCombo );
    m_busGroupLayout->addLayout( layout3 );

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    textLabel2 = new QLabel( m_busGroup, "textLabel2" );
    textLabel2->setMinimumSize( QSize( 70, 0 ) );
    layout4->addWidget( textLabel2 );

    m_lowBusValueSpin = new QSpinBox( m_busGroup, "m_lowBusValueSpin" );
    m_lowBusValueSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_lowBusValueSpin->sizePolicy().hasHeightForWidth() ) );
    m_lowBusValueSpin->setMaxValue( 999 );
    layout4->addWidget( m_lowBusValueSpin );

    textLabel3 = new QLabel( m_busGroup, "textLabel3" );
    textLabel3->setMinimumSize( QSize( 70, 0 ) );
    layout4->addWidget( textLabel3 );

    m_highBusValueSpin = new QSpinBox( m_busGroup, "m_highBusValueSpin" );
    m_highBusValueSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_highBusValueSpin->sizePolicy().hasHeightForWidth() ) );
    m_highBusValueSpin->setMaxValue( 999 );
    m_highBusValueSpin->setValue( 16 );
    layout4->addWidget( m_highBusValueSpin );
    m_busGroupLayout->addLayout( layout4 );
    m_behaviourGroupLayout->addWidget( m_busGroup );

    m_levelRadio = new QRadioButton( m_behaviourGroup, "m_levelRadio" );
    m_behaviourGroup->insert( m_levelRadio, 1 );
    m_behaviourGroupLayout->addWidget( m_levelRadio );

    m_submasterRadio = new QRadioButton( m_behaviourGroup, "m_submasterRadio" );
    m_behaviourGroup->insert( m_submasterRadio, 2 );
    m_behaviourGroupLayout->addWidget( m_submasterRadio );

    m_channelGroup = new QGroupBox( m_behaviourGroup, "m_channelGroup" );
    m_channelGroup->setEnabled( FALSE );
    m_channelGroup->setColumnLayout(0, Qt::Vertical );
    m_channelGroup->layout()->setSpacing( 6 );
    m_channelGroup->layout()->setMargin( 11 );
    m_channelGroupLayout = new QHBoxLayout( m_channelGroup->layout() );
    m_channelGroupLayout->setAlignment( Qt::AlignTop );

    layout7 = new QVBoxLayout( 0, 0, 6, "layout7"); 

    m_channelList = new QListView( m_channelGroup, "m_channelList" );
    m_channelList->addColumn( tr( "Device" ) );
    m_channelList->addColumn( tr( "Channel" ) );
    m_channelList->setResizeMode( QListView::AllColumns );
    layout7->addWidget( m_channelList );

    layout5 = new QHBoxLayout( 0, 0, 6, "layout5"); 

    textLabel1_2 = new QLabel( m_channelGroup, "textLabel1_2" );
    textLabel1_2->setMinimumSize( QSize( 70, 0 ) );
    layout5->addWidget( textLabel1_2 );

    m_lowChannelValueSpin = new QSpinBox( m_channelGroup, "m_lowChannelValueSpin" );
    m_lowChannelValueSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_lowChannelValueSpin->sizePolicy().hasHeightForWidth() ) );
    m_lowChannelValueSpin->setMaxValue( 255 );
    layout5->addWidget( m_lowChannelValueSpin );

    textLabel2_2 = new QLabel( m_channelGroup, "textLabel2_2" );
    textLabel2_2->setMinimumSize( QSize( 70, 0 ) );
    layout5->addWidget( textLabel2_2 );

    m_highChannelValueSpin = new QSpinBox( m_channelGroup, "m_highChannelValueSpin" );
    m_highChannelValueSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_highChannelValueSpin->sizePolicy().hasHeightForWidth() ) );
    m_highChannelValueSpin->setMaxValue( 255 );
    m_highChannelValueSpin->setValue( 255 );
    layout5->addWidget( m_highChannelValueSpin );
    layout7->addLayout( layout5 );
    m_channelGroupLayout->addLayout( layout7 );

    layout6 = new QVBoxLayout( 0, 0, 6, "layout6"); 

    m_allChannels = new QPushButton( m_channelGroup, "m_allChannels" );
    m_allChannels->setEnabled( FALSE );
    layout6->addWidget( m_allChannels );

    m_invertChannels = new QPushButton( m_channelGroup, "m_invertChannels" );
    m_invertChannels->setEnabled( FALSE );
    layout6->addWidget( m_invertChannels );

    m_clearChannels = new QPushButton( m_channelGroup, "m_clearChannels" );
    m_clearChannels->setEnabled( FALSE );
    layout6->addWidget( m_clearChannels );

    m_deviceChannels = new QPushButton( m_channelGroup, "m_deviceChannels" );
    m_deviceChannels->setEnabled( FALSE );
    layout6->addWidget( m_deviceChannels );

    m_roleChannels = new QPushButton( m_channelGroup, "m_roleChannels" );
    m_roleChannels->setEnabled( FALSE );
    layout6->addWidget( m_roleChannels );
    spacer5 = new QSpacerItem( 20, 51, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout6->addItem( spacer5 );
    m_channelGroupLayout->addLayout( layout6 );
    m_behaviourGroupLayout->addWidget( m_channelGroup );

    m_keybourdHotkeyGroup = new QGroupBox( m_behaviourGroup, "m_keybourdHotkeyGroup" );
    m_keybourdHotkeyGroup->setColumnLayout(0, Qt::Vertical );
    m_keybourdHotkeyGroup->layout()->setSpacing( 6 );
    m_keybourdHotkeyGroup->layout()->setMargin( 11 );
    m_keybourdHotkeyGroupLayout = new QGridLayout( m_keybourdHotkeyGroup->layout() );
    m_keybourdHotkeyGroupLayout->setAlignment( Qt::AlignTop );

    m_keyUpLabel = new QLabel( m_keybourdHotkeyGroup, "m_keyUpLabel" );

    m_keybourdHotkeyGroupLayout->addWidget( m_keyUpLabel, 0, 0 );

    m_keyDownLabel = new QLabel( m_keybourdHotkeyGroup, "m_keyDownLabel" );

    m_keybourdHotkeyGroupLayout->addWidget( m_keyDownLabel, 1, 0 );

    m_keyUpEdit = new QLineEdit( m_keybourdHotkeyGroup, "m_keyUpEdit" );

    m_keybourdHotkeyGroupLayout->addWidget( m_keyUpEdit, 0, 1 );

    m_keyDownEdit = new QLineEdit( m_keybourdHotkeyGroup, "m_keyDownEdit" );

    m_keybourdHotkeyGroupLayout->addWidget( m_keyDownEdit, 1, 1 );

    m_detachKey = new QPushButton( m_keybourdHotkeyGroup, "m_detachKey" );
    m_detachKey->setMinimumSize( QSize( 30, 30 ) );
    m_detachKey->setMaximumSize( QSize( 30, 30 ) );

    m_keybourdHotkeyGroupLayout->addMultiCellWidget( m_detachKey, 0, 1, 3, 3 );

    m_attachKey = new QPushButton( m_keybourdHotkeyGroup, "m_attachKey" );
    m_attachKey->setMinimumSize( QSize( 30, 30 ) );
    m_attachKey->setMaximumSize( QSize( 30, 30 ) );

    m_keybourdHotkeyGroupLayout->addMultiCellWidget( m_attachKey, 0, 1, 2, 2 );
    m_behaviourGroupLayout->addWidget( m_keybourdHotkeyGroup );

    m_IDLabel = new QGroupBox( m_behaviourGroup, "m_IDLabel" );
    m_IDLabel->setColumnLayout(0, Qt::Vertical );
    m_IDLabel->layout()->setSpacing( 6 );
    m_IDLabel->layout()->setMargin( 11 );
    m_IDLabelLayout = new QGridLayout( m_IDLabel->layout() );
    m_IDLabelLayout->setAlignment( Qt::AlignTop );

    m_keyLabel_2 = new QLabel( m_IDLabel, "m_keyLabel_2" );
    m_keyLabel_2->setMinimumSize( QSize( 80, 0 ) );

    m_IDLabelLayout->addWidget( m_keyLabel_2, 0, 0 );

    m_IDCombo = new QComboBox( FALSE, m_IDLabel, "m_IDCombo" );
    m_IDCombo->setEnabled( TRUE );

    m_IDLabelLayout->addWidget( m_IDCombo, 0, 1 );

    m_channelLabel = new QLabel( m_IDLabel, "m_channelLabel" );
    m_channelLabel->setMinimumSize( QSize( 80, 0 ) );

    m_IDLabelLayout->addWidget( m_channelLabel, 1, 0 );

    m_channelSpinBox = new QSpinBox( m_IDLabel, "m_channelSpinBox" );
    m_channelSpinBox->setMaxValue( 127 );

    m_IDLabelLayout->addWidget( m_channelSpinBox, 1, 1 );
    m_behaviourGroupLayout->addWidget( m_IDLabel );
    UI_VCDockSliderPropertiesLayout->addWidget( m_behaviourGroup );

    layout7_2 = new QHBoxLayout( 0, 0, 6, "layout7_2"); 
    spacer2 = new QSpacerItem( 190, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout7_2->addItem( spacer2 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout7_2->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout7_2->addWidget( m_cancel );
    UI_VCDockSliderPropertiesLayout->addLayout( layout7_2 );
    languageChange();
    resize( QSize(443, 629).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_behaviourGroup, SIGNAL( clicked(int) ), this, SLOT( slotBehaviourSelected(int) ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_allChannels, SIGNAL( clicked() ), this, SLOT( slotAllChannelsClicked() ) );
    connect( m_invertChannels, SIGNAL( clicked() ), this, SLOT( slotInvertChannelsClicked() ) );
    connect( m_clearChannels, SIGNAL( clicked() ), this, SLOT( slotClearChannelsClicked() ) );
    connect( m_deviceChannels, SIGNAL( clicked() ), this, SLOT( slotDeviceChannelsClicked() ) );
    connect( m_roleChannels, SIGNAL( clicked() ), this, SLOT( slotRoleChannelsClicked() ) );
    connect( m_attachKey, SIGNAL( clicked() ), this, SLOT( slotAttachKeyClicked() ) );
    connect( m_detachKey, SIGNAL( clicked() ), this, SLOT( slotDetachKeyClicked() ) );

    // tab order
    setTabOrder( m_speedRadio, m_busCombo );
    setTabOrder( m_busCombo, m_lowBusValueSpin );
    setTabOrder( m_lowBusValueSpin, m_highBusValueSpin );
    setTabOrder( m_highBusValueSpin, m_levelRadio );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VCDockSliderProperties::~UI_VCDockSliderProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VCDockSliderProperties::languageChange()
{
    setCaption( tr( "Slider Properties" ) );
    m_behaviourGroup->setTitle( QString::null );
    m_speedRadio->setText( tr( "&Speed Setting" ) );
    m_speedRadio->setAccel( QKeySequence( tr( "Alt+S" ) ) );
    QToolTip::add( m_speedRadio, tr( "Use this slider to set fade or hold time for functions" ) );
    m_busGroup->setTitle( QString::null );
    textLabel1->setText( tr( "Bus" ) );
    QToolTip::add( m_busCombo, tr( "The bus that this slider will set its value to" ) );
    textLabel2->setText( tr( "Low Limit" ) );
    m_lowBusValueSpin->setSuffix( tr( "s" ) );
    QToolTip::add( m_lowBusValueSpin, tr( "Shortest time in seconds" ) );
    textLabel3->setText( tr( "High Limit" ) );
    m_highBusValueSpin->setSuffix( tr( "s" ) );
    QToolTip::add( m_highBusValueSpin, tr( "Longest time in seconds" ) );
    m_levelRadio->setText( tr( "&Level..." ) );
    m_levelRadio->setAccel( QKeySequence( tr( "Alt+L" ) ) );
    QToolTip::add( m_levelRadio, tr( "Use this slider to set the value for individual channels" ) );
    m_submasterRadio->setText( tr( "Submaster..." ) );
    QToolTip::add( m_submasterRadio, tr( "Use this slider to set the maximum value limit for selected channels" ) );
    m_channelGroup->setTitle( tr( "...for Channels" ) );
    m_channelList->header()->setLabel( 0, tr( "Device" ) );
    m_channelList->header()->setLabel( 1, tr( "Channel" ) );
    QToolTip::add( m_channelList, tr( "This slider affects these channels" ) );
    textLabel1_2->setText( tr( "Low Limit" ) );
    QToolTip::add( m_lowChannelValueSpin, tr( "Lowest value that this slider can set to the selected channel(s)" ) );
    textLabel2_2->setText( tr( "High Limit" ) );
    QToolTip::add( m_highChannelValueSpin, tr( "Highest value this slider can set to the selected channel(s)" ) );
    m_allChannels->setText( tr( "All" ) );
    QToolTip::add( m_allChannels, tr( "Select all channels" ) );
    m_invertChannels->setText( tr( "Invert" ) );
    QToolTip::add( m_invertChannels, tr( "Invert selection" ) );
    m_clearChannels->setText( tr( "Clear" ) );
    QToolTip::add( m_clearChannels, tr( "Clear channel selection" ) );
    m_deviceChannels->setText( tr( "Device" ) );
    QToolTip::add( m_deviceChannels, tr( "Toggle selection on all channels from the current device" ) );
    m_roleChannels->setText( tr( "Role" ) );
    QToolTip::add( m_roleChannels, tr( "Toggle selection on such channels, whose roles (names) match the selected channel" ) );
    m_keybourdHotkeyGroup->setTitle( tr( "Keyboard Hotkeys" ) );
    m_keyUpLabel->setText( tr( "Key Up" ) );
    m_keyDownLabel->setText( tr( "Key Down" ) );
    m_detachKey->setText( QString::null );
    m_attachKey->setText( QString::null );
    m_IDLabel->setTitle( tr( "External Input/Output settings" ) );
    m_keyLabel_2->setText( tr( "ID" ) );
    m_IDCombo->clear();
    m_IDCombo->insertItem( tr( "Midi 1 - ControlChange" ) );
    QToolTip::add( m_IDCombo, tr( "The device and type of control." ) );
    m_channelLabel->setText( tr( "Channel" ) );
    QToolTip::add( m_channelSpinBox, tr( "The control change number." ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Discard changes and close" ) );
}

void UI_VCDockSliderProperties::slotOKClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotOKClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotCancelClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotCancelClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotBehaviourSelected(int)
{
    qWarning( "UI_VCDockSliderProperties::slotBehaviourSelected(int): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotAllChannelsClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotAllChannelsClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotClearChannelsClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotClearChannelsClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotInvertChannelsClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotInvertChannelsClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotDeviceChannelsClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotDeviceChannelsClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotRoleChannelsClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotRoleChannelsClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotAttachKeyClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotAttachKeyClicked(): Not implemented yet" );
}

void UI_VCDockSliderProperties::slotDetachKeyClicked()
{
    qWarning( "UI_VCDockSliderProperties::slotDetachKeyClicked(): Not implemented yet" );
}

