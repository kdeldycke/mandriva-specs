/****************************************************************************
** Form implementation generated from reading ui file 'src/assignhotkey.ui'
**
** Created: Thu Nov 30 00:54:39 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_assignhotkey.h"

#include <qvariant.h>
#include <qtextview.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_AssignHotKey as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_AssignHotKey::UI_AssignHotKey( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_AssignHotKey" );
    UI_AssignHotKeyLayout = new QVBoxLayout( this, 11, 6, "UI_AssignHotKeyLayout"); 

    m_infoText = new QTextView( this, "m_infoText" );
    m_infoText->setTextFormat( QTextView::AutoText );
    UI_AssignHotKeyLayout->addWidget( m_infoText );

    m_previewLabel = new QLabel( this, "m_previewLabel" );
    m_previewLabel->setAlignment( int( QLabel::AlignCenter ) );
    UI_AssignHotKeyLayout->addWidget( m_previewLabel );

    m_previewEdit = new QLineEdit( this, "m_previewEdit" );
    UI_AssignHotKeyLayout->addWidget( m_previewEdit );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_ok = new QPushButton( this, "m_ok" );
    layout9->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout9->addWidget( m_cancel );
    UI_AssignHotKeyLayout->addLayout( layout9 );
    languageChange();
    resize( QSize(282, 349).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_AssignHotKey::~UI_AssignHotKey()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_AssignHotKey::languageChange()
{
    setCaption( tr( "Assign Hotkey to Button" ) );
    m_previewLabel->setText( tr( "Preview hotkey" ) );
    m_ok->setText( tr( "OK" ) );
    m_cancel->setText( tr( "Cancel" ) );
}

