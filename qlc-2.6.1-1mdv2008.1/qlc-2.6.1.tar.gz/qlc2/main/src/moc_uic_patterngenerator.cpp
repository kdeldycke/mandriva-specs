/****************************************************************************
** UI_PatternGenerator meta object code from reading C++ file 'uic_patterngenerator.h'
**
** Created: Thu Nov 30 00:55:31 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_patterngenerator.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_PatternGenerator::className() const
{
    return "UI_PatternGenerator";
}

QMetaObject *UI_PatternGenerator::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_PatternGenerator( "UI_PatternGenerator", &UI_PatternGenerator::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_PatternGenerator::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_PatternGenerator", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_PatternGenerator::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_PatternGenerator", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_PatternGenerator::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotHeightSpinChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotXOffsetSpinChanged", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotYOffsetSpinChanged", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotWidthSpinChanged", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotDensitySpinChanged", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotHorizontalChannelSelected", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"slotVerticalChannelSelected", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotPatternSelected", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotOrientationChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotOmegaXChanged", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotOmegaYChanged", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotPhaseXChanged", 1, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotPhaseYChanged", 1, param_slot_12 };
    static const QUMethod slot_13 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotHeightSpinChanged(int)", &slot_0, QMetaData::Public },
	{ "slotXOffsetSpinChanged(int)", &slot_1, QMetaData::Public },
	{ "slotYOffsetSpinChanged(int)", &slot_2, QMetaData::Public },
	{ "slotWidthSpinChanged(int)", &slot_3, QMetaData::Public },
	{ "slotDensitySpinChanged(int)", &slot_4, QMetaData::Public },
	{ "slotHorizontalChannelSelected(int)", &slot_5, QMetaData::Public },
	{ "slotVerticalChannelSelected(int)", &slot_6, QMetaData::Public },
	{ "slotPatternSelected(const QString&)", &slot_7, QMetaData::Public },
	{ "slotOrientationChanged(int)", &slot_8, QMetaData::Public },
	{ "slotOmegaXChanged(int)", &slot_9, QMetaData::Public },
	{ "slotOmegaYChanged(int)", &slot_10, QMetaData::Public },
	{ "slotPhaseXChanged(int)", &slot_11, QMetaData::Public },
	{ "slotPhaseYChanged(int)", &slot_12, QMetaData::Public },
	{ "languageChange()", &slot_13, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_PatternGenerator", parentObject,
	slot_tbl, 14,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_PatternGenerator.setMetaObject( metaObj );
    return metaObj;
}

void* UI_PatternGenerator::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_PatternGenerator" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_PatternGenerator::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotHeightSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 1: slotXOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 2: slotYOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 3: slotWidthSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 4: slotDensitySpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 5: slotHorizontalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    case 6: slotVerticalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    case 7: slotPatternSelected((const QString&)static_QUType_QString.get(_o+1)); break;
    case 8: slotOrientationChanged((int)static_QUType_int.get(_o+1)); break;
    case 9: slotOmegaXChanged((int)static_QUType_int.get(_o+1)); break;
    case 10: slotOmegaYChanged((int)static_QUType_int.get(_o+1)); break;
    case 11: slotPhaseXChanged((int)static_QUType_int.get(_o+1)); break;
    case 12: slotPhaseYChanged((int)static_QUType_int.get(_o+1)); break;
    case 13: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_PatternGenerator::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_PatternGenerator::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_PatternGenerator::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
