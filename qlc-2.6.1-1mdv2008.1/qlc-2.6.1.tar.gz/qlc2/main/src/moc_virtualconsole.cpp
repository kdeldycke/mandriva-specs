/****************************************************************************
** VirtualConsole meta object code from reading C++ file 'virtualconsole.h'
**
** Created: Thu Nov 30 00:58:02 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "virtualconsole.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VirtualConsole::className() const
{
    return "VirtualConsole";
}

QMetaObject *VirtualConsole::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VirtualConsole( "VirtualConsole", &VirtualConsole::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VirtualConsole::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VirtualConsole", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VirtualConsole::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VirtualConsole", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VirtualConsole::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotDockAreaHidden", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotModeChanged", 0, 0 };
    static const QUMethod slot_2 = {"slotAddButton", 0, 0 };
    static const QUMethod slot_3 = {"slotAddSlider", 0, 0 };
    static const QUMethod slot_4 = {"slotAddFrame", 0, 0 };
    static const QUMethod slot_5 = {"slotAddLabel", 0, 0 };
    static const QUMethod slot_6 = {"slotAddXYPad", 0, 0 };
    static const QUMethod slot_7 = {"slotToolsSliders", 0, 0 };
    static const QUMethod slot_8 = {"slotToolsSettings", 0, 0 };
    static const QUMethod slot_9 = {"slotToolsPanic", 0, 0 };
    static const QUMethod slot_10 = {"slotEditCut", 0, 0 };
    static const QUMethod slot_11 = {"slotEditCopy", 0, 0 };
    static const QUMethod slot_12 = {"slotEditPaste", 0, 0 };
    static const QUMethod slot_13 = {"slotEditDelete", 0, 0 };
    static const QUMethod slot_14 = {"slotEditProperties", 0, 0 };
    static const QUMethod slot_15 = {"slotEditRename", 0, 0 };
    static const QUMethod slot_16 = {"slotEditRenameReturnPressed", 0, 0 };
    static const QUMethod slot_17 = {"slotEditRenameCancelled", 0, 0 };
    static const QUMethod slot_18 = {"slotForegroundFont", 0, 0 };
    static const QUMethod slot_19 = {"slotForegroundColor", 0, 0 };
    static const QUMethod slot_20 = {"slotForegroundNone", 0, 0 };
    static const QUMethod slot_21 = {"slotBackgroundColor", 0, 0 };
    static const QUMethod slot_22 = {"slotBackgroundImage", 0, 0 };
    static const QUMethod slot_23 = {"slotBackgroundNone", 0, 0 };
    static const QUMethod slot_24 = {"slotBackgroundFrame", 0, 0 };
    static const QUMethod slot_25 = {"slotStackingRaise", 0, 0 };
    static const QUMethod slot_26 = {"slotStackingLower", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotDockAreaHidden(bool)", &slot_0, QMetaData::Public },
	{ "slotModeChanged()", &slot_1, QMetaData::Public },
	{ "slotAddButton()", &slot_2, QMetaData::Public },
	{ "slotAddSlider()", &slot_3, QMetaData::Public },
	{ "slotAddFrame()", &slot_4, QMetaData::Public },
	{ "slotAddLabel()", &slot_5, QMetaData::Public },
	{ "slotAddXYPad()", &slot_6, QMetaData::Public },
	{ "slotToolsSliders()", &slot_7, QMetaData::Public },
	{ "slotToolsSettings()", &slot_8, QMetaData::Public },
	{ "slotToolsPanic()", &slot_9, QMetaData::Public },
	{ "slotEditCut()", &slot_10, QMetaData::Public },
	{ "slotEditCopy()", &slot_11, QMetaData::Public },
	{ "slotEditPaste()", &slot_12, QMetaData::Public },
	{ "slotEditDelete()", &slot_13, QMetaData::Public },
	{ "slotEditProperties()", &slot_14, QMetaData::Public },
	{ "slotEditRename()", &slot_15, QMetaData::Public },
	{ "slotEditRenameReturnPressed()", &slot_16, QMetaData::Public },
	{ "slotEditRenameCancelled()", &slot_17, QMetaData::Public },
	{ "slotForegroundFont()", &slot_18, QMetaData::Public },
	{ "slotForegroundColor()", &slot_19, QMetaData::Public },
	{ "slotForegroundNone()", &slot_20, QMetaData::Public },
	{ "slotBackgroundColor()", &slot_21, QMetaData::Public },
	{ "slotBackgroundImage()", &slot_22, QMetaData::Public },
	{ "slotBackgroundNone()", &slot_23, QMetaData::Public },
	{ "slotBackgroundFrame()", &slot_24, QMetaData::Public },
	{ "slotStackingRaise()", &slot_25, QMetaData::Public },
	{ "slotStackingLower()", &slot_26, QMetaData::Public }
    };
    static const QUMethod signal_0 = {"closed", 0, 0 };
    static const QUParameter param_signal_1[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod signal_1 = {"InpEvent", 3, param_signal_1 };
    static const QUMethod signal_2 = {"sendFeedBack", 0, 0 };
    static const QUParameter param_signal_3[] = {
	{ 0, &static_QUType_ptr, "QKeyEvent", QUParameter::In }
    };
    static const QUMethod signal_3 = {"keyPressed", 1, param_signal_3 };
    static const QUParameter param_signal_4[] = {
	{ 0, &static_QUType_ptr, "QKeyEvent", QUParameter::In }
    };
    static const QUMethod signal_4 = {"keyReleased", 1, param_signal_4 };
    static const QMetaData signal_tbl[] = {
	{ "closed()", &signal_0, QMetaData::Public },
	{ "InpEvent(const int,const int,const int)", &signal_1, QMetaData::Public },
	{ "sendFeedBack()", &signal_2, QMetaData::Public },
	{ "keyPressed(QKeyEvent*)", &signal_3, QMetaData::Public },
	{ "keyReleased(QKeyEvent*)", &signal_4, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"VirtualConsole", parentObject,
	slot_tbl, 27,
	signal_tbl, 5,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VirtualConsole.setMetaObject( metaObj );
    return metaObj;
}

void* VirtualConsole::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VirtualConsole" ) )
	return this;
    return QWidget::qt_cast( clname );
}

// SIGNAL closed
void VirtualConsole::closed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL InpEvent
void VirtualConsole::InpEvent( const int t0, const int t1, const int t2 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[4];
    static_QUType_int.set(o+1,t0);
    static_QUType_int.set(o+2,t1);
    static_QUType_int.set(o+3,t2);
    activate_signal( clist, o );
}

// SIGNAL sendFeedBack
void VirtualConsole::sendFeedBack()
{
    activate_signal( staticMetaObject()->signalOffset() + 2 );
}

// SIGNAL keyPressed
void VirtualConsole::keyPressed( QKeyEvent* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

// SIGNAL keyReleased
void VirtualConsole::keyReleased( QKeyEvent* t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 4 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,t0);
    activate_signal( clist, o );
}

bool VirtualConsole::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotDockAreaHidden((bool)static_QUType_bool.get(_o+1)); break;
    case 1: slotModeChanged(); break;
    case 2: slotAddButton(); break;
    case 3: slotAddSlider(); break;
    case 4: slotAddFrame(); break;
    case 5: slotAddLabel(); break;
    case 6: slotAddXYPad(); break;
    case 7: slotToolsSliders(); break;
    case 8: slotToolsSettings(); break;
    case 9: slotToolsPanic(); break;
    case 10: slotEditCut(); break;
    case 11: slotEditCopy(); break;
    case 12: slotEditPaste(); break;
    case 13: slotEditDelete(); break;
    case 14: slotEditProperties(); break;
    case 15: slotEditRename(); break;
    case 16: slotEditRenameReturnPressed(); break;
    case 17: slotEditRenameCancelled(); break;
    case 18: slotForegroundFont(); break;
    case 19: slotForegroundColor(); break;
    case 20: slotForegroundNone(); break;
    case 21: slotBackgroundColor(); break;
    case 22: slotBackgroundImage(); break;
    case 23: slotBackgroundNone(); break;
    case 24: slotBackgroundFrame(); break;
    case 25: slotStackingRaise(); break;
    case 26: slotStackingLower(); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VirtualConsole::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed(); break;
    case 1: InpEvent((const int)static_QUType_int.get(_o+1),(const int)static_QUType_int.get(_o+2),(const int)static_QUType_int.get(_o+3)); break;
    case 2: sendFeedBack(); break;
    case 3: keyPressed((QKeyEvent*)static_QUType_ptr.get(_o+1)); break;
    case 4: keyReleased((QKeyEvent*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool VirtualConsole::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool VirtualConsole::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
