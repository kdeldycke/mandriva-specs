/****************************************************************************
** Doc meta object code from reading C++ file 'doc.h'
**
** Created: Thu Nov 30 00:57:35 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "doc.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *Doc::className() const
{
    return "Doc";
}

QMetaObject *Doc::metaObj = 0;
static QMetaObjectCleanUp cleanUp_Doc( "Doc", &Doc::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString Doc::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Doc", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString Doc::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "Doc", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* Doc::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUMethod slot_0 = {"slotModeChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotModeChanged()", &slot_0, QMetaData::Private }
    };
    static const QUParameter param_signal_0[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod signal_0 = {"deviceAdded", 1, param_signal_0 };
    static const QUParameter param_signal_1[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod signal_1 = {"deviceRemoved", 1, param_signal_1 };
    static const QUParameter param_signal_2[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod signal_2 = {"deviceChanged", 1, param_signal_2 };
    static const QUParameter param_signal_3[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod signal_3 = {"functionAdded", 1, param_signal_3 };
    static const QUParameter param_signal_4[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod signal_4 = {"functionRemoved", 1, param_signal_4 };
    static const QUParameter param_signal_5[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod signal_5 = {"functionChanged", 1, param_signal_5 };
    static const QMetaData signal_tbl[] = {
	{ "deviceAdded(t_device_id)", &signal_0, QMetaData::Private },
	{ "deviceRemoved(t_device_id)", &signal_1, QMetaData::Private },
	{ "deviceChanged(t_device_id)", &signal_2, QMetaData::Private },
	{ "functionAdded(t_function_id)", &signal_3, QMetaData::Private },
	{ "functionRemoved(t_function_id)", &signal_4, QMetaData::Private },
	{ "functionChanged(t_function_id)", &signal_5, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"Doc", parentObject,
	slot_tbl, 1,
	signal_tbl, 6,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_Doc.setMetaObject( metaObj );
    return metaObj;
}

void* Doc::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "Doc" ) )
	return this;
    return QObject::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL deviceAdded
void Doc::deviceAdded( t_device_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL deviceRemoved
void Doc::deviceRemoved( t_device_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 1 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL deviceChanged
void Doc::deviceChanged( t_device_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 2 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL functionAdded
void Doc::functionAdded( t_function_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 3 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL functionRemoved
void Doc::functionRemoved( t_function_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 4 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

// SIGNAL functionChanged
void Doc::functionChanged( t_function_id t0 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 5 );
    if ( !clist )
	return;
    QUObject o[2];
    static_QUType_ptr.set(o+1,&t0);
    activate_signal( clist, o );
}

bool Doc::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotModeChanged(); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool Doc::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: deviceAdded((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 1: deviceRemoved((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 2: deviceChanged((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 3: functionAdded((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 4: functionRemoved((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 5: functionChanged((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    default:
	return QObject::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool Doc::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool Doc::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
