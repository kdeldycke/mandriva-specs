/****************************************************************************
** SceneEditor meta object code from reading C++ file 'sceneeditor.h'
**
** Created: Thu Nov 30 00:57:49 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "sceneeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *SceneEditor::className() const
{
    return "SceneEditor";
}

QMetaObject *SceneEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_SceneEditor( "SceneEditor", &SceneEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString SceneEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SceneEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString SceneEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SceneEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* SceneEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_SceneEditor::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_ptr, "QListBoxItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSceneListContextMenu", 2, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_ptr, "t_channel", QUParameter::In },
	{ 0, &static_QUType_ptr, "t_value", QUParameter::In },
	{ 0, &static_QUType_ptr, "Scene::ValueType", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotChannelChanged", 3, param_slot_1 };
    static const QUMethod slot_2 = {"slotActivate", 0, 0 };
    static const QUMethod slot_3 = {"slotNew", 0, 0 };
    static const QUMethod slot_4 = {"slotStore", 0, 0 };
    static const QUMethod slot_5 = {"slotRemove", 0, 0 };
    static const QUMethod slot_6 = {"slotRename", 0, 0 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotFunctionAdded", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotFunctionRemoved", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotFunctionChanged", 1, param_slot_9 };
    static const QMetaData slot_tbl[] = {
	{ "slotSceneListContextMenu(QListBoxItem*,const QPoint&)", &slot_0, QMetaData::Public },
	{ "slotChannelChanged(t_channel,t_value,Scene::ValueType)", &slot_1, QMetaData::Public },
	{ "slotActivate()", &slot_2, QMetaData::Public },
	{ "slotNew()", &slot_3, QMetaData::Public },
	{ "slotStore()", &slot_4, QMetaData::Public },
	{ "slotRemove()", &slot_5, QMetaData::Public },
	{ "slotRename()", &slot_6, QMetaData::Public },
	{ "slotFunctionAdded(t_function_id)", &slot_7, QMetaData::Public },
	{ "slotFunctionRemoved(t_function_id)", &slot_8, QMetaData::Public },
	{ "slotFunctionChanged(t_function_id)", &slot_9, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "values", &static_QUType_ptr, "SceneValue", QUParameter::In },
	{ "channels", &static_QUType_ptr, "t_channel", QUParameter::In }
    };
    static const QUMethod signal_0 = {"sceneActivated", 2, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "sceneActivated(SceneValue*,t_channel)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"SceneEditor", parentObject,
	slot_tbl, 10,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_SceneEditor.setMetaObject( metaObj );
    return metaObj;
}

void* SceneEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "SceneEditor" ) )
	return this;
    return UI_SceneEditor::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL sceneActivated
void SceneEditor::sceneActivated( SceneValue* t0, t_channel t1 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[3];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_ptr.set(o+2,&t1);
    activate_signal( clist, o );
}

bool SceneEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSceneListContextMenu((QListBoxItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2))); break;
    case 1: slotChannelChanged((t_channel)(*((t_channel*)static_QUType_ptr.get(_o+1))),(t_value)(*((t_value*)static_QUType_ptr.get(_o+2))),(Scene::ValueType)(*((Scene::ValueType*)static_QUType_ptr.get(_o+3)))); break;
    case 2: slotActivate(); break;
    case 3: slotNew(); break;
    case 4: slotStore(); break;
    case 5: slotRemove(); break;
    case 6: slotRename(); break;
    case 7: slotFunctionAdded((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 8: slotFunctionRemoved((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 9: slotFunctionChanged((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    default:
	return UI_SceneEditor::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool SceneEditor::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: sceneActivated((SceneValue*)static_QUType_ptr.get(_o+1),(t_channel)(*((t_channel*)static_QUType_ptr.get(_o+2)))); break;
    default:
	return UI_SceneEditor::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool SceneEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_SceneEditor::qt_property( id, f, v);
}

bool SceneEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
