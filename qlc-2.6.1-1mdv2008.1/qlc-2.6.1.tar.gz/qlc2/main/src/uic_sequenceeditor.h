/****************************************************************************
** Form interface generated from reading ui file 'src/sequenceeditor.ui'
**
** Created: Thu Nov 30 00:55:03 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_SEQUENCEEDITOR_H
#define UI_SEQUENCEEDITOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QListView;
class QListViewItem;
class QFrame;
class QPushButton;
class QButtonGroup;
class QRadioButton;
class QCheckBox;

class UI_SequenceEditor : public QDialog
{
    Q_OBJECT

public:
    UI_SequenceEditor( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_SequenceEditor();

    QLabel* m_nameLabel;
    QLineEdit* m_name;
    QListView* m_list;
    QFrame* m_sliderContainer;
    QPushButton* m_insert;
    QPushButton* m_remove;
    QPushButton* m_raise;
    QPushButton* m_lower;
    QPushButton* m_sliders;
    QButtonGroup* m_runOrderGroup;
    QRadioButton* m_looping;
    QRadioButton* m_singleShot;
    QRadioButton* m_pingPong;
    QButtonGroup* m_directionGroup;
    QRadioButton* m_forward;
    QRadioButton* m_backward;
    QButtonGroup* m_advancedOptionGroup;
    QCheckBox* m_zeroEnabled;
    QFrame* m_line;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotInsert();
    virtual void slotRemove();
    virtual void slotRaise();
    virtual void slotLower();
    virtual void slotSelectionChanged(QListViewItem*);
    virtual void slotGeneratorButtonClicked();
    virtual void slotSlidersToggled(bool);
    virtual void slotItemRenamed(QListViewItem*, int, const QString&);
    virtual void slotOKClicked();
    virtual void slotCancelClicked();

protected:
    QVBoxLayout* UI_SequenceEditorLayout;
    QHBoxLayout* layout4;
    QHBoxLayout* layout9;
    QVBoxLayout* layout8;
    QVBoxLayout* layout8_2;
    QSpacerItem* spacer3;
    QHBoxLayout* layout6;
    QHBoxLayout* m_runOrderGroupLayout;
    QHBoxLayout* m_directionGroupLayout;
    QVBoxLayout* m_advancedOptionGroupLayout;
    QHBoxLayout* layout7;
    QSpacerItem* spacer3_2;

protected slots:
    virtual void languageChange();

};

#endif // UI_SEQUENCEEDITOR_H
