/****************************************************************************
** DeviceManagerView meta object code from reading C++ file 'devicemanagerview.h'
**
** Created: Thu Nov 30 00:57:32 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "devicemanagerview.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DeviceManagerView::className() const
{
    return "DeviceManagerView";
}

QMetaObject *DeviceManagerView::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DeviceManagerView( "DeviceManagerView", &DeviceManagerView::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DeviceManagerView::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceManagerView", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DeviceManagerView::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceManagerView", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DeviceManagerView::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotDeviceAdded", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotDeviceRemoved", 1, param_slot_1 };
    static const QUMethod slot_2 = {"slotAdd", 0, 0 };
    static const QUMethod slot_3 = {"slotRemove", 0, 0 };
    static const QUMethod slot_4 = {"slotClone", 0, 0 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotDoubleClicked", 1, param_slot_5 };
    static const QUMethod slot_6 = {"slotProperties", 0, 0 };
    static const QUMethod slot_7 = {"slotConsole", 0, 0 };
    static const QUMethod slot_8 = {"slotAutoFunction", 0, 0 };
    static const QUMethod slot_9 = {"slotModeChanged", 0, 0 };
    static const QUParameter param_slot_10[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotSelectionChanged", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotRightButtonClicked", 3, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotMenuCallBack", 1, param_slot_12 };
    static const QMetaData slot_tbl[] = {
	{ "slotDeviceAdded(t_device_id)", &slot_0, QMetaData::Public },
	{ "slotDeviceRemoved(t_device_id)", &slot_1, QMetaData::Public },
	{ "slotAdd()", &slot_2, QMetaData::Protected },
	{ "slotRemove()", &slot_3, QMetaData::Protected },
	{ "slotClone()", &slot_4, QMetaData::Protected },
	{ "slotDoubleClicked(QListViewItem*)", &slot_5, QMetaData::Protected },
	{ "slotProperties()", &slot_6, QMetaData::Protected },
	{ "slotConsole()", &slot_7, QMetaData::Protected },
	{ "slotAutoFunction()", &slot_8, QMetaData::Protected },
	{ "slotModeChanged()", &slot_9, QMetaData::Protected },
	{ "slotSelectionChanged(QListViewItem*)", &slot_10, QMetaData::Protected },
	{ "slotRightButtonClicked(QListViewItem*,const QPoint&,int)", &slot_11, QMetaData::Protected },
	{ "slotMenuCallBack(int)", &slot_12, QMetaData::Protected }
    };
    static const QUMethod signal_0 = {"closed", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "closed()", &signal_0, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"DeviceManagerView", parentObject,
	slot_tbl, 13,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DeviceManagerView.setMetaObject( metaObj );
    return metaObj;
}

void* DeviceManagerView::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DeviceManagerView" ) )
	return this;
    return QWidget::qt_cast( clname );
}

// SIGNAL closed
void DeviceManagerView::closed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool DeviceManagerView::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotDeviceAdded((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 1: slotDeviceRemoved((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 2: slotAdd(); break;
    case 3: slotRemove(); break;
    case 4: slotClone(); break;
    case 5: slotDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 6: slotProperties(); break;
    case 7: slotConsole(); break;
    case 8: slotAutoFunction(); break;
    case 9: slotModeChanged(); break;
    case 10: slotSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 11: slotRightButtonClicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 12: slotMenuCallBack((int)static_QUType_int.get(_o+1)); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DeviceManagerView::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed(); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool DeviceManagerView::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool DeviceManagerView::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
