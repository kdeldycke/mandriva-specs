/****************************************************************************
** Form interface generated from reading ui file 'src/consolechannel.ui'
**
** Created: Thu Nov 30 00:54:45 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_CONSOLECHANNEL_H
#define UI_CONSOLECHANNEL_H

#include <qvariant.h>
#include <qframe.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QPushButton;
class QLabel;
class QSlider;

class UI_ConsoleChannel : public QFrame
{
    Q_OBJECT

public:
    UI_ConsoleChannel( QWidget* parent = 0, const char* name = 0 );
    ~UI_ConsoleChannel();

    QPushButton* m_presetButton;
    QLabel* m_valueLabel;
    QSlider* m_valueSlider;
    QPushButton* m_statusButton;
    QLabel* m_numberLabel;

protected:
    QVBoxLayout* UI_ConsoleChannelLayout;

protected slots:
    virtual void languageChange();

};

#endif // UI_CONSOLECHANNEL_H
