/****************************************************************************
** PatternGenerator meta object code from reading C++ file 'patterngenerator.h'
**
** Created: Thu Nov 30 00:57:47 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "patterngenerator.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *PatternGenerator::className() const
{
    return "PatternGenerator";
}

QMetaObject *PatternGenerator::metaObj = 0;
static QMetaObjectCleanUp cleanUp_PatternGenerator( "PatternGenerator", &PatternGenerator::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString PatternGenerator::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PatternGenerator", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString PatternGenerator::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PatternGenerator", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* PatternGenerator::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_PatternGenerator::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotPatternSelected", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotWidthSpinChanged", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotHeightSpinChanged", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotXOffsetSpinChanged", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotYOffsetSpinChanged", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotDensitySpinChanged", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"slotOrientationChanged", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotOmegaXChanged", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotOmegaYChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotPhaseXChanged", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotPhaseYChanged", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotHorizontalChannelSelected", 1, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotVerticalChannelSelected", 1, param_slot_12 };
    static const QMetaData slot_tbl[] = {
	{ "slotPatternSelected(const QString&)", &slot_0, QMetaData::Public },
	{ "slotWidthSpinChanged(int)", &slot_1, QMetaData::Public },
	{ "slotHeightSpinChanged(int)", &slot_2, QMetaData::Public },
	{ "slotXOffsetSpinChanged(int)", &slot_3, QMetaData::Public },
	{ "slotYOffsetSpinChanged(int)", &slot_4, QMetaData::Public },
	{ "slotDensitySpinChanged(int)", &slot_5, QMetaData::Public },
	{ "slotOrientationChanged(int)", &slot_6, QMetaData::Public },
	{ "slotOmegaXChanged(int)", &slot_7, QMetaData::Public },
	{ "slotOmegaYChanged(int)", &slot_8, QMetaData::Public },
	{ "slotPhaseXChanged(int)", &slot_9, QMetaData::Public },
	{ "slotPhaseYChanged(int)", &slot_10, QMetaData::Public },
	{ "slotHorizontalChannelSelected(int)", &slot_11, QMetaData::Public },
	{ "slotVerticalChannelSelected(int)", &slot_12, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"PatternGenerator", parentObject,
	slot_tbl, 13,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_PatternGenerator.setMetaObject( metaObj );
    return metaObj;
}

void* PatternGenerator::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "PatternGenerator" ) )
	return this;
    return UI_PatternGenerator::qt_cast( clname );
}

bool PatternGenerator::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotPatternSelected((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: slotWidthSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 2: slotHeightSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 3: slotXOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 4: slotYOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 5: slotDensitySpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 6: slotOrientationChanged((int)static_QUType_int.get(_o+1)); break;
    case 7: slotOmegaXChanged((int)static_QUType_int.get(_o+1)); break;
    case 8: slotOmegaYChanged((int)static_QUType_int.get(_o+1)); break;
    case 9: slotPhaseXChanged((int)static_QUType_int.get(_o+1)); break;
    case 10: slotPhaseYChanged((int)static_QUType_int.get(_o+1)); break;
    case 11: slotHorizontalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    case 12: slotVerticalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    default:
	return UI_PatternGenerator::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool PatternGenerator::qt_emit( int _id, QUObject* _o )
{
    return UI_PatternGenerator::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool PatternGenerator::qt_property( int id, int f, QVariant* v)
{
    return UI_PatternGenerator::qt_property( id, f, v);
}

bool PatternGenerator::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
