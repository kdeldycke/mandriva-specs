/****************************************************************************
** VCDockSlider meta object code from reading C++ file 'vcdockslider.h'
**
** Created: Thu Nov 30 00:57:55 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "vcdockslider.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VCDockSlider::className() const
{
    return "VCDockSlider";
}

QMetaObject *VCDockSlider::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCDockSlider( "VCDockSlider", &VCDockSlider::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCDockSlider::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCDockSlider", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCDockSlider::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCDockSlider", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCDockSlider::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_VCDockSlider::staticMetaObject();
    static const QUMethod slot_0 = {"pressUp", 0, 0 };
    static const QUMethod slot_1 = {"pressDown", 0, 0 };
    static const QUMethod slot_2 = {"slotFeedBack", 0, 0 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotInputEvent", 3, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotSliderValueChanged", 1, param_slot_4 };
    static const QUMethod slot_5 = {"slotTapInButtonClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotModeChanged", 0, 0 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_ptr, "t_bus_id", QUParameter::In },
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotBusNameChanged", 2, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_ptr, "t_bus_id", QUParameter::In },
	{ 0, &static_QUType_ptr, "t_bus_value", QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotBusValueChanged", 2, param_slot_8 };
    static const QMetaData slot_tbl[] = {
	{ "pressUp()", &slot_0, QMetaData::Public },
	{ "pressDown()", &slot_1, QMetaData::Public },
	{ "slotFeedBack()", &slot_2, QMetaData::Public },
	{ "slotInputEvent(const int,const int,const int)", &slot_3, QMetaData::Public },
	{ "slotSliderValueChanged(const int)", &slot_4, QMetaData::Private },
	{ "slotTapInButtonClicked()", &slot_5, QMetaData::Private },
	{ "slotModeChanged()", &slot_6, QMetaData::Private },
	{ "slotBusNameChanged(t_bus_id,const QString&)", &slot_7, QMetaData::Private },
	{ "slotBusValueChanged(t_bus_id,t_bus_value)", &slot_8, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"VCDockSlider", parentObject,
	slot_tbl, 9,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCDockSlider.setMetaObject( metaObj );
    return metaObj;
}

void* VCDockSlider::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCDockSlider" ) )
	return this;
    return UI_VCDockSlider::qt_cast( clname );
}

bool VCDockSlider::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: pressUp(); break;
    case 1: pressDown(); break;
    case 2: slotFeedBack(); break;
    case 3: slotInputEvent((const int)static_QUType_int.get(_o+1),(const int)static_QUType_int.get(_o+2),(const int)static_QUType_int.get(_o+3)); break;
    case 4: slotSliderValueChanged((const int)static_QUType_int.get(_o+1)); break;
    case 5: slotTapInButtonClicked(); break;
    case 6: slotModeChanged(); break;
    case 7: slotBusNameChanged((t_bus_id)(*((t_bus_id*)static_QUType_ptr.get(_o+1))),(const QString&)static_QUType_QString.get(_o+2)); break;
    case 8: slotBusValueChanged((t_bus_id)(*((t_bus_id*)static_QUType_ptr.get(_o+1))),(t_bus_value)(*((t_bus_value*)static_QUType_ptr.get(_o+2)))); break;
    default:
	return UI_VCDockSlider::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VCDockSlider::qt_emit( int _id, QUObject* _o )
{
    return UI_VCDockSlider::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCDockSlider::qt_property( int id, int f, QVariant* v)
{
    return UI_VCDockSlider::qt_property( id, f, v);
}

bool VCDockSlider::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
