/****************************************************************************
** Form implementation generated from reading ui file 'src/chasereditor.ui'
**
** Created: Thu Nov 30 00:54:43 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_chasereditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qheader.h>
#include <qlistview.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qframe.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_ChaserEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_ChaserEditor::UI_ChaserEditor( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_ChaserEditor" );
    UI_ChaserEditorLayout = new QVBoxLayout( this, 11, 6, "UI_ChaserEditorLayout"); 

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_nameLabel = new QLabel( this, "m_nameLabel" );
    layout4->addWidget( m_nameLabel );

    m_nameEdit = new QLineEdit( this, "m_nameEdit" );
    layout4->addWidget( m_nameEdit );
    UI_ChaserEditorLayout->addLayout( layout4 );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_stepList = new QListView( this, "m_stepList" );
    m_stepList->addColumn( tr( "Step" ) );
    m_stepList->header()->setClickEnabled( FALSE, m_stepList->header()->count() - 1 );
    m_stepList->addColumn( tr( "Device" ) );
    m_stepList->header()->setClickEnabled( FALSE, m_stepList->header()->count() - 1 );
    m_stepList->addColumn( tr( "Function" ) );
    m_stepList->header()->setClickEnabled( FALSE, m_stepList->header()->count() - 1 );
    m_stepList->setAllColumnsShowFocus( TRUE );
    m_stepList->setResizeMode( QListView::AllColumns );
    layout9->addWidget( m_stepList );

    layout8 = new QVBoxLayout( 0, 0, 6, "layout8"); 

    m_addStep = new QPushButton( this, "m_addStep" );
    m_addStep->setMaximumSize( QSize( 30, 30 ) );
    layout8->addWidget( m_addStep );

    m_removeStep = new QPushButton( this, "m_removeStep" );
    m_removeStep->setMaximumSize( QSize( 30, 30 ) );
    layout8->addWidget( m_removeStep );

    m_raiseButton = new QPushButton( this, "m_raiseButton" );
    m_raiseButton->setMaximumSize( QSize( 30, 30 ) );
    layout8->addWidget( m_raiseButton );

    m_lowerButton = new QPushButton( this, "m_lowerButton" );
    m_lowerButton->setMaximumSize( QSize( 30, 30 ) );
    layout8->addWidget( m_lowerButton );
    spacer2 = new QSpacerItem( 20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout8->addItem( spacer2 );
    layout9->addLayout( layout8 );
    UI_ChaserEditorLayout->addLayout( layout9 );

    layout13 = new QHBoxLayout( 0, 0, 6, "layout13"); 

    m_runOrderGroup = new QButtonGroup( this, "m_runOrderGroup" );
    m_runOrderGroup->setColumnLayout(0, Qt::Vertical );
    m_runOrderGroup->layout()->setSpacing( 6 );
    m_runOrderGroup->layout()->setMargin( 11 );
    m_runOrderGroupLayout = new QHBoxLayout( m_runOrderGroup->layout() );
    m_runOrderGroupLayout->setAlignment( Qt::AlignTop );

    m_looping = new QRadioButton( m_runOrderGroup, "m_looping" );
    m_looping->setChecked( TRUE );
    m_runOrderGroupLayout->addWidget( m_looping );

    m_singleShot = new QRadioButton( m_runOrderGroup, "m_singleShot" );
    m_runOrderGroupLayout->addWidget( m_singleShot );

    m_pingPong = new QRadioButton( m_runOrderGroup, "m_pingPong" );
    m_runOrderGroup->insert( m_pingPong, 2 );
    m_runOrderGroupLayout->addWidget( m_pingPong );
    layout13->addWidget( m_runOrderGroup );

    m_directionGroup = new QButtonGroup( this, "m_directionGroup" );
    m_directionGroup->setProperty( "selectedId", -1 );
    m_directionGroup->setColumnLayout(0, Qt::Vertical );
    m_directionGroup->layout()->setSpacing( 6 );
    m_directionGroup->layout()->setMargin( 11 );
    m_directionGroupLayout = new QHBoxLayout( m_directionGroup->layout() );
    m_directionGroupLayout->setAlignment( Qt::AlignTop );

    m_forward = new QRadioButton( m_directionGroup, "m_forward" );
    m_directionGroup->insert( m_forward, 0 );
    m_directionGroupLayout->addWidget( m_forward );

    m_backward = new QRadioButton( m_directionGroup, "m_backward" );
    m_directionGroup->insert( m_backward, 1 );
    m_directionGroupLayout->addWidget( m_backward );
    layout13->addWidget( m_directionGroup );
    UI_ChaserEditorLayout->addLayout( layout13 );

    line2 = new QFrame( this, "line2" );
    line2->setFrameShape( QFrame::HLine );
    line2->setFrameShadow( QFrame::Sunken );
    line2->setFrameShape( QFrame::HLine );
    UI_ChaserEditorLayout->addWidget( line2 );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 
    spacer3 = new QSpacerItem( 310, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout6->addItem( spacer3 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout6->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout6->addWidget( m_cancel );
    UI_ChaserEditorLayout->addLayout( layout6 );
    languageChange();
    resize( QSize(524, 391).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_addStep, SIGNAL( clicked() ), this, SLOT( slotAddClicked() ) );
    connect( m_removeStep, SIGNAL( clicked() ), this, SLOT( slotRemoveClicked() ) );
    connect( m_raiseButton, SIGNAL( clicked() ), this, SLOT( slotRaiseClicked() ) );
    connect( m_lowerButton, SIGNAL( clicked() ), this, SLOT( slotLowerClicked() ) );

    // tab order
    setTabOrder( m_nameEdit, m_stepList );
    setTabOrder( m_stepList, m_looping );
    setTabOrder( m_looping, m_addStep );
    setTabOrder( m_addStep, m_removeStep );
    setTabOrder( m_removeStep, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_ChaserEditor::~UI_ChaserEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_ChaserEditor::languageChange()
{
    setCaption( tr( "Chaser Editor" ) );
    m_nameLabel->setText( tr( "Chaser Name:" ) );
    QToolTip::add( m_nameEdit, tr( "Chaser name" ) );
    m_stepList->header()->setLabel( 0, tr( "Step" ) );
    m_stepList->header()->setLabel( 1, tr( "Device" ) );
    m_stepList->header()->setLabel( 2, tr( "Function" ) );
    QToolTip::add( m_stepList, tr( "Functions assigned to this chaser" ) );
    m_addStep->setText( tr( "+" ) );
    m_addStep->setAccel( QKeySequence( tr( "Ins" ) ) );
    QToolTip::add( m_addStep, tr( "Add new step" ) );
    m_removeStep->setText( tr( "X" ) );
    m_removeStep->setAccel( QKeySequence( tr( "Del" ) ) );
    QToolTip::add( m_removeStep, tr( "Remove selected step" ) );
    m_raiseButton->setText( tr( "/\\" ) );
    m_raiseButton->setAccel( QKeySequence( QString::null ) );
    QToolTip::add( m_raiseButton, tr( "Raise selected step" ) );
    m_lowerButton->setText( tr( "\\/" ) );
    QToolTip::add( m_lowerButton, tr( "Lower selected step" ) );
    m_runOrderGroup->setTitle( tr( "Run Order" ) );
    m_looping->setText( tr( "&Loop" ) );
    m_looping->setAccel( QKeySequence( tr( "Alt+L" ) ) );
    QToolTip::add( m_looping, tr( "Loop forever" ) );
    m_singleShot->setText( tr( "&Single Shot" ) );
    m_singleShot->setAccel( QKeySequence( tr( "Alt+S" ) ) );
    QToolTip::add( m_singleShot, tr( "Stop after the last step" ) );
    m_pingPong->setText( tr( "&Ping Pong" ) );
    m_pingPong->setAccel( QKeySequence( tr( "Alt+P" ) ) );
    QToolTip::add( m_pingPong, tr( "Run forever reversing the direction in both ends" ) );
    m_directionGroup->setTitle( tr( "Direction" ) );
    m_forward->setText( tr( "Forward" ) );
    QToolTip::add( m_forward, tr( "Run from first to last" ) );
    m_backward->setText( tr( "Backward" ) );
    QToolTip::add( m_backward, tr( "Run from last to first" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_ChaserEditor::slotAddClicked()
{
    qWarning( "UI_ChaserEditor::slotAddClicked(): Not implemented yet" );
}

void UI_ChaserEditor::slotCancelClicked()
{
    qWarning( "UI_ChaserEditor::slotCancelClicked(): Not implemented yet" );
}

void UI_ChaserEditor::slotLowerClicked()
{
    qWarning( "UI_ChaserEditor::slotLowerClicked(): Not implemented yet" );
}

void UI_ChaserEditor::slotOKClicked()
{
    qWarning( "UI_ChaserEditor::slotOKClicked(): Not implemented yet" );
}

void UI_ChaserEditor::slotRaiseClicked()
{
    qWarning( "UI_ChaserEditor::slotRaiseClicked(): Not implemented yet" );
}

void UI_ChaserEditor::slotRemoveClicked()
{
    qWarning( "UI_ChaserEditor::slotRemoveClicked(): Not implemented yet" );
}

