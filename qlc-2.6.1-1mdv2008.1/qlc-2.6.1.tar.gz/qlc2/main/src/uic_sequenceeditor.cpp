/****************************************************************************
** Form implementation generated from reading ui file 'src/sequenceeditor.ui'
**
** Created: Thu Nov 30 00:55:03 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_sequenceeditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qheader.h>
#include <qlistview.h>
#include <qframe.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_SequenceEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_SequenceEditor::UI_SequenceEditor( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_SequenceEditor" );
    UI_SequenceEditorLayout = new QVBoxLayout( this, 11, 6, "UI_SequenceEditorLayout"); 

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_nameLabel = new QLabel( this, "m_nameLabel" );
    layout4->addWidget( m_nameLabel );

    m_name = new QLineEdit( this, "m_name" );
    layout4->addWidget( m_name );
    UI_SequenceEditorLayout->addLayout( layout4 );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    layout8 = new QVBoxLayout( 0, 0, 6, "layout8"); 

    m_list = new QListView( this, "m_list" );
    m_list->setAllColumnsShowFocus( TRUE );
    m_list->setDefaultRenameAction( QListView::Accept );
    layout8->addWidget( m_list );

    m_sliderContainer = new QFrame( this, "m_sliderContainer" );
    m_sliderContainer->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)5, 0, 0, m_sliderContainer->sizePolicy().hasHeightForWidth() ) );
    m_sliderContainer->setMinimumSize( QSize( 20, 200 ) );
    m_sliderContainer->setMaximumSize( QSize( 32767, 200 ) );
    m_sliderContainer->setFrameShape( QFrame::NoFrame );
    m_sliderContainer->setFrameShadow( QFrame::Plain );
    layout8->addWidget( m_sliderContainer );
    layout9->addLayout( layout8 );

    layout8_2 = new QVBoxLayout( 0, 0, 6, "layout8_2"); 

    m_insert = new QPushButton( this, "m_insert" );
    m_insert->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)1, 0, 0, m_insert->sizePolicy().hasHeightForWidth() ) );
    m_insert->setMinimumSize( QSize( 30, 30 ) );
    m_insert->setMaximumSize( QSize( 30, 30 ) );
    layout8_2->addWidget( m_insert );

    m_remove = new QPushButton( this, "m_remove" );
    m_remove->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)1, 0, 0, m_remove->sizePolicy().hasHeightForWidth() ) );
    m_remove->setMinimumSize( QSize( 30, 30 ) );
    m_remove->setMaximumSize( QSize( 30, 30 ) );
    layout8_2->addWidget( m_remove );

    m_raise = new QPushButton( this, "m_raise" );
    m_raise->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, m_raise->sizePolicy().hasHeightForWidth() ) );
    m_raise->setMinimumSize( QSize( 30, 30 ) );
    m_raise->setMaximumSize( QSize( 30, 30 ) );
    layout8_2->addWidget( m_raise );

    m_lower = new QPushButton( this, "m_lower" );
    m_lower->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, m_lower->sizePolicy().hasHeightForWidth() ) );
    m_lower->setMinimumSize( QSize( 30, 30 ) );
    m_lower->setMaximumSize( QSize( 30, 30 ) );
    layout8_2->addWidget( m_lower );
    spacer3 = new QSpacerItem( 20, 110, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout8_2->addItem( spacer3 );

    m_sliders = new QPushButton( this, "m_sliders" );
    m_sliders->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, m_sliders->sizePolicy().hasHeightForWidth() ) );
    m_sliders->setMinimumSize( QSize( 30, 30 ) );
    m_sliders->setMaximumSize( QSize( 30, 30 ) );
    m_sliders->setToggleButton( TRUE );
    layout8_2->addWidget( m_sliders );
    layout9->addLayout( layout8_2 );
    UI_SequenceEditorLayout->addLayout( layout9 );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 

    m_runOrderGroup = new QButtonGroup( this, "m_runOrderGroup" );
    m_runOrderGroup->setProperty( "selectedId", -1 );
    m_runOrderGroup->setColumnLayout(0, Qt::Vertical );
    m_runOrderGroup->layout()->setSpacing( 6 );
    m_runOrderGroup->layout()->setMargin( 11 );
    m_runOrderGroupLayout = new QHBoxLayout( m_runOrderGroup->layout() );
    m_runOrderGroupLayout->setAlignment( Qt::AlignTop );

    m_looping = new QRadioButton( m_runOrderGroup, "m_looping" );
    m_runOrderGroupLayout->addWidget( m_looping );

    m_singleShot = new QRadioButton( m_runOrderGroup, "m_singleShot" );
    m_runOrderGroupLayout->addWidget( m_singleShot );

    m_pingPong = new QRadioButton( m_runOrderGroup, "m_pingPong" );
    m_runOrderGroupLayout->addWidget( m_pingPong );
    layout6->addWidget( m_runOrderGroup );

    m_directionGroup = new QButtonGroup( this, "m_directionGroup" );
    m_directionGroup->setProperty( "selectedId", -1 );
    m_directionGroup->setColumnLayout(0, Qt::Vertical );
    m_directionGroup->layout()->setSpacing( 6 );
    m_directionGroup->layout()->setMargin( 11 );
    m_directionGroupLayout = new QHBoxLayout( m_directionGroup->layout() );
    m_directionGroupLayout->setAlignment( Qt::AlignTop );

    m_forward = new QRadioButton( m_directionGroup, "m_forward" );
    m_directionGroupLayout->addWidget( m_forward );

    m_backward = new QRadioButton( m_directionGroup, "m_backward" );
    m_directionGroupLayout->addWidget( m_backward );
    layout6->addWidget( m_directionGroup );
    UI_SequenceEditorLayout->addLayout( layout6 );

    m_advancedOptionGroup = new QButtonGroup( this, "m_advancedOptionGroup" );
    m_advancedOptionGroup->setColumnLayout(0, Qt::Vertical );
    m_advancedOptionGroup->layout()->setSpacing( 6 );
    m_advancedOptionGroup->layout()->setMargin( 11 );
    m_advancedOptionGroupLayout = new QVBoxLayout( m_advancedOptionGroup->layout() );
    m_advancedOptionGroupLayout->setAlignment( Qt::AlignTop );

    m_zeroEnabled = new QCheckBox( m_advancedOptionGroup, "m_zeroEnabled" );
    m_advancedOptionGroupLayout->addWidget( m_zeroEnabled );
    UI_SequenceEditorLayout->addWidget( m_advancedOptionGroup );

    m_line = new QFrame( this, "m_line" );
    m_line->setFrameShape( QFrame::HLine );
    m_line->setFrameShadow( QFrame::Sunken );
    m_line->setFrameShape( QFrame::HLine );
    UI_SequenceEditorLayout->addWidget( m_line );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 
    spacer3_2 = new QSpacerItem( 351, 25, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout7->addItem( spacer3_2 );

    m_ok = new QPushButton( this, "m_ok" );
    layout7->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout7->addWidget( m_cancel );
    UI_SequenceEditorLayout->addLayout( layout7 );
    languageChange();
    resize( QSize(546, 582).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_insert, SIGNAL( clicked() ), this, SLOT( slotInsert() ) );
    connect( m_remove, SIGNAL( clicked() ), this, SLOT( slotRemove() ) );
    connect( m_raise, SIGNAL( clicked() ), this, SLOT( slotRaise() ) );
    connect( m_lower, SIGNAL( clicked() ), this, SLOT( slotLower() ) );
    connect( m_list, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotSelectionChanged(QListViewItem*) ) );
    connect( m_sliders, SIGNAL( toggled(bool) ), this, SLOT( slotSlidersToggled(bool) ) );
    connect( m_list, SIGNAL( itemRenamed(QListViewItem*,int,const QString&) ), this, SLOT( slotItemRenamed(QListViewItem*,int,const QString&) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_SequenceEditor::~UI_SequenceEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_SequenceEditor::languageChange()
{
    setCaption( tr( "Sequence Editor" ) );
    m_nameLabel->setText( tr( "Name:" ) );
    m_insert->setText( tr( "+" ) );
    QToolTip::add( m_insert, tr( "Insert" ) );
    m_remove->setText( tr( "-" ) );
    QToolTip::add( m_remove, tr( "Remove selected step" ) );
    m_raise->setText( tr( "/\\" ) );
    QToolTip::add( m_raise, tr( "Raise selected step up" ) );
    m_lower->setText( tr( "\\/" ) );
    QToolTip::add( m_lower, tr( "Lower selected step down" ) );
    m_sliders->setText( tr( "SL" ) );
    QToolTip::add( m_sliders, tr( "Toggle slider visibility" ) );
    m_runOrderGroup->setTitle( tr( "Run Order" ) );
    m_looping->setText( tr( "Loop" ) );
    m_singleShot->setText( tr( "Single Shot" ) );
    m_pingPong->setText( tr( "Ping Pong" ) );
    m_directionGroup->setTitle( tr( "Direction" ) );
    m_forward->setText( tr( "Forward" ) );
    m_backward->setText( tr( "Backward" ) );
    m_advancedOptionGroup->setTitle( tr( "Advanced" ) );
    m_zeroEnabled->setText( tr( "Set Channels to Zero After Stop" ) );
    QToolTip::add( m_zeroEnabled, tr( "Set all channels to zero when this sequence stops" ) );
    m_ok->setText( tr( "OK" ) );
    m_cancel->setText( tr( "Cancel" ) );
}

void UI_SequenceEditor::slotInsert()
{
    qWarning( "UI_SequenceEditor::slotInsert(): Not implemented yet" );
}

void UI_SequenceEditor::slotRemove()
{
    qWarning( "UI_SequenceEditor::slotRemove(): Not implemented yet" );
}

void UI_SequenceEditor::slotRaise()
{
    qWarning( "UI_SequenceEditor::slotRaise(): Not implemented yet" );
}

void UI_SequenceEditor::slotLower()
{
    qWarning( "UI_SequenceEditor::slotLower(): Not implemented yet" );
}

void UI_SequenceEditor::slotSelectionChanged(QListViewItem*)
{
    qWarning( "UI_SequenceEditor::slotSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_SequenceEditor::slotGeneratorButtonClicked()
{
    qWarning( "UI_SequenceEditor::slotGeneratorButtonClicked(): Not implemented yet" );
}

void UI_SequenceEditor::slotSlidersToggled(bool)
{
    qWarning( "UI_SequenceEditor::slotSlidersToggled(bool): Not implemented yet" );
}

void UI_SequenceEditor::slotItemRenamed(QListViewItem*,int,const QString&)
{
    qWarning( "UI_SequenceEditor::slotItemRenamed(QListViewItem*,int,const QString&): Not implemented yet" );
}

void UI_SequenceEditor::slotOKClicked()
{
    qWarning( "UI_SequenceEditor::slotOKClicked(): Not implemented yet" );
}

void UI_SequenceEditor::slotCancelClicked()
{
    qWarning( "UI_SequenceEditor::slotCancelClicked(): Not implemented yet" );
}

