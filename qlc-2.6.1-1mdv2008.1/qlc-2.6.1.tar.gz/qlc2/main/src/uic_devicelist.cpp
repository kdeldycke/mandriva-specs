/****************************************************************************
** Form implementation generated from reading ui file 'src/devicelist.ui'
**
** Created: Thu Nov 30 00:54:46 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_devicelist.h"

#include <qvariant.h>
#include <qgroupbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_DeviceList as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_DeviceList::UI_DeviceList( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_DeviceList" );
    UI_DeviceListLayout = new QVBoxLayout( this, 11, 6, "UI_DeviceListLayout"); 

    groupBox9 = new QGroupBox( this, "groupBox9" );
    groupBox9->setColumnLayout(0, Qt::Vertical );
    groupBox9->layout()->setSpacing( 6 );
    groupBox9->layout()->setMargin( 11 );
    groupBox9Layout = new QGridLayout( groupBox9->layout() );
    groupBox9Layout->setAlignment( Qt::AlignTop );

    m_listView = new QListView( groupBox9, "m_listView" );
    m_listView->addColumn( tr( "Device" ) );
    m_listView->addColumn( tr( "Channel" ) );
    m_listView->setAllColumnsShowFocus( TRUE );
    m_listView->setResizeMode( QListView::AllColumns );

    groupBox9Layout->addWidget( m_listView, 0, 0 );
    UI_DeviceListLayout->addWidget( groupBox9 );

    layout24 = new QHBoxLayout( 0, 0, 6, "layout24"); 
    spacer3 = new QSpacerItem( 448, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout24->addItem( spacer3 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout24->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout24->addWidget( m_cancel );
    UI_DeviceListLayout->addLayout( layout24 );
    languageChange();
    resize( QSize(502, 385).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_listView, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotSelectionChanged(QListViewItem*) ) );
    connect( m_listView, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotItemDoubleClicked(QListViewItem*) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_DeviceList::~UI_DeviceList()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_DeviceList::languageChange()
{
    setCaption( tr( "Device List" ) );
    groupBox9->setTitle( tr( "Devices" ) );
    m_listView->header()->setLabel( 0, tr( "Device" ) );
    m_listView->header()->setLabel( 1, tr( "Channel" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_DeviceList::slotSelectionChanged(QListViewItem*)
{
    qWarning( "UI_DeviceList::slotSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_DeviceList::slotItemDoubleClicked(QListViewItem*)
{
    qWarning( "UI_DeviceList::slotItemDoubleClicked(QListViewItem*): Not implemented yet" );
}

