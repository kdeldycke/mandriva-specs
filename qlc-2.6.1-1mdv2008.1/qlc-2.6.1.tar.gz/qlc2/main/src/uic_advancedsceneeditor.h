/****************************************************************************
** Form interface generated from reading ui file 'src/advancedsceneeditor.ui'
**
** Created: Thu Nov 30 00:54:38 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_ADVANCEDSCENEEDITOR_H
#define UI_ADVANCEDSCENEEDITOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QListView;
class QListViewItem;
class QPushButton;

class UI_AdvancedSceneEditor : public QDialog
{
    Q_OBJECT

public:
    UI_AdvancedSceneEditor( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_AdvancedSceneEditor();

    QLabel* m_sceneNameLabel;
    QLineEdit* m_sceneNameEdit;
    QListView* m_sceneContents;
    QPushButton* m_editValue;
    QPushButton* m_applyButton;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotChannelsContextMenuRequested(QListViewItem*, const QPoint &, int);
    virtual void slotAddSceneClicked();
    virtual void slotApplyClicked();
    virtual void slotCancelClicked();
    virtual void slotContentsClicked(QListViewItem*);
    virtual void slotContentsDoubleClicked(QListViewItem*);
    virtual void slotEditSceneNameClicked();
    virtual void slotEditValueClicked();
    virtual void slotOKClicked();
    virtual void slotOutputDeviceActivated(const QString&);
    virtual void slotRemoveSceneClicked();
    virtual void slotSceneDoubleClicked(QListViewItem*);
    virtual void slotSceneNameTextChanged(const QString&);
    virtual void slotSceneSelected(QListViewItem*);
    virtual void slotStoreButtonClicked();
    virtual void slotStoreSceneInGroupClicked(int);
    virtual void slotItemRenamed(QListViewItem*, int);

protected:
    QVBoxLayout* UI_AdvancedSceneEditorLayout;
    QHBoxLayout* layout8;
    QHBoxLayout* layout7;
    QSpacerItem* spacer4;

protected slots:
    virtual void languageChange();

};

#endif // UI_ADVANCEDSCENEEDITOR_H
