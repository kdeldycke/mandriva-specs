/****************************************************************************
** Form interface generated from reading ui file 'src/settings.ui'
**
** Created: Thu Nov 30 00:55:05 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_SETTINGS_H
#define UI_SETTINGS_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLineEdit;
class QPushButton;
class QLabel;
class QComboBox;
class QSpinBox;
class QListView;
class QListViewItem;
class QCheckBox;

class UI_Settings : public QDialog
{
    Q_OBJECT

public:
    UI_Settings( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_Settings();

    QGroupBox* m_backgroundGroupBox;
    QLineEdit* m_backgroundEdit;
    QPushButton* m_backgroundBrowse;
    QGroupBox* GroupBox4;
    QLabel* m_widgetStyleLabel;
    QComboBox* m_widgetStyleCombo;
    QLabel* m_MRUSizeLabel;
    QSpinBox* m_MRUSizeSpin;
    QPushButton* m_ok;
    QPushButton* m_cancel;
    QGroupBox* groupBox7;
    QListView* m_advancedList;
    QGroupBox* m_startupGroupBox;
    QCheckBox* m_openLastWorkspaceCheckBox;
    QGroupBox* groupBox6;
    QLabel* textLabel1;
    QLabel* textLabel2;
    QComboBox* m_outputPluginCombo;
    QComboBox* m_inputPluginCombo;
    QPushButton* m_configureInputPlugin;
    QPushButton* m_configureOutputPlugin;

public slots:
    virtual void slotCancelClicked();
    virtual void slotOKClicked();
    virtual void slotStyleChanged( const QString & );
    virtual void slotBackgroundBrowseClicked();
    virtual void slotConfigureOutputPluginClicked();
    virtual void slotConfigureInputPluginClicked();

protected:
    QGridLayout* UI_SettingsLayout;
    QVBoxLayout* m_backgroundGroupBoxLayout;
    QHBoxLayout* layout9;
    QVBoxLayout* GroupBox4Layout;
    QHBoxLayout* layout5;
    QHBoxLayout* layout4;
    QSpacerItem* spacer1;
    QHBoxLayout* layout4_2;
    QGridLayout* groupBox7Layout;
    QHBoxLayout* m_startupGroupBoxLayout;
    QGridLayout* groupBox6Layout;

protected slots:
    virtual void languageChange();

};

#endif // UI_SETTINGS_H
