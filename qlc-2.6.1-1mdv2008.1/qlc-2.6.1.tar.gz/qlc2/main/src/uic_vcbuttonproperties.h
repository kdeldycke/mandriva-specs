/****************************************************************************
** Form interface generated from reading ui file 'src/vcbuttonproperties.ui'
**
** Created: Thu Nov 30 00:55:07 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VCBUTTONPROPERTIES_H
#define UI_VCBUTTONPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLabel;
class QLineEdit;
class QPushButton;
class QComboBox;
class QSpinBox;
class QButtonGroup;
class QRadioButton;
class QCheckBox;

class UI_VCButtonProperties : public QDialog
{
    Q_OBJECT

public:
    UI_VCButtonProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_VCButtonProperties();

    QGroupBox* m_generalInfoGroup;
    QLabel* m_nameLabel;
    QLineEdit* m_nameEdit;
    QLabel* m_functionLabel;
    QLineEdit* m_functionEdit;
    QPushButton* m_attachFunction;
    QPushButton* m_detachFunction;
    QGroupBox* m_keyboardHotkeyGroup;
    QLabel* m_keyLabel;
    QLineEdit* m_keyEdit;
    QPushButton* m_attachKey;
    QPushButton* m_detachKey;
    QGroupBox* m_IDLabel;
    QLabel* m_keyLabel_2;
    QComboBox* m_IDCombo;
    QLabel* m_channelLabel;
    QSpinBox* m_channelSpinBox;
    QButtonGroup* m_onButtonPressGroup;
    QRadioButton* m_toggle;
    QRadioButton* m_flash;
    QRadioButton* m_forward;
    QRadioButton* m_backward;
    QGroupBox* m_experimental;
    QCheckBox* m_stopFunctionsCheck;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotCancelClicked();
    virtual void slotAttachFunctionClicked();
    virtual void slotDetachFunctionClicked();
    virtual void slotAttachKeyClicked();
    virtual void slotDetachKeyClicked();
    virtual void slotOKClicked();
    virtual void slotPressGroupClicked(int);

protected:
    QVBoxLayout* UI_VCButtonPropertiesLayout;
    QVBoxLayout* m_generalInfoGroupLayout;
    QHBoxLayout* layout8;
    QHBoxLayout* layout7;
    QHBoxLayout* m_keyboardHotkeyGroupLayout;
    QGridLayout* m_IDLabelLayout;
    QVBoxLayout* m_experimentalLayout;
    QHBoxLayout* layout9;
    QSpacerItem* spacer8;

protected slots:
    virtual void languageChange();

};

#endif // UI_VCBUTTONPROPERTIES_H
