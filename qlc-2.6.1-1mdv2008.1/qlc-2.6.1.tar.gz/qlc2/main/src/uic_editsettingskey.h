/****************************************************************************
** Form interface generated from reading ui file 'src/editsettingskey.ui'
**
** Created: Thu Nov 30 00:54:52 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_EDITSETTINGSKEY_H
#define UI_EDITSETTINGSKEY_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QButtonGroup;
class QRadioButton;
class QPushButton;

class UI_EditSettingsKey : public QWidget
{
    Q_OBJECT

public:
    UI_EditSettingsKey( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~UI_EditSettingsKey();

    QLabel* textLabel1;
    QLineEdit* m_keyEdit;
    QLabel* textLabel2;
    QLineEdit* m_valueEdit;
    QButtonGroup* m_typeGroup;
    QRadioButton* m_integerRadio;
    QRadioButton* m_textRadio;
    QPushButton* m_okButton;
    QPushButton* m_cancelButton;

protected:
    QVBoxLayout* UI_EditSettingsKeyLayout;
    QHBoxLayout* layout4;
    QVBoxLayout* layout1;
    QVBoxLayout* layout2;
    QHBoxLayout* m_typeGroupLayout;
    QHBoxLayout* layout5;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

};

#endif // UI_EDITSETTINGSKEY_H
