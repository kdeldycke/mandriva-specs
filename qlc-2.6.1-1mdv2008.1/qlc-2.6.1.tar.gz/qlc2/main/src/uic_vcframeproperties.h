/****************************************************************************
** Form interface generated from reading ui file 'src/vcframeproperties.ui'
**
** Created: Thu Nov 30 00:55:13 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VCFRAMEPROPERTIES_H
#define UI_VCFRAMEPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QButtonGroup;
class QRadioButton;
class QPushButton;

class UI_VCFrameProperties : public QDialog
{
    Q_OBJECT

public:
    UI_VCFrameProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_VCFrameProperties();

    QButtonGroup* m_behaviourGroup;
    QRadioButton* m_normal;
    QRadioButton* m_exclusive;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotOKClicked();
    virtual void slotCancelClicked();

protected:
    QVBoxLayout* UI_VCFramePropertiesLayout;
    QVBoxLayout* m_behaviourGroupLayout;
    QHBoxLayout* layout1;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

};

#endif // UI_VCFRAMEPROPERTIES_H
