/****************************************************************************
** Form implementation generated from reading ui file 'src/sceneeditor.ui'
**
** Created: Thu Nov 30 00:55:01 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_sceneeditor.h"

#include <qvariant.h>
#include <qtoolbutton.h>
#include <qlistbox.h>
#include <qlabel.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_SceneEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
UI_SceneEditor::UI_SceneEditor( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "UI_SceneEditor" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMaximumSize( QSize( 32767, 32767 ) );
    UI_SceneEditorLayout = new QVBoxLayout( this, 11, 6, "UI_SceneEditorLayout"); 

    m_tools = new QToolButton( this, "m_tools" );
    m_tools->setUsesTextLabel( TRUE );
    m_tools->setPopupDelay( 10 );
    m_tools->setTextPosition( QToolButton::Right );
    UI_SceneEditorLayout->addWidget( m_tools );

    m_sceneList = new QListBox( this, "m_sceneList" );
    m_sceneList->setFrameShape( QListBox::NoFrame );
    m_sceneList->setFrameShadow( QListBox::Plain );
    m_sceneList->setHScrollBarMode( QListBox::Auto );
    UI_SceneEditorLayout->addWidget( m_sceneList );

    m_statusLabel = new QLabel( this, "m_statusLabel" );
    m_statusLabel->setPaletteForegroundColor( QColor( 255, 0, 127 ) );
    m_statusLabel->setPaletteBackgroundColor( QColor( 0, 0, 0 ) );
    QFont m_statusLabel_font(  m_statusLabel->font() );
    m_statusLabel_font.setBold( TRUE );
    m_statusLabel->setFont( m_statusLabel_font ); 
    m_statusLabel->setFrameShape( QLabel::Panel );
    m_statusLabel->setFrameShadow( QLabel::Sunken );
    m_statusLabel->setAlignment( int( QLabel::AlignCenter ) );
    UI_SceneEditorLayout->addWidget( m_statusLabel );
    languageChange();
    resize( QSize(173, 220).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_sceneList, SIGNAL( selected(int) ), this, SLOT( slotActivate() ) );
    connect( m_sceneList, SIGNAL( contextMenuRequested(QListBoxItem*,const QPoint&) ), this, SLOT( slotSceneListContextMenu(QListBoxItem*,const QPoint&) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_SceneEditor::~UI_SceneEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_SceneEditor::languageChange()
{
    setCaption( tr( "SceneEditor" ) );
    m_tools->setText( tr( "Scene Editor" ) );
    m_tools->setTextLabel( tr( "Scene Editor" ) );
    QToolTip::add( m_tools, tr( "Open the quick scene editor menu" ) );
    m_statusLabel->setText( tr( "modified" ) );
}

void UI_SceneEditor::slotActivate()
{
    qWarning( "UI_SceneEditor::slotActivate(): Not implemented yet" );
}

void UI_SceneEditor::slotSceneListContextMenu(QListBoxItem*,const QPoint&)
{
    qWarning( "UI_SceneEditor::slotSceneListContextMenu(QListBoxItem*,const QPoint&): Not implemented yet" );
}

