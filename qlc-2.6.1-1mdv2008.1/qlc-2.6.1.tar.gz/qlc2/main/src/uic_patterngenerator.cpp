/****************************************************************************
** Form implementation generated from reading ui file 'src/patterngenerator.ui'
**
** Created: Thu Nov 30 00:54:59 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_patterngenerator.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qcombobox.h>
#include <qlabel.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_PatternGenerator as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_PatternGenerator::UI_PatternGenerator( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_PatternGenerator" );
    UI_PatternGeneratorLayout = new QVBoxLayout( this, 11, 6, "UI_PatternGeneratorLayout"); 

    layout64 = new QHBoxLayout( 0, 0, 6, "layout64"); 

    m_generatorFrame = new QFrame( this, "m_generatorFrame" );
    m_generatorFrame->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_generatorFrame->sizePolicy().hasHeightForWidth() ) );
    m_generatorFrame->setMinimumSize( QSize( 255, 255 ) );
    m_generatorFrame->setMaximumSize( QSize( 255, 255 ) );
    m_generatorFrame->setFrameShape( QFrame::StyledPanel );
    m_generatorFrame->setFrameShadow( QFrame::Sunken );
    layout64->addWidget( m_generatorFrame );

    layout63 = new QVBoxLayout( 0, 0, 6, "layout63"); 

    m_patternGroup = new QGroupBox( this, "m_patternGroup" );
    m_patternGroup->setColumnLayout(0, Qt::Vertical );
    m_patternGroup->layout()->setSpacing( 6 );
    m_patternGroup->layout()->setMargin( 11 );
    m_patternGroupLayout = new QHBoxLayout( m_patternGroup->layout() );
    m_patternGroupLayout->setAlignment( Qt::AlignTop );

    m_patternCombo = new QComboBox( FALSE, m_patternGroup, "m_patternCombo" );
    m_patternCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_patternCombo->sizePolicy().hasHeightForWidth() ) );
    m_patternGroupLayout->addWidget( m_patternCombo );
    layout63->addWidget( m_patternGroup );

    layout62 = new QHBoxLayout( 0, 0, 6, "layout62"); 

    m_parametersGroup = new QGroupBox( this, "m_parametersGroup" );
    m_parametersGroup->setColumnLayout(0, Qt::Vertical );
    m_parametersGroup->layout()->setSpacing( 6 );
    m_parametersGroup->layout()->setMargin( 11 );
    m_parametersGroupLayout = new QVBoxLayout( m_parametersGroup->layout() );
    m_parametersGroupLayout->setAlignment( Qt::AlignTop );

    layout14 = new QVBoxLayout( 0, 0, 6, "layout14"); 

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 

    m_widthLabel = new QLabel( m_parametersGroup, "m_widthLabel" );
    m_widthLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout6->addWidget( m_widthLabel );

    m_widthSpin = new QSpinBox( m_parametersGroup, "m_widthSpin" );
    m_widthSpin->setMaxValue( 127 );
    m_widthSpin->setValue( 127 );
    layout6->addWidget( m_widthSpin );
    layout14->addLayout( layout6 );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    m_heightLabel = new QLabel( m_parametersGroup, "m_heightLabel" );
    m_heightLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout7->addWidget( m_heightLabel );

    m_heightSpin = new QSpinBox( m_parametersGroup, "m_heightSpin" );
    m_heightSpin->setMaxValue( 127 );
    m_heightSpin->setValue( 127 );
    layout7->addWidget( m_heightSpin );
    layout14->addLayout( layout7 );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    m_xOffsetLabel = new QLabel( m_parametersGroup, "m_xOffsetLabel" );
    m_xOffsetLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout8->addWidget( m_xOffsetLabel );

    m_xOffsetSpin = new QSpinBox( m_parametersGroup, "m_xOffsetSpin" );
    m_xOffsetSpin->setMaxValue( 255 );
    m_xOffsetSpin->setValue( 127 );
    layout8->addWidget( m_xOffsetSpin );
    layout14->addLayout( layout8 );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_yOffsetLabel = new QLabel( m_parametersGroup, "m_yOffsetLabel" );
    m_yOffsetLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout9->addWidget( m_yOffsetLabel );

    m_yOffsetSpin = new QSpinBox( m_parametersGroup, "m_yOffsetSpin" );
    m_yOffsetSpin->setMaxValue( 255 );
    m_yOffsetSpin->setValue( 127 );
    layout9->addWidget( m_yOffsetSpin );
    layout14->addLayout( layout9 );

    layout35 = new QHBoxLayout( 0, 0, 6, "layout35"); 

    m_densityLabel = new QLabel( m_parametersGroup, "m_densityLabel" );
    m_densityLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout35->addWidget( m_densityLabel );

    m_densitySpin = new QSpinBox( m_parametersGroup, "m_densitySpin" );
    m_densitySpin->setMaxValue( 100 );
    m_densitySpin->setMinValue( 1 );
    m_densitySpin->setValue( 10 );
    layout35->addWidget( m_densitySpin );
    layout14->addLayout( layout35 );

    layout23 = new QHBoxLayout( 0, 0, 6, "layout23"); 

    m_orientationLabel = new QLabel( m_parametersGroup, "m_orientationLabel" );
    m_orientationLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout23->addWidget( m_orientationLabel );

    m_orientation = new QSpinBox( m_parametersGroup, "m_orientation" );
    m_orientation->setMaxValue( 90 );
    m_orientation->setValue( 0 );
    layout23->addWidget( m_orientation );
    layout14->addLayout( layout23 );
    m_parametersGroupLayout->addLayout( layout14 );
    layout62->addWidget( m_parametersGroup );

    m_paraLissa = new QGroupBox( this, "m_paraLissa" );
    m_paraLissa->setEnabled( TRUE );
    m_paraLissa->setColumnLayout(0, Qt::Vertical );
    m_paraLissa->layout()->setSpacing( 6 );
    m_paraLissa->layout()->setMargin( 11 );
    m_paraLissaLayout = new QVBoxLayout( m_paraLissa->layout() );
    m_paraLissaLayout->setAlignment( Qt::AlignTop );

    layout15 = new QVBoxLayout( 0, 0, 6, "layout15"); 

    layout13 = new QHBoxLayout( 0, 0, 6, "layout13"); 

    m_omegaxLabel = new QLabel( m_paraLissa, "m_omegaxLabel" );
    layout13->addWidget( m_omegaxLabel );

    m_omegax = new QSpinBox( m_paraLissa, "m_omegax" );
    m_omegax->setEnabled( TRUE );
    m_omegax->setMaxValue( 5 );
    m_omegax->setMinValue( 1 );
    layout13->addWidget( m_omegax );
    layout15->addLayout( layout13 );

    layout14_2 = new QHBoxLayout( 0, 0, 6, "layout14_2"); 

    m_omegayLabel = new QLabel( m_paraLissa, "m_omegayLabel" );
    layout14_2->addWidget( m_omegayLabel );

    m_omegay = new QSpinBox( m_paraLissa, "m_omegay" );
    m_omegay->setEnabled( TRUE );
    m_omegay->setMaxValue( 5 );
    m_omegay->setMinValue( 1 );
    layout14_2->addWidget( m_omegay );
    layout15->addLayout( layout14_2 );

    layout15_2 = new QHBoxLayout( 0, 0, 6, "layout15_2"); 

    m_phasexLabel = new QLabel( m_paraLissa, "m_phasexLabel" );
    layout15_2->addWidget( m_phasexLabel );

    m_phasex = new QSpinBox( m_paraLissa, "m_phasex" );
    m_phasex->setEnabled( TRUE );
    m_phasex->setMaxValue( 180 );
    m_phasex->setMinValue( 1 );
    layout15_2->addWidget( m_phasex );
    layout15->addLayout( layout15_2 );

    layout13_2 = new QHBoxLayout( 0, 0, 6, "layout13_2"); 

    m_phaseyLabel = new QLabel( m_paraLissa, "m_phaseyLabel" );
    layout13_2->addWidget( m_phaseyLabel );

    m_phasey = new QSpinBox( m_paraLissa, "m_phasey" );
    m_phasey->setEnabled( TRUE );
    m_phasey->setMaxValue( 180 );
    m_phasey->setMinValue( 1 );
    layout13_2->addWidget( m_phasey );
    layout15->addLayout( layout13_2 );
    m_paraLissaLayout->addLayout( layout15 );
    layout62->addWidget( m_paraLissa );
    layout63->addLayout( layout62 );
    layout64->addLayout( layout63 );
    UI_PatternGeneratorLayout->addLayout( layout64 );

    m_axesGroup = new QGroupBox( this, "m_axesGroup" );
    m_axesGroup->setColumnLayout(0, Qt::Vertical );
    m_axesGroup->layout()->setSpacing( 6 );
    m_axesGroup->layout()->setMargin( 11 );
    m_axesGroupLayout = new QVBoxLayout( m_axesGroup->layout() );
    m_axesGroupLayout->setAlignment( Qt::AlignTop );

    layout14_3 = new QHBoxLayout( 0, 0, 6, "layout14_3"); 

    m_horizontalLabel = new QLabel( m_axesGroup, "m_horizontalLabel" );
    m_horizontalLabel->setMinimumSize( QSize( 70, 0 ) );
    m_horizontalLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout14_3->addWidget( m_horizontalLabel );

    m_horizontalCombo = new QComboBox( FALSE, m_axesGroup, "m_horizontalCombo" );
    layout14_3->addWidget( m_horizontalCombo );
    m_axesGroupLayout->addLayout( layout14_3 );

    layout15_3 = new QHBoxLayout( 0, 0, 6, "layout15_3"); 

    m_verticalLabel = new QLabel( m_axesGroup, "m_verticalLabel" );
    m_verticalLabel->setMinimumSize( QSize( 70, 0 ) );
    m_verticalLabel->setMaximumSize( QSize( 70, 32767 ) );
    layout15_3->addWidget( m_verticalLabel );

    m_verticalCombo = new QComboBox( FALSE, m_axesGroup, "m_verticalCombo" );
    layout15_3->addWidget( m_verticalCombo );
    m_axesGroupLayout->addLayout( layout15_3 );
    UI_PatternGeneratorLayout->addWidget( m_axesGroup );

    line2 = new QFrame( this, "line2" );
    line2->setFrameShape( QFrame::HLine );
    line2->setFrameShadow( QFrame::Sunken );
    line2->setFrameShape( QFrame::HLine );
    UI_PatternGeneratorLayout->addWidget( line2 );

    layout13_3 = new QHBoxLayout( 0, 0, 6, "layout13_3"); 
    spacer4 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout13_3->addItem( spacer4 );

    m_ok = new QPushButton( this, "m_ok" );
    layout13_3->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout13_3->addWidget( m_cancel );
    UI_PatternGeneratorLayout->addLayout( layout13_3 );
    languageChange();
    resize( QSize(663, 465).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_widthSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotWidthSpinChanged(int) ) );
    connect( m_heightSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotHeightSpinChanged(int) ) );
    connect( m_xOffsetSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotXOffsetSpinChanged(int) ) );
    connect( m_yOffsetSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotYOffsetSpinChanged(int) ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_densitySpin, SIGNAL( valueChanged(int) ), this, SLOT( slotDensitySpinChanged(int) ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_horizontalCombo, SIGNAL( activated(int) ), this, SLOT( slotHorizontalChannelSelected(int) ) );
    connect( m_verticalCombo, SIGNAL( activated(int) ), this, SLOT( slotVerticalChannelSelected(int) ) );
    connect( m_patternCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotPatternSelected(const QString&) ) );
    connect( m_orientation, SIGNAL( valueChanged(int) ), this, SLOT( slotOrientationChanged(int) ) );
    connect( m_omegax, SIGNAL( valueChanged(int) ), this, SLOT( slotOmegaXChanged(int) ) );
    connect( m_omegay, SIGNAL( valueChanged(int) ), this, SLOT( slotOmegaYChanged(int) ) );
    connect( m_phasex, SIGNAL( valueChanged(int) ), this, SLOT( slotPhaseXChanged(int) ) );
    connect( m_phasey, SIGNAL( valueChanged(int) ), this, SLOT( slotPhaseYChanged(int) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_PatternGenerator::~UI_PatternGenerator()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_PatternGenerator::languageChange()
{
    setCaption( tr( "Pattern Generator" ) );
    m_patternGroup->setTitle( tr( "Pattern" ) );
    m_patternCombo->clear();
    m_patternCombo->insertItem( tr( "Circle" ) );
    m_patternCombo->insertItem( tr( "Eight" ) );
    m_patternCombo->insertItem( tr( "Line" ) );
    m_patternCombo->insertItem( tr( "Square" ) );
    m_patternCombo->insertItem( tr( "Triangle" ) );
    m_patternCombo->insertItem( tr( "Lissajou" ) );
    m_parametersGroup->setTitle( tr( "Parameters" ) );
    m_widthLabel->setText( tr( "Width" ) );
    m_heightLabel->setText( tr( "Height" ) );
    m_xOffsetLabel->setText( tr( "X Offset" ) );
    m_yOffsetLabel->setText( tr( "Y Offset" ) );
    m_densityLabel->setText( tr( "Density" ) );
    m_orientationLabel->setText( tr( "Orientation" ) );
    m_paraLissa->setTitle( tr( "Lissajou" ) );
    m_omegaxLabel->setText( tr( "FrequenceX" ) );
    m_omegayLabel->setText( tr( "FrequenceY" ) );
    m_phasexLabel->setText( tr( "PhaseX" ) );
    m_phaseyLabel->setText( tr( "PhaseY" ) );
    m_axesGroup->setTitle( tr( "Axes" ) );
    m_horizontalLabel->setText( tr( "Horizontal" ) );
    QToolTip::add( m_horizontalCombo, tr( "Horizontal (X) axis channel (usually pan)" ) );
    m_verticalLabel->setText( tr( "Vertical" ) );
    QToolTip::add( m_verticalCombo, tr( "Vertical (Y) axis channel (usually tilt)" ) );
    m_ok->setText( tr( "OK" ) );
    QToolTip::add( m_ok, tr( "Generate pattern and close." ) );
    m_cancel->setText( tr( "Cancel" ) );
    QToolTip::add( m_cancel, tr( "Close and do not generate a pattern." ) );
}

void UI_PatternGenerator::slotHeightSpinChanged(int)
{
    qWarning( "UI_PatternGenerator::slotHeightSpinChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotXOffsetSpinChanged(int)
{
    qWarning( "UI_PatternGenerator::slotXOffsetSpinChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotYOffsetSpinChanged(int)
{
    qWarning( "UI_PatternGenerator::slotYOffsetSpinChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotWidthSpinChanged(int)
{
    qWarning( "UI_PatternGenerator::slotWidthSpinChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotDensitySpinChanged(int)
{
    qWarning( "UI_PatternGenerator::slotDensitySpinChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotHorizontalChannelSelected(int)
{
    qWarning( "UI_PatternGenerator::slotHorizontalChannelSelected(int): Not implemented yet" );
}

void UI_PatternGenerator::slotVerticalChannelSelected(int)
{
    qWarning( "UI_PatternGenerator::slotVerticalChannelSelected(int): Not implemented yet" );
}

void UI_PatternGenerator::slotPatternSelected(const QString&)
{
    qWarning( "UI_PatternGenerator::slotPatternSelected(const QString&): Not implemented yet" );
}

void UI_PatternGenerator::slotOrientationChanged(int)
{
    qWarning( "UI_PatternGenerator::slotOrientationChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotOmegaXChanged(int)
{
    qWarning( "UI_PatternGenerator::slotOmegaXChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotOmegaYChanged(int)
{
    qWarning( "UI_PatternGenerator::slotOmegaYChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotPhaseXChanged(int)
{
    qWarning( "UI_PatternGenerator::slotPhaseXChanged(int): Not implemented yet" );
}

void UI_PatternGenerator::slotPhaseYChanged(int)
{
    qWarning( "UI_PatternGenerator::slotPhaseYChanged(int): Not implemented yet" );
}

