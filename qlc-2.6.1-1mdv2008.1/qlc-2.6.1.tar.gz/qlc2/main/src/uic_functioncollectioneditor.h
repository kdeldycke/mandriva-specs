/****************************************************************************
** Form interface generated from reading ui file 'src/functioncollectioneditor.ui'
**
** Created: Thu Nov 30 00:54:56 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_FUNCTIONCOLLECTIONEDITOR_H
#define UI_FUNCTIONCOLLECTIONEDITOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QListView;
class QListViewItem;
class QPushButton;
class QFrame;

class UI_FunctionCollectionEditor : public QDialog
{
    Q_OBJECT

public:
    UI_FunctionCollectionEditor( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_FunctionCollectionEditor();

    QLabel* m_nameLabel;
    QLineEdit* m_nameEdit;
    QListView* m_functionList;
    QPushButton* m_addFunction;
    QPushButton* m_removeFunction;
    QFrame* line1;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotAddFunctionClicked();
    virtual void slotRemoveFunctionClicked();
    virtual void slotOKClicked();
    virtual void slotCancelClicked();

protected:
    QVBoxLayout* UI_FunctionCollectionEditorLayout;
    QHBoxLayout* layout1;
    QHBoxLayout* layout13;
    QVBoxLayout* layout12;
    QSpacerItem* spacer4;
    QHBoxLayout* layout14;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

};

#endif // UI_FUNCTIONCOLLECTIONEDITOR_H
