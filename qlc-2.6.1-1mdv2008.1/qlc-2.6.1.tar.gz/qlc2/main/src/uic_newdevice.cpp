/****************************************************************************
** Form implementation generated from reading ui file 'src/newdevice.ui'
**
** Created: Thu Nov 30 00:54:58 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_newdevice.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qheader.h>
#include <qlistview.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qspinbox.h>
#include <qframe.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_NewDevice as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_NewDevice::UI_NewDevice( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_NewDevice" );
    UI_NewDeviceLayout = new QVBoxLayout( this, 11, 6, "UI_NewDeviceLayout"); 

    layout11 = new QHBoxLayout( 0, 0, 6, "layout11"); 

    m_tree = new QListView( this, "m_tree" );
    m_tree->addColumn( tr( "Device" ) );
    m_tree->addColumn( tr( "Type" ) );
    m_tree->setAllColumnsShowFocus( TRUE );
    m_tree->setRootIsDecorated( TRUE );
    m_tree->setResizeMode( QListView::AllColumns );
    layout11->addWidget( m_tree );

    layout10 = new QVBoxLayout( 0, 0, 6, "layout10"); 

    groupBox1 = new QGroupBox( this, "groupBox1" );
    groupBox1->setColumnLayout(0, Qt::Vertical );
    groupBox1->layout()->setSpacing( 6 );
    groupBox1->layout()->setMargin( 11 );
    groupBox1Layout = new QVBoxLayout( groupBox1->layout() );
    groupBox1Layout->setAlignment( Qt::AlignTop );

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 

    m_nameLabel = new QLabel( groupBox1, "m_nameLabel" );
    layout1->addWidget( m_nameLabel );

    m_nameEdit = new QLineEdit( groupBox1, "m_nameEdit" );
    m_nameEdit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_nameEdit->sizePolicy().hasHeightForWidth() ) );
    m_nameEdit->setMinimumSize( QSize( 150, 0 ) );
    layout1->addWidget( m_nameEdit );
    groupBox1Layout->addLayout( layout1 );

    layout3 = new QHBoxLayout( 0, 0, 6, "layout3"); 

    m_addressLabel = new QLabel( groupBox1, "m_addressLabel" );
    layout3->addWidget( m_addressLabel );

    m_addressSpin = new QSpinBox( groupBox1, "m_addressSpin" );
    m_addressSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_addressSpin->sizePolicy().hasHeightForWidth() ) );
    m_addressSpin->setWrapping( TRUE );
    m_addressSpin->setMaxValue( 512 );
    m_addressSpin->setMinValue( 1 );
    layout3->addWidget( m_addressSpin );
    groupBox1Layout->addLayout( layout3 );

    layout10_2 = new QHBoxLayout( 0, 0, 6, "layout10_2"); 

    m_universeLabel = new QLabel( groupBox1, "m_universeLabel" );
    layout10_2->addWidget( m_universeLabel );

    m_universeSpin = new QSpinBox( groupBox1, "m_universeSpin" );
    m_universeSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_universeSpin->sizePolicy().hasHeightForWidth() ) );
    m_universeSpin->setWrapping( TRUE );
    m_universeSpin->setMaxValue( 128 );
    m_universeSpin->setMinValue( 1 );
    layout10_2->addWidget( m_universeSpin );
    groupBox1Layout->addLayout( layout10_2 );

    line2 = new QFrame( groupBox1, "line2" );
    line2->setFrameShape( QFrame::HLine );
    line2->setFrameShadow( QFrame::Sunken );
    line2->setFrameShape( QFrame::HLine );
    groupBox1Layout->addWidget( line2 );

    layout10_2_2 = new QHBoxLayout( 0, 0, 6, "layout10_2_2"); 

    m_channelsLabel = new QLabel( groupBox1, "m_channelsLabel" );
    layout10_2_2->addWidget( m_channelsLabel );

    m_channelsSpin = new QSpinBox( groupBox1, "m_channelsSpin" );
    m_channelsSpin->setEnabled( FALSE );
    m_channelsSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_channelsSpin->sizePolicy().hasHeightForWidth() ) );
    m_channelsSpin->setWrapping( TRUE );
    m_channelsSpin->setMaxValue( 128 );
    m_channelsSpin->setMinValue( 0 );
    layout10_2_2->addWidget( m_channelsSpin );
    groupBox1Layout->addLayout( layout10_2_2 );
    layout10->addWidget( groupBox1 );

    groupBox2 = new QGroupBox( this, "groupBox2" );
    groupBox2->setColumnLayout(0, Qt::Vertical );
    groupBox2->layout()->setSpacing( 6 );
    groupBox2->layout()->setMargin( 11 );
    groupBox2Layout = new QVBoxLayout( groupBox2->layout() );
    groupBox2Layout->setAlignment( Qt::AlignTop );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    textLabel1 = new QLabel( groupBox2, "textLabel1" );
    layout8->addWidget( textLabel1 );

    m_multipleNumberSpin = new QSpinBox( groupBox2, "m_multipleNumberSpin" );
    m_multipleNumberSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_multipleNumberSpin->sizePolicy().hasHeightForWidth() ) );
    m_multipleNumberSpin->setButtonSymbols( QSpinBox::UpDownArrows );
    m_multipleNumberSpin->setMaxValue( 100 );
    m_multipleNumberSpin->setMinValue( 1 );
    layout8->addWidget( m_multipleNumberSpin );
    groupBox2Layout->addLayout( layout8 );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    textLabel2 = new QLabel( groupBox2, "textLabel2" );
    layout9->addWidget( textLabel2 );

    m_addressGapSpin = new QSpinBox( groupBox2, "m_addressGapSpin" );
    m_addressGapSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_addressGapSpin->sizePolicy().hasHeightForWidth() ) );
    m_addressGapSpin->setWrapping( FALSE );
    m_addressGapSpin->setMaxValue( 512 );
    layout9->addWidget( m_addressGapSpin );
    groupBox2Layout->addLayout( layout9 );
    layout10->addWidget( groupBox2 );

    m_treeOpenCheckBox = new QCheckBox( this, "m_treeOpenCheckBox" );
    m_treeOpenCheckBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)4, (QSizePolicy::SizeType)0, 0, 0, m_treeOpenCheckBox->sizePolicy().hasHeightForWidth() ) );
    layout10->addWidget( m_treeOpenCheckBox );
    spacer1 = new QSpacerItem( 20, 150, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout10->addItem( spacer1 );
    layout11->addLayout( layout10 );
    UI_NewDeviceLayout->addLayout( layout11 );

    line1 = new QFrame( this, "line1" );
    line1->setFrameShape( QFrame::HLine );
    line1->setFrameShadow( QFrame::Sunken );
    line1->setFrameShape( QFrame::HLine );
    UI_NewDeviceLayout->addWidget( line1 );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 
    spacer3 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout6->addItem( spacer3 );

    m_ok = new QPushButton( this, "m_ok" );
    layout6->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout6->addWidget( m_cancel );
    UI_NewDeviceLayout->addLayout( layout6 );
    languageChange();
    resize( QSize(494, 520).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_tree, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotSelectionChanged(QListViewItem*) ) );
    connect( m_nameEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( slotNameChanged(const QString&) ) );
    connect( m_tree, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotTreeDoubleClicked(QListViewItem*) ) );
    connect( m_treeOpenCheckBox, SIGNAL( clicked() ), this, SLOT( slotTreeOpenCheckBoxClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_NewDevice::~UI_NewDevice()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_NewDevice::languageChange()
{
    setCaption( tr( "Add a new device to the workspace" ) );
    m_tree->header()->setLabel( 0, tr( "Device" ) );
    m_tree->header()->setLabel( 1, tr( "Type" ) );
    QToolTip::add( m_tree, tr( "List of available devices" ) );
    groupBox1->setTitle( tr( "Device Properties" ) );
    m_nameLabel->setText( tr( "Name" ) );
    QToolTip::add( m_nameEdit, tr( "Give the device a descriptive name" ) );
    m_addressLabel->setText( tr( "Address" ) );
    QToolTip::add( m_addressSpin, tr( "The first device's DMX address" ) );
    m_universeLabel->setText( tr( "Universe" ) );
    QToolTip::add( m_universeSpin, tr( "The device's DMX universe" ) );
    m_channelsLabel->setText( tr( "Channels" ) );
    QToolTip::add( m_channelsSpin, tr( "Number of channels used by the device" ) );
    groupBox2->setTitle( tr( "Multiple Devices" ) );
    textLabel1->setText( tr( "Number" ) );
    QToolTip::add( m_multipleNumberSpin, tr( "Number of devices to add" ) );
    textLabel2->setText( tr( "Address gap" ) );
    QToolTip::add( m_addressGapSpin, tr( "Leave a gap between each device's address space" ) );
    m_treeOpenCheckBox->setText( tr( "Keep folders open" ) );
    QToolTip::add( m_treeOpenCheckBox, tr( "Keep all devices visible by opening all folders" ) );
    m_ok->setText( tr( "OK" ) );
    QToolTip::add( m_ok, tr( "Add the device to the workspace" ) );
    m_cancel->setText( tr( "Cancel" ) );
    QToolTip::add( m_cancel, tr( "Do not add the device to the workspace" ) );
}

void UI_NewDevice::slotOKClicked()
{
    qWarning( "UI_NewDevice::slotOKClicked(): Not implemented yet" );
}

void UI_NewDevice::slotCancelClicked()
{
    qWarning( "UI_NewDevice::slotCancelClicked(): Not implemented yet" );
}

void UI_NewDevice::slotSelectionChanged(QListViewItem*)
{
    qWarning( "UI_NewDevice::slotSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_NewDevice::slotNameChanged(const QString&)
{
    qWarning( "UI_NewDevice::slotNameChanged(const QString&): Not implemented yet" );
}

void UI_NewDevice::slotTreeDoubleClicked(QListViewItem*)
{
    qWarning( "UI_NewDevice::slotTreeDoubleClicked(QListViewItem*): Not implemented yet" );
}

void UI_NewDevice::slotTreeOpenCheckBoxClicked()
{
    qWarning( "UI_NewDevice::slotTreeOpenCheckBoxClicked(): Not implemented yet" );
}

void UI_NewDevice::slotDIPClicked()
{
    qWarning( "UI_NewDevice::slotDIPClicked(): Not implemented yet" );
}

