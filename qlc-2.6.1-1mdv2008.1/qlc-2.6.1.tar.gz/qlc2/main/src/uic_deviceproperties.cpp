/****************************************************************************
** Form implementation generated from reading ui file 'src/deviceproperties.ui'
**
** Created: Thu Nov 30 00:54:47 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_deviceproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_DeviceProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_DeviceProperties::UI_DeviceProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_DeviceProperties" );
    UI_DevicePropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_DevicePropertiesLayout"); 

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 

    m_deviceNameLabel = new QLabel( this, "m_deviceNameLabel" );
    layout1->addWidget( m_deviceNameLabel );

    m_deviceNameEdit = new QLineEdit( this, "m_deviceNameEdit" );
    layout1->addWidget( m_deviceNameEdit );
    UI_DevicePropertiesLayout->addLayout( layout1 );

    layout5 = new QHBoxLayout( 0, 0, 6, "layout5"); 

    m_addressLabel = new QLabel( this, "m_addressLabel" );
    layout5->addWidget( m_addressLabel );

    m_addressSpin = new QSpinBox( this, "m_addressSpin" );
    m_addressSpin->setMaxValue( 512 );
    m_addressSpin->setMinValue( 1 );
    layout5->addWidget( m_addressSpin );
    UI_DevicePropertiesLayout->addLayout( layout5 );

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_universeLabel = new QLabel( this, "m_universeLabel" );
    layout4->addWidget( m_universeLabel );

    m_universeSpin = new QSpinBox( this, "m_universeSpin" );
    m_universeSpin->setMaxValue( 128 );
    m_universeSpin->setMinValue( 1 );
    layout4->addWidget( m_universeSpin );
    UI_DevicePropertiesLayout->addLayout( layout4 );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 
    spacer1 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout7->addItem( spacer1 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout7->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout7->addWidget( m_cancel );
    UI_DevicePropertiesLayout->addLayout( layout7 );
    languageChange();
    resize( QSize(258, 151).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );

    // tab order
    setTabOrder( m_deviceNameEdit, m_addressSpin );
    setTabOrder( m_addressSpin, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_DeviceProperties::~UI_DeviceProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_DeviceProperties::languageChange()
{
    setCaption( tr( "Device Properties" ) );
    m_deviceNameLabel->setText( tr( "Name" ) );
    QToolTip::add( m_deviceNameEdit, tr( "Device's name" ) );
    m_addressLabel->setText( tr( "Address" ) );
    QToolTip::add( m_addressSpin, tr( "Device's DMX address" ) );
    m_universeLabel->setText( tr( "Universe" ) );
    m_ok->setText( tr( "OK" ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "Cancel" ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_DeviceProperties::slotDIPClicked()
{
    qWarning( "UI_DeviceProperties::slotDIPClicked(): Not implemented yet" );
}

void UI_DeviceProperties::slotOKClicked()
{
    qWarning( "UI_DeviceProperties::slotOKClicked(): Not implemented yet" );
}

