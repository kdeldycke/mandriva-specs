/****************************************************************************
** VirtualConsoleProperties meta object code from reading C++ file 'virtualconsoleproperties.h'
**
** Created: Thu Nov 30 00:58:03 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "virtualconsoleproperties.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VirtualConsoleProperties::className() const
{
    return "VirtualConsoleProperties";
}

QMetaObject *VirtualConsoleProperties::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VirtualConsoleProperties( "VirtualConsoleProperties", &VirtualConsoleProperties::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VirtualConsoleProperties::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VirtualConsoleProperties", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VirtualConsoleProperties::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VirtualConsoleProperties", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VirtualConsoleProperties::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_VirtualConsoleProperties::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSnapToGridToggled", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_2 = {"slotCancelClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotSnapToGridToggled(bool)", &slot_0, QMetaData::Public },
	{ "slotOKClicked()", &slot_1, QMetaData::Public },
	{ "slotCancelClicked()", &slot_2, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"VirtualConsoleProperties", parentObject,
	slot_tbl, 3,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VirtualConsoleProperties.setMetaObject( metaObj );
    return metaObj;
}

void* VirtualConsoleProperties::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VirtualConsoleProperties" ) )
	return this;
    return UI_VirtualConsoleProperties::qt_cast( clname );
}

bool VirtualConsoleProperties::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSnapToGridToggled((bool)static_QUType_bool.get(_o+1)); break;
    case 1: slotOKClicked(); break;
    case 2: slotCancelClicked(); break;
    default:
	return UI_VirtualConsoleProperties::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VirtualConsoleProperties::qt_emit( int _id, QUObject* _o )
{
    return UI_VirtualConsoleProperties::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VirtualConsoleProperties::qt_property( int id, int f, QVariant* v)
{
    return UI_VirtualConsoleProperties::qt_property( id, f, v);
}

bool VirtualConsoleProperties::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
