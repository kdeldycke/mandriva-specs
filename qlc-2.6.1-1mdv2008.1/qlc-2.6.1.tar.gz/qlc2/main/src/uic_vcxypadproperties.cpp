/****************************************************************************
** Form implementation generated from reading ui file 'src/vcxypadproperties.ui'
**
** Created: Thu Nov 30 00:55:14 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_vcxypadproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlabel.h>
#include <qspinbox.h>
#include <qcombobox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VCXYPadProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_VCXYPadProperties::UI_VCXYPadProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_VCXYPadProperties" );
    UI_VCXYPadPropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_VCXYPadPropertiesLayout"); 

    groupBox1_2 = new QGroupBox( this, "groupBox1_2" );
    groupBox1_2->setColumnLayout(0, Qt::Vertical );
    groupBox1_2->layout()->setSpacing( 6 );
    groupBox1_2->layout()->setMargin( 11 );
    groupBox1_2Layout = new QHBoxLayout( groupBox1_2->layout() );
    groupBox1_2Layout->setAlignment( Qt::AlignTop );

    layout5 = new QVBoxLayout( 0, 0, 6, "layout5"); 

    m_listX = new QListView( groupBox1_2, "m_listX" );
    m_listX->addColumn( tr( "Device" ) );
    m_listX->addColumn( tr( "Channel" ) );
    m_listX->addColumn( tr( "Min" ) );
    m_listX->addColumn( tr( "Max" ) );
    m_listX->addColumn( tr( "Reverse" ) );
    m_listX->setAllColumnsShowFocus( TRUE );
    m_listX->setResizeMode( QListView::AllColumns );
    layout5->addWidget( m_listX );

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_minXLabel = new QLabel( groupBox1_2, "m_minXLabel" );
    layout4->addWidget( m_minXLabel );

    m_minXSpin = new QSpinBox( groupBox1_2, "m_minXSpin" );
    m_minXSpin->setMaxValue( 255 );
    layout4->addWidget( m_minXSpin );

    m_maxXLabel = new QLabel( groupBox1_2, "m_maxXLabel" );
    layout4->addWidget( m_maxXLabel );

    m_maxXSpin = new QSpinBox( groupBox1_2, "m_maxXSpin" );
    m_maxXSpin->setMaxValue( 255 );
    layout4->addWidget( m_maxXSpin );

    m_reverseXLabel = new QLabel( groupBox1_2, "m_reverseXLabel" );
    layout4->addWidget( m_reverseXLabel );

    m_reverseXCombo = new QComboBox( FALSE, groupBox1_2, "m_reverseXCombo" );
    layout4->addWidget( m_reverseXCombo );
    layout5->addLayout( layout4 );
    groupBox1_2Layout->addLayout( layout5 );

    layout7 = new QVBoxLayout( 0, 0, 6, "layout7"); 

    m_addX = new QPushButton( groupBox1_2, "m_addX" );
    layout7->addWidget( m_addX );

    m_removeX = new QPushButton( groupBox1_2, "m_removeX" );
    layout7->addWidget( m_removeX );
    spacer1 = new QSpacerItem( 20, 51, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout7->addItem( spacer1 );
    groupBox1_2Layout->addLayout( layout7 );
    UI_VCXYPadPropertiesLayout->addWidget( groupBox1_2 );

    groupBox1 = new QGroupBox( this, "groupBox1" );
    groupBox1->setColumnLayout(0, Qt::Vertical );
    groupBox1->layout()->setSpacing( 6 );
    groupBox1->layout()->setMargin( 11 );
    groupBox1Layout = new QHBoxLayout( groupBox1->layout() );
    groupBox1Layout->setAlignment( Qt::AlignTop );

    layout7_2 = new QVBoxLayout( 0, 0, 6, "layout7_2"); 

    m_listY = new QListView( groupBox1, "m_listY" );
    m_listY->addColumn( tr( "Device" ) );
    m_listY->addColumn( tr( "Channel" ) );
    m_listY->addColumn( tr( "Min" ) );
    m_listY->addColumn( tr( "Max" ) );
    m_listY->addColumn( tr( "Reverse" ) );
    m_listY->setAllColumnsShowFocus( TRUE );
    m_listY->setResizeMode( QListView::AllColumns );
    layout7_2->addWidget( m_listY );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 

    m_minYLabel = new QLabel( groupBox1, "m_minYLabel" );
    layout6->addWidget( m_minYLabel );

    m_minYSpin = new QSpinBox( groupBox1, "m_minYSpin" );
    m_minYSpin->setMaxValue( 255 );
    layout6->addWidget( m_minYSpin );

    m_maxYLabel = new QLabel( groupBox1, "m_maxYLabel" );
    layout6->addWidget( m_maxYLabel );

    m_maxYSpin = new QSpinBox( groupBox1, "m_maxYSpin" );
    m_maxYSpin->setMaxValue( 255 );
    layout6->addWidget( m_maxYSpin );

    m_reverseYLabel = new QLabel( groupBox1, "m_reverseYLabel" );
    layout6->addWidget( m_reverseYLabel );

    m_reverseYCombo = new QComboBox( FALSE, groupBox1, "m_reverseYCombo" );
    layout6->addWidget( m_reverseYCombo );
    layout7_2->addLayout( layout6 );
    groupBox1Layout->addLayout( layout7_2 );

    layout6_2 = new QVBoxLayout( 0, 0, 6, "layout6_2"); 

    m_addY = new QPushButton( groupBox1, "m_addY" );
    layout6_2->addWidget( m_addY );

    m_removeY = new QPushButton( groupBox1, "m_removeY" );
    layout6_2->addWidget( m_removeY );
    spacer2 = new QSpacerItem( 21, 51, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout6_2->addItem( spacer2 );
    groupBox1Layout->addLayout( layout6_2 );
    UI_VCXYPadPropertiesLayout->addWidget( groupBox1 );

    layout3 = new QHBoxLayout( 0, 0, 6, "layout3"); 
    spacer3 = new QSpacerItem( 321, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout3->addItem( spacer3 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout3->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout3->addWidget( m_cancel );
    UI_VCXYPadPropertiesLayout->addLayout( layout3 );
    languageChange();
    resize( QSize(607, 453).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_addX, SIGNAL( clicked() ), this, SLOT( slotAddX() ) );
    connect( m_removeX, SIGNAL( clicked() ), this, SLOT( slotRemoveX() ) );
    connect( m_addY, SIGNAL( clicked() ), this, SLOT( slotAddY() ) );
    connect( m_removeY, SIGNAL( clicked() ), this, SLOT( slotRemoveY() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_listX, SIGNAL( contextMenuRequested(QListViewItem*,const QPoint&,int) ), this, SLOT( slotContextMenuRequested(QListViewItem*,const QPoint&,int) ) );
    connect( m_listY, SIGNAL( contextMenuRequested(QListViewItem*,const QPoint&,int) ), this, SLOT( slotContextMenuRequested(QListViewItem*,const QPoint&,int) ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_minXSpin, SIGNAL( valueChanged(const QString&) ), this, SLOT( slotMinXChanged(const QString&) ) );
    connect( m_maxXSpin, SIGNAL( valueChanged(const QString&) ), this, SLOT( slotMaxXChanged(const QString&) ) );
    connect( m_minYSpin, SIGNAL( valueChanged(const QString&) ), this, SLOT( slotMinYChanged(const QString&) ) );
    connect( m_maxYSpin, SIGNAL( valueChanged(const QString&) ), this, SLOT( slotMaxYChanged(const QString&) ) );
    connect( m_reverseXCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotReverseXActivated(const QString&) ) );
    connect( m_reverseYCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotReverseYActivated(const QString&) ) );
    connect( m_listX, SIGNAL( currentChanged(QListViewItem*) ), this, SLOT( slotSelectionXChanged(QListViewItem*) ) );
    connect( m_listY, SIGNAL( currentChanged(QListViewItem*) ), this, SLOT( slotSelectionYChanged(QListViewItem*) ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VCXYPadProperties::~UI_VCXYPadProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VCXYPadProperties::languageChange()
{
    setCaption( tr( "XY-Pad Properties" ) );
    groupBox1_2->setTitle( tr( "Horizontal Axis (X)" ) );
    m_listX->header()->setLabel( 0, tr( "Device" ) );
    m_listX->header()->setLabel( 1, tr( "Channel" ) );
    m_listX->header()->setLabel( 2, tr( "Min" ) );
    m_listX->header()->setLabel( 3, tr( "Max" ) );
    m_listX->header()->setLabel( 4, tr( "Reverse" ) );
    m_minXLabel->setText( tr( "Minimum Value" ) );
    m_maxXLabel->setText( tr( "Maximum Value" ) );
    m_reverseXLabel->setText( tr( "Reverse" ) );
    m_addX->setText( tr( "+" ) );
    QToolTip::add( m_addX, tr( "Add a new channel to X-axis control" ) );
    m_removeX->setText( tr( "-" ) );
    QToolTip::add( m_removeX, tr( "Remove selected channel from X axis control" ) );
    groupBox1->setTitle( tr( "Vertical Axis (Y)" ) );
    m_listY->header()->setLabel( 0, tr( "Device" ) );
    m_listY->header()->setLabel( 1, tr( "Channel" ) );
    m_listY->header()->setLabel( 2, tr( "Min" ) );
    m_listY->header()->setLabel( 3, tr( "Max" ) );
    m_listY->header()->setLabel( 4, tr( "Reverse" ) );
    m_minYLabel->setText( tr( "Minimum Value" ) );
    m_maxYLabel->setText( tr( "Maximum Value" ) );
    m_reverseYLabel->setText( tr( "Reverse" ) );
    m_addY->setText( tr( "+" ) );
    QToolTip::add( m_addY, tr( "Add new channel to Y-axis control" ) );
    m_removeY->setText( tr( "-" ) );
    QToolTip::add( m_removeY, tr( "Remove selected channel from Y-axis control" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_VCXYPadProperties::slotAddX()
{
    qWarning( "UI_VCXYPadProperties::slotAddX(): Not implemented yet" );
}

void UI_VCXYPadProperties::slotAddY()
{
    qWarning( "UI_VCXYPadProperties::slotAddY(): Not implemented yet" );
}

void UI_VCXYPadProperties::slotRemoveX()
{
    qWarning( "UI_VCXYPadProperties::slotRemoveX(): Not implemented yet" );
}

void UI_VCXYPadProperties::slotRemoveY()
{
    qWarning( "UI_VCXYPadProperties::slotRemoveY(): Not implemented yet" );
}

void UI_VCXYPadProperties::slotContextMenuRequested(QListViewItem*,const QPoint&,int)
{
    qWarning( "UI_VCXYPadProperties::slotContextMenuRequested(QListViewItem*,const QPoint&,int): Not implemented yet" );
}

void UI_VCXYPadProperties::slotOKClicked()
{
    qWarning( "UI_VCXYPadProperties::slotOKClicked(): Not implemented yet" );
}

void UI_VCXYPadProperties::slotMinXChanged(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotMinXChanged(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotMinYChanged(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotMinYChanged(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotMaxXChanged(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotMaxXChanged(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotMaxYChanged(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotMaxYChanged(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotReverseXActivated(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotReverseXActivated(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotReverseYActivated(const QString&)
{
    qWarning( "UI_VCXYPadProperties::slotReverseYActivated(const QString&): Not implemented yet" );
}

void UI_VCXYPadProperties::slotSelectionXChanged(QListViewItem*)
{
    qWarning( "UI_VCXYPadProperties::slotSelectionXChanged(QListViewItem*): Not implemented yet" );
}

void UI_VCXYPadProperties::slotSelectionYChanged(QListViewItem*)
{
    qWarning( "UI_VCXYPadProperties::slotSelectionYChanged(QListViewItem*): Not implemented yet" );
}

