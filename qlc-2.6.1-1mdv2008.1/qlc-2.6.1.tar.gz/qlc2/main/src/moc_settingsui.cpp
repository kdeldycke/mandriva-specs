/****************************************************************************
** SettingsUI meta object code from reading C++ file 'settingsui.h'
**
** Created: Thu Nov 30 00:57:50 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "settingsui.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *SettingsUI::className() const
{
    return "SettingsUI";
}

QMetaObject *SettingsUI::metaObj = 0;
static QMetaObjectCleanUp cleanUp_SettingsUI( "SettingsUI", &SettingsUI::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString SettingsUI::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SettingsUI", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString SettingsUI::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SettingsUI", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* SettingsUI::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_Settings::staticMetaObject();
    static const QUMethod slot_0 = {"slotBackgroundBrowseClicked", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotStyleChanged", 1, param_slot_1 };
    static const QUMethod slot_2 = {"slotConfigureOutputPluginClicked", 0, 0 };
    static const QUMethod slot_3 = {"slotConfigureInputPluginClicked", 0, 0 };
    static const QUMethod slot_4 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_5 = {"slotCancelClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotBackgroundBrowseClicked()", &slot_0, QMetaData::Private },
	{ "slotStyleChanged(const QString&)", &slot_1, QMetaData::Private },
	{ "slotConfigureOutputPluginClicked()", &slot_2, QMetaData::Private },
	{ "slotConfigureInputPluginClicked()", &slot_3, QMetaData::Private },
	{ "slotOKClicked()", &slot_4, QMetaData::Private },
	{ "slotCancelClicked()", &slot_5, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"SettingsUI", parentObject,
	slot_tbl, 6,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_SettingsUI.setMetaObject( metaObj );
    return metaObj;
}

void* SettingsUI::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "SettingsUI" ) )
	return this;
    return UI_Settings::qt_cast( clname );
}

bool SettingsUI::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotBackgroundBrowseClicked(); break;
    case 1: slotStyleChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 2: slotConfigureOutputPluginClicked(); break;
    case 3: slotConfigureInputPluginClicked(); break;
    case 4: slotOKClicked(); break;
    case 5: slotCancelClicked(); break;
    default:
	return UI_Settings::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool SettingsUI::qt_emit( int _id, QUObject* _o )
{
    return UI_Settings::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool SettingsUI::qt_property( int id, int f, QVariant* v)
{
    return UI_Settings::qt_property( id, f, v);
}

bool SettingsUI::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
