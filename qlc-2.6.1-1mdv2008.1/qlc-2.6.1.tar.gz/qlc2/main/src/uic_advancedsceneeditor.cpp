/****************************************************************************
** Form implementation generated from reading ui file 'src/advancedsceneeditor.ui'
**
** Created: Thu Nov 30 00:54:38 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_advancedsceneeditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qheader.h>
#include <qlistview.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_AdvancedSceneEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_AdvancedSceneEditor::UI_AdvancedSceneEditor( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_AdvancedSceneEditor" );
    UI_AdvancedSceneEditorLayout = new QVBoxLayout( this, 11, 6, "UI_AdvancedSceneEditorLayout"); 

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    m_sceneNameLabel = new QLabel( this, "m_sceneNameLabel" );
    m_sceneNameLabel->setFrameShape( QLabel::Panel );
    m_sceneNameLabel->setFrameShadow( QLabel::Sunken );
    layout8->addWidget( m_sceneNameLabel );

    m_sceneNameEdit = new QLineEdit( this, "m_sceneNameEdit" );
    layout8->addWidget( m_sceneNameEdit );
    UI_AdvancedSceneEditorLayout->addLayout( layout8 );

    m_sceneContents = new QListView( this, "m_sceneContents" );
    m_sceneContents->addColumn( tr( "#" ) );
    m_sceneContents->header()->setClickEnabled( FALSE, m_sceneContents->header()->count() - 1 );
    m_sceneContents->addColumn( tr( "Channel" ) );
    m_sceneContents->header()->setClickEnabled( FALSE, m_sceneContents->header()->count() - 1 );
    m_sceneContents->addColumn( tr( "Preset" ) );
    m_sceneContents->header()->setClickEnabled( FALSE, m_sceneContents->header()->count() - 1 );
    m_sceneContents->addColumn( tr( "Value" ) );
    m_sceneContents->header()->setClickEnabled( FALSE, m_sceneContents->header()->count() - 1 );
    m_sceneContents->addColumn( tr( "Type" ) );
    m_sceneContents->header()->setClickEnabled( FALSE, m_sceneContents->header()->count() - 1 );
    m_sceneContents->setAllColumnsShowFocus( TRUE );
    m_sceneContents->setResizeMode( QListView::AllColumns );
    UI_AdvancedSceneEditorLayout->addWidget( m_sceneContents );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    m_editValue = new QPushButton( this, "m_editValue" );
    m_editValue->setDefault( TRUE );
    layout7->addWidget( m_editValue );
    spacer4 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout7->addItem( spacer4 );

    m_applyButton = new QPushButton( this, "m_applyButton" );
    m_applyButton->setDefault( TRUE );
    layout7->addWidget( m_applyButton );

    m_ok = new QPushButton( this, "m_ok" );
    layout7->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout7->addWidget( m_cancel );
    UI_AdvancedSceneEditorLayout->addLayout( layout7 );
    languageChange();
    resize( QSize(559, 399).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_editValue, SIGNAL( clicked() ), this, SLOT( slotEditValueClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_applyButton, SIGNAL( clicked() ), this, SLOT( slotApplyClicked() ) );
    connect( m_sceneContents, SIGNAL( contextMenuRequested(QListViewItem*,const QPoint&,int) ), this, SLOT( slotChannelsContextMenuRequested(QListViewItem*,const QPoint&,int) ) );
    connect( m_sceneContents, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotContentsDoubleClicked(QListViewItem*) ) );
    connect( m_sceneContents, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotContentsClicked(QListViewItem*) ) );
    connect( m_sceneNameEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( slotSceneNameTextChanged(const QString&) ) );
    connect( m_sceneContents, SIGNAL( itemRenamed(QListViewItem*,int) ), this, SLOT( slotItemRenamed(QListViewItem*,int) ) );

    // tab order
    setTabOrder( m_sceneNameEdit, m_sceneContents );
    setTabOrder( m_sceneContents, m_editValue );
    setTabOrder( m_editValue, m_applyButton );
    setTabOrder( m_applyButton, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_AdvancedSceneEditor::~UI_AdvancedSceneEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_AdvancedSceneEditor::languageChange()
{
    setCaption( tr( "Scene Editor" ) );
    m_sceneNameLabel->setText( tr( "Scene name:" ) );
    m_sceneContents->header()->setLabel( 0, tr( "#" ) );
    m_sceneContents->header()->setLabel( 1, tr( "Channel" ) );
    m_sceneContents->header()->setLabel( 2, tr( "Preset" ) );
    m_sceneContents->header()->setLabel( 3, tr( "Value" ) );
    m_sceneContents->header()->setLabel( 4, tr( "Type" ) );
    m_editValue->setText( tr( "Edit Channel" ) );
    QToolTip::add( m_editValue, tr( "Edit current channel's value" ) );
    m_applyButton->setText( tr( "Apply" ) );
    m_ok->setText( tr( "OK" ) );
    m_cancel->setText( tr( "Cancel" ) );
}

void UI_AdvancedSceneEditor::slotChannelsContextMenuRequested(QListViewItem*,const QPoint&,int)
{
    qWarning( "UI_AdvancedSceneEditor::slotChannelsContextMenuRequested(QListViewItem*,const QPoint&,int): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotAddSceneClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotAddSceneClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotApplyClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotApplyClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotCancelClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotCancelClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotContentsClicked(QListViewItem*)
{
    qWarning( "UI_AdvancedSceneEditor::slotContentsClicked(QListViewItem*): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotContentsDoubleClicked(QListViewItem*)
{
    qWarning( "UI_AdvancedSceneEditor::slotContentsDoubleClicked(QListViewItem*): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotEditSceneNameClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotEditSceneNameClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotEditValueClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotEditValueClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotOKClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotOKClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotOutputDeviceActivated(const QString&)
{
    qWarning( "UI_AdvancedSceneEditor::slotOutputDeviceActivated(const QString&): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotRemoveSceneClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotRemoveSceneClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotSceneDoubleClicked(QListViewItem*)
{
    qWarning( "UI_AdvancedSceneEditor::slotSceneDoubleClicked(QListViewItem*): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotSceneNameTextChanged(const QString&)
{
    qWarning( "UI_AdvancedSceneEditor::slotSceneNameTextChanged(const QString&): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotSceneSelected(QListViewItem*)
{
    qWarning( "UI_AdvancedSceneEditor::slotSceneSelected(QListViewItem*): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotStoreButtonClicked()
{
    qWarning( "UI_AdvancedSceneEditor::slotStoreButtonClicked(): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotStoreSceneInGroupClicked(int)
{
    qWarning( "UI_AdvancedSceneEditor::slotStoreSceneInGroupClicked(int): Not implemented yet" );
}

void UI_AdvancedSceneEditor::slotItemRenamed(QListViewItem*,int)
{
    qWarning( "UI_AdvancedSceneEditor::slotItemRenamed(QListViewItem*,int): Not implemented yet" );
}

