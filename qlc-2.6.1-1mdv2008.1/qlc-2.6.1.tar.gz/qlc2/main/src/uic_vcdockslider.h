/****************************************************************************
** Form interface generated from reading ui file 'src/vcdockslider.ui'
**
** Created: Thu Nov 30 00:55:11 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VCDOCKSLIDER_H
#define UI_VCDOCKSLIDER_H

#include <qvariant.h>
#include <qframe.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QSlider;
class QPushButton;

class UI_VCDockSlider : public QFrame
{
    Q_OBJECT

public:
    UI_VCDockSlider( QWidget* parent = 0, const char* name = 0 );
    ~UI_VCDockSlider();

    QLabel* m_valueLabel;
    QSlider* m_slider;
    QPushButton* m_tapInButton;
    QLabel* m_infoLabel;

public slots:
    virtual void slotSliderValueChanged(int);
    virtual void slotPropertiesButtonClicked();
    virtual void slotFunctionButtonClicked();
    virtual void slotTapInButtonClicked();

protected:
    QVBoxLayout* UI_VCDockSliderLayout;
    QHBoxLayout* layout3;
    QSpacerItem* spacer5;
    QSpacerItem* spacer4;

protected slots:
    virtual void languageChange();

};

#endif // UI_VCDOCKSLIDER_H
