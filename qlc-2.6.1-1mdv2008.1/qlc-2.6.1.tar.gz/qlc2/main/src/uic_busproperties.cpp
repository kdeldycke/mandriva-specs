/****************************************************************************
** Form implementation generated from reading ui file 'src/busproperties.ui'
**
** Created: Thu Nov 30 00:54:42 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_busproperties.h"

#include <qvariant.h>
#include <qheader.h>
#include <qlistview.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_BusProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
UI_BusProperties::UI_BusProperties( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "UI_BusProperties" );
    UI_BusPropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_BusPropertiesLayout"); 

    m_list = new QListView( this, "m_list" );
    m_list->addColumn( tr( "ID" ) );
    m_list->addColumn( tr( "Name" ) );
    m_list->setAllColumnsShowFocus( TRUE );
    m_list->setResizeMode( QListView::LastColumn );
    UI_BusPropertiesLayout->addWidget( m_list );

    layout2 = new QHBoxLayout( 0, 0, 6, "layout2"); 

    m_edit = new QPushButton( this, "m_edit" );
    layout2->addWidget( m_edit );
    spacer1 = new QSpacerItem( 180, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout2->addItem( spacer1 );

    m_close = new QPushButton( this, "m_close" );
    m_close->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, m_close->sizePolicy().hasHeightForWidth() ) );
    layout2->addWidget( m_close );
    UI_BusPropertiesLayout->addLayout( layout2 );
    languageChange();
    resize( QSize(376, 286).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_close, SIGNAL( clicked() ), this, SLOT( close() ) );
    connect( m_edit, SIGNAL( clicked() ), this, SLOT( slotEditClicked() ) );
    connect( m_list, SIGNAL( doubleClicked(QListViewItem*) ), this, SLOT( slotEditClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_BusProperties::~UI_BusProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_BusProperties::languageChange()
{
    setCaption( tr( "Bus Properties" ) );
    m_list->header()->setLabel( 0, tr( "ID" ) );
    m_list->header()->setLabel( 1, tr( "Name" ) );
    m_edit->setText( tr( "&Edit..." ) );
    m_close->setText( tr( "&Close" ) );
    m_close->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

void UI_BusProperties::slotEditClicked()
{
    qWarning( "UI_BusProperties::slotEditClicked(): Not implemented yet" );
}

