/****************************************************************************
** Form interface generated from reading ui file 'src/vcdocksliderproperties.ui'
**
** Created: Thu Nov 30 00:55:08 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VCDOCKSLIDERPROPERTIES_H
#define UI_VCDOCKSLIDERPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QButtonGroup;
class QRadioButton;
class QGroupBox;
class QLabel;
class QComboBox;
class QSpinBox;
class QListView;
class QListViewItem;
class QPushButton;
class QLineEdit;

class UI_VCDockSliderProperties : public QDialog
{
    Q_OBJECT

public:
    UI_VCDockSliderProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_VCDockSliderProperties();

    QButtonGroup* m_behaviourGroup;
    QRadioButton* m_speedRadio;
    QGroupBox* m_busGroup;
    QLabel* textLabel1;
    QComboBox* m_busCombo;
    QLabel* textLabel2;
    QSpinBox* m_lowBusValueSpin;
    QLabel* textLabel3;
    QSpinBox* m_highBusValueSpin;
    QRadioButton* m_levelRadio;
    QRadioButton* m_submasterRadio;
    QGroupBox* m_channelGroup;
    QListView* m_channelList;
    QLabel* textLabel1_2;
    QSpinBox* m_lowChannelValueSpin;
    QLabel* textLabel2_2;
    QSpinBox* m_highChannelValueSpin;
    QPushButton* m_allChannels;
    QPushButton* m_invertChannels;
    QPushButton* m_clearChannels;
    QPushButton* m_deviceChannels;
    QPushButton* m_roleChannels;
    QGroupBox* m_keybourdHotkeyGroup;
    QLabel* m_keyUpLabel;
    QLabel* m_keyDownLabel;
    QLineEdit* m_keyUpEdit;
    QLineEdit* m_keyDownEdit;
    QPushButton* m_detachKey;
    QPushButton* m_attachKey;
    QGroupBox* m_IDLabel;
    QLabel* m_keyLabel_2;
    QComboBox* m_IDCombo;
    QLabel* m_channelLabel;
    QSpinBox* m_channelSpinBox;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotOKClicked();
    virtual void slotCancelClicked();
    virtual void slotBehaviourSelected(int);
    virtual void slotAllChannelsClicked();
    virtual void slotClearChannelsClicked();
    virtual void slotInvertChannelsClicked();
    virtual void slotDeviceChannelsClicked();
    virtual void slotRoleChannelsClicked();
    virtual void slotAttachKeyClicked();
    virtual void slotDetachKeyClicked();

protected:
    QVBoxLayout* UI_VCDockSliderPropertiesLayout;
    QVBoxLayout* m_behaviourGroupLayout;
    QVBoxLayout* m_busGroupLayout;
    QHBoxLayout* layout3;
    QHBoxLayout* layout4;
    QHBoxLayout* m_channelGroupLayout;
    QVBoxLayout* layout7;
    QHBoxLayout* layout5;
    QVBoxLayout* layout6;
    QSpacerItem* spacer5;
    QGridLayout* m_keybourdHotkeyGroupLayout;
    QGridLayout* m_IDLabelLayout;
    QHBoxLayout* layout7_2;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

};

#endif // UI_VCDOCKSLIDERPROPERTIES_H
