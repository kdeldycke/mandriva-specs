/****************************************************************************
** Form implementation generated from reading ui file 'src/virtualconsoleproperties.ui'
**
** Created: Thu Nov 30 00:55:16 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_virtualconsoleproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qcheckbox.h>
#include <qlabel.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VirtualConsoleProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_VirtualConsoleProperties::UI_VirtualConsoleProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_VirtualConsoleProperties" );
    UI_VirtualConsolePropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_VirtualConsolePropertiesLayout"); 

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_keyboardGroup = new QGroupBox( this, "m_keyboardGroup" );
    m_keyboardGroup->setColumnLayout(0, Qt::Vertical );
    m_keyboardGroup->layout()->setSpacing( 6 );
    m_keyboardGroup->layout()->setMargin( 11 );
    m_keyboardGroupLayout = new QVBoxLayout( m_keyboardGroup->layout() );
    m_keyboardGroupLayout->setAlignment( Qt::AlignTop );

    m_grabKeyboard = new QCheckBox( m_keyboardGroup, "m_grabKeyboard" );
    m_keyboardGroupLayout->addWidget( m_grabKeyboard );

    m_keyRepeat = new QCheckBox( m_keyboardGroup, "m_keyRepeat" );
    m_keyboardGroupLayout->addWidget( m_keyRepeat );
    layout4->addWidget( m_keyboardGroup );

    m_gridBox = new QGroupBox( this, "m_gridBox" );
    m_gridBox->setColumnLayout(0, Qt::Vertical );
    m_gridBox->layout()->setSpacing( 6 );
    m_gridBox->layout()->setMargin( 11 );
    m_gridBoxLayout = new QVBoxLayout( m_gridBox->layout() );
    m_gridBoxLayout->setAlignment( Qt::AlignTop );

    m_snapToGrid = new QCheckBox( m_gridBox, "m_snapToGrid" );
    m_gridBoxLayout->addWidget( m_snapToGrid );

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 

    textLabel1 = new QLabel( m_gridBox, "textLabel1" );
    layout1->addWidget( textLabel1 );

    m_xSpin = new QSpinBox( m_gridBox, "m_xSpin" );
    m_xSpin->setMaxValue( 100 );
    m_xSpin->setMinValue( 1 );
    layout1->addWidget( m_xSpin );
    m_gridBoxLayout->addLayout( layout1 );

    layout2 = new QHBoxLayout( 0, 0, 6, "layout2"); 

    textLabel1_2 = new QLabel( m_gridBox, "textLabel1_2" );
    textLabel1_2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)5, 0, 0, textLabel1_2->sizePolicy().hasHeightForWidth() ) );
    layout2->addWidget( textLabel1_2 );

    m_ySpin = new QSpinBox( m_gridBox, "m_ySpin" );
    m_ySpin->setMaxValue( 100 );
    m_ySpin->setMinValue( 1 );
    layout2->addWidget( m_ySpin );
    m_gridBoxLayout->addLayout( layout2 );
    layout4->addWidget( m_gridBox );
    UI_VirtualConsolePropertiesLayout->addLayout( layout4 );

    layout3 = new QHBoxLayout( 0, 0, 6, "layout3"); 
    spacer1 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout3->addItem( spacer1 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_ok->sizePolicy().hasHeightForWidth() ) );
    m_ok->setMinimumSize( QSize( 80, 0 ) );
    m_ok->setDefault( TRUE );
    layout3->addWidget( m_ok );
    spacer2 = new QSpacerItem( 16, 20, QSizePolicy::Minimum, QSizePolicy::Minimum );
    layout3->addItem( spacer2 );

    m_cancel = new QPushButton( this, "m_cancel" );
    m_cancel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_cancel->sizePolicy().hasHeightForWidth() ) );
    m_cancel->setMinimumSize( QSize( 80, 0 ) );
    layout3->addWidget( m_cancel );
    UI_VirtualConsolePropertiesLayout->addLayout( layout3 );
    languageChange();
    resize( QSize(496, 178).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_snapToGrid, SIGNAL( toggled(bool) ), this, SLOT( slotSnapToGridToggled(bool) ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VirtualConsoleProperties::~UI_VirtualConsoleProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VirtualConsoleProperties::languageChange()
{
    setCaption( tr( "Virtual Console Properties" ) );
    m_keyboardGroup->setTitle( tr( "Keyboard" ) );
    m_grabKeyboard->setText( tr( "Grab Keyboard in Operate Mode" ) );
    QToolTip::add( m_grabKeyboard, tr( "Give all keyboard input to virtual console in operate mode; This is generally good to have turned on." ) );
    m_keyRepeat->setText( tr( "Turn Off Key Repeat in Operate Mode" ) );
    QToolTip::add( m_keyRepeat, tr( "To prevent flickering in the same way as repeatedly pressing the same key; This is generally good to have turned on." ) );
    m_gridBox->setTitle( tr( "Grid" ) );
    m_snapToGrid->setText( tr( "Snap to Grid" ) );
    QToolTip::add( m_snapToGrid, tr( "Align widgets in a grid" ) );
    textLabel1->setText( tr( "Horizontal" ) );
    m_xSpin->setSuffix( tr( " px" ) );
    QToolTip::add( m_xSpin, tr( "X resolution in pixels" ) );
    textLabel1_2->setText( tr( "Vertical" ) );
    m_ySpin->setSuffix( tr( " px" ) );
    QToolTip::add( m_ySpin, tr( "Y resolution in pixels" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept settings and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Close without saving settings" ) );
}

void UI_VirtualConsoleProperties::slotSnapToGridToggled(bool)
{
    qWarning( "UI_VirtualConsoleProperties::slotSnapToGridToggled(bool): Not implemented yet" );
}

void UI_VirtualConsoleProperties::slotOKClicked()
{
    qWarning( "UI_VirtualConsoleProperties::slotOKClicked(): Not implemented yet" );
}

void UI_VirtualConsoleProperties::slotCancelClicked()
{
    qWarning( "UI_VirtualConsoleProperties::slotCancelClicked(): Not implemented yet" );
}

