/****************************************************************************
** Form interface generated from reading ui file 'src/assignsliderhotkey.ui'
**
** Created: Thu Nov 30 00:54:40 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_ASSIGNSLIDERHOTKEY_H
#define UI_ASSIGNSLIDERHOTKEY_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QTextView;
class QGroupBox;
class QLineEdit;
class QLabel;
class QPushButton;

class UI_AssignSliderHotKey : public QDialog
{
    Q_OBJECT

public:
    UI_AssignSliderHotKey( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_AssignSliderHotKey();

    QTextView* m_infoText;
    QGroupBox* m_assignGroup;
    QLineEdit* m_previewUpEdit;
    QLabel* m_previewDownLabel;
    QLineEdit* m_previewDownEdit;
    QLabel* m_previewUpLabel;
    QPushButton* m_ok;
    QPushButton* m_cancel;

protected:
    QVBoxLayout* UI_AssignSliderHotKeyLayout;
    QGridLayout* m_assignGroupLayout;
    QHBoxLayout* layout9;

protected slots:
    virtual void languageChange();

};

#endif // UI_ASSIGNSLIDERHOTKEY_H
