/****************************************************************************
** VCButton meta object code from reading C++ file 'vcbutton.h'
**
** Created: Thu Nov 30 00:57:53 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "vcbutton.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VCButton::className() const
{
    return "VCButton";
}

QMetaObject *VCButton::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCButton( "VCButton", &VCButton::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCButton::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCButton", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCButton::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCButton", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCButton::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QPushButton::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"setCaption", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotFeedBack", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotInputEvent", 3, param_slot_2 };
    static const QUMethod slot_3 = {"pressFunction", 0, 0 };
    static const QUMethod slot_4 = {"releaseFunction", 0, 0 };
    static const QUMethod slot_5 = {"slotFlashReady", 0, 0 };
    static const QUMethod slot_6 = {"slotModeChanged", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "setCaption(const QString&)", &slot_0, QMetaData::Public },
	{ "slotFeedBack()", &slot_1, QMetaData::Public },
	{ "slotInputEvent(const int,const int,const int)", &slot_2, QMetaData::Public },
	{ "pressFunction()", &slot_3, QMetaData::Public },
	{ "releaseFunction()", &slot_4, QMetaData::Public },
	{ "slotFlashReady()", &slot_5, QMetaData::Private },
	{ "slotModeChanged()", &slot_6, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"VCButton", parentObject,
	slot_tbl, 7,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCButton.setMetaObject( metaObj );
    return metaObj;
}

void* VCButton::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCButton" ) )
	return this;
    return QPushButton::qt_cast( clname );
}

bool VCButton::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: setCaption((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: slotFeedBack(); break;
    case 2: slotInputEvent((const int)static_QUType_int.get(_o+1),(const int)static_QUType_int.get(_o+2),(const int)static_QUType_int.get(_o+3)); break;
    case 3: pressFunction(); break;
    case 4: releaseFunction(); break;
    case 5: slotFlashReady(); break;
    case 6: slotModeChanged(); break;
    default:
	return QPushButton::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VCButton::qt_emit( int _id, QUObject* _o )
{
    return QPushButton::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCButton::qt_property( int id, int f, QVariant* v)
{
    return QPushButton::qt_property( id, f, v);
}

bool VCButton::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
