/****************************************************************************
** DummyOutPlugin meta object code from reading C++ file 'dummyoutplugin.h'
**
** Created: Thu Nov 30 00:57:37 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "dummyoutplugin.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DummyOutPlugin::className() const
{
    return "DummyOutPlugin";
}

QMetaObject *DummyOutPlugin::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DummyOutPlugin( "DummyOutPlugin", &DummyOutPlugin::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DummyOutPlugin::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DummyOutPlugin", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DummyOutPlugin::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DummyOutPlugin", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DummyOutPlugin::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = OutputPlugin::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotContextMenuCallback", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "slotContextMenuCallback(int)", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"DummyOutPlugin", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DummyOutPlugin.setMetaObject( metaObj );
    return metaObj;
}

void* DummyOutPlugin::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DummyOutPlugin" ) )
	return this;
    return OutputPlugin::qt_cast( clname );
}

bool DummyOutPlugin::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotContextMenuCallback((int)static_QUType_int.get(_o+1)); break;
    default:
	return OutputPlugin::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DummyOutPlugin::qt_emit( int _id, QUObject* _o )
{
    return OutputPlugin::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool DummyOutPlugin::qt_property( int id, int f, QVariant* v)
{
    return OutputPlugin::qt_property( id, f, v);
}

bool DummyOutPlugin::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
