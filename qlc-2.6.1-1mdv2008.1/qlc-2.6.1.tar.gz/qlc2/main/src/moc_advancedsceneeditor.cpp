/****************************************************************************
** AdvancedSceneEditor meta object code from reading C++ file 'advancedsceneeditor.h'
**
** Created: Thu Nov 30 00:57:21 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "advancedsceneeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *AdvancedSceneEditor::className() const
{
    return "AdvancedSceneEditor";
}

QMetaObject *AdvancedSceneEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_AdvancedSceneEditor( "AdvancedSceneEditor", &AdvancedSceneEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString AdvancedSceneEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "AdvancedSceneEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString AdvancedSceneEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "AdvancedSceneEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* AdvancedSceneEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_AdvancedSceneEditor::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSceneNameTextChanged", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotEditValueClicked", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotContentsClicked", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotContentsDoubleClicked", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotChannelsContextMenuRequested", 3, param_slot_4 };
    static const QUMethod slot_5 = {"slotApplyClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_7 = {"slotCancelClicked", 0, 0 };
    static const QUParameter param_slot_8[] = {
	{ "fid", &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotDeviceFunctionsListChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotPresetMenuActivated", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotValueMenuActivated", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotTypeMenuActivated", 1, param_slot_11 };
    static const QMetaData slot_tbl[] = {
	{ "slotSceneNameTextChanged(const QString&)", &slot_0, QMetaData::Public },
	{ "slotEditValueClicked()", &slot_1, QMetaData::Public },
	{ "slotContentsClicked(QListViewItem*)", &slot_2, QMetaData::Public },
	{ "slotContentsDoubleClicked(QListViewItem*)", &slot_3, QMetaData::Public },
	{ "slotChannelsContextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_4, QMetaData::Public },
	{ "slotApplyClicked()", &slot_5, QMetaData::Public },
	{ "slotOKClicked()", &slot_6, QMetaData::Public },
	{ "slotCancelClicked()", &slot_7, QMetaData::Public },
	{ "slotDeviceFunctionsListChanged(t_function_id)", &slot_8, QMetaData::Public },
	{ "slotPresetMenuActivated(int)", &slot_9, QMetaData::Private },
	{ "slotValueMenuActivated(int)", &slot_10, QMetaData::Private },
	{ "slotTypeMenuActivated(int)", &slot_11, QMetaData::Private }
    };
    static const QUMethod signal_0 = {"closed", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "closed()", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"AdvancedSceneEditor", parentObject,
	slot_tbl, 12,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_AdvancedSceneEditor.setMetaObject( metaObj );
    return metaObj;
}

void* AdvancedSceneEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "AdvancedSceneEditor" ) )
	return this;
    return UI_AdvancedSceneEditor::qt_cast( clname );
}

// SIGNAL closed
void AdvancedSceneEditor::closed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool AdvancedSceneEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSceneNameTextChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 1: slotEditValueClicked(); break;
    case 2: slotContentsClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 3: slotContentsDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 4: slotChannelsContextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 5: slotApplyClicked(); break;
    case 6: slotOKClicked(); break;
    case 7: slotCancelClicked(); break;
    case 8: slotDeviceFunctionsListChanged((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 9: slotPresetMenuActivated((int)static_QUType_int.get(_o+1)); break;
    case 10: slotValueMenuActivated((int)static_QUType_int.get(_o+1)); break;
    case 11: slotTypeMenuActivated((int)static_QUType_int.get(_o+1)); break;
    default:
	return UI_AdvancedSceneEditor::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool AdvancedSceneEditor::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed(); break;
    default:
	return UI_AdvancedSceneEditor::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool AdvancedSceneEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_AdvancedSceneEditor::qt_property( id, f, v);
}

bool AdvancedSceneEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
