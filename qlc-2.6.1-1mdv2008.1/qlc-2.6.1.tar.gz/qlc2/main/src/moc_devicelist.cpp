/****************************************************************************
** DeviceList meta object code from reading C++ file 'devicelist.h'
**
** Created: Thu Nov 30 00:57:31 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "devicelist.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DeviceList::className() const
{
    return "DeviceList";
}

QMetaObject *DeviceList::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DeviceList( "DeviceList", &DeviceList::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DeviceList::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceList", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DeviceList::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DeviceList", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DeviceList::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_DeviceList::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSelectionChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotItemDoubleClicked", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "slotSelectionChanged(QListViewItem*)", &slot_0, QMetaData::Public },
	{ "slotItemDoubleClicked(QListViewItem*)", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"DeviceList", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DeviceList.setMetaObject( metaObj );
    return metaObj;
}

void* DeviceList::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DeviceList" ) )
	return this;
    return UI_DeviceList::qt_cast( clname );
}

bool DeviceList::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 1: slotItemDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    default:
	return UI_DeviceList::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DeviceList::qt_emit( int _id, QUObject* _o )
{
    return UI_DeviceList::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool DeviceList::qt_property( int id, int f, QVariant* v)
{
    return UI_DeviceList::qt_property( id, f, v);
}

bool DeviceList::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
