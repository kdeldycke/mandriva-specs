/****************************************************************************
** Form interface generated from reading ui file 'src/dmxaddresstool.ui'
**
** Created: Thu Nov 30 00:54:49 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_DMXADDRESSTOOL_H
#define UI_DMXADDRESSTOOL_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QSpinBox;
class QSlider;
class QLabel;
class QPushButton;

class UI_DMXAddressTool : public QDialog
{
    Q_OBJECT

public:
    UI_DMXAddressTool( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_DMXAddressTool();

    QGroupBox* m_decimalValueGroup;
    QSpinBox* m_decimalSpin;
    QGroupBox* m_DIPSettingGroup;
    QSlider* m_256Slider;
    QLabel* m_256Label;
    QSlider* m_128Slider;
    QLabel* m_128Label;
    QSlider* m_64Slider;
    QLabel* m_64Label;
    QSlider* m_32Slider;
    QLabel* m_32Label;
    QSlider* m_16Slider;
    QLabel* m_16Label;
    QSlider* m_8Slider;
    QLabel* m_8Label;
    QSlider* m_4Slider;
    QLabel* m_4Label;
    QSlider* m_2Slider;
    QLabel* m_2Label;
    QSlider* m_1Slider;
    QLabel* m_1Label;
    QLabel* m_onLabel;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotSliderValueChanged(int);
    virtual void slotDecimalChanged(const QString &);

protected:
    QVBoxLayout* UI_DMXAddressToolLayout;
    QVBoxLayout* m_decimalValueGroupLayout;
    QHBoxLayout* m_DIPSettingGroupLayout;
    QHBoxLayout* layout13;
    QVBoxLayout* layout2;
    QVBoxLayout* layout3;
    QVBoxLayout* layout4;
    QVBoxLayout* layout5;
    QVBoxLayout* layout6;
    QVBoxLayout* layout7;
    QVBoxLayout* layout8;
    QVBoxLayout* layout9;
    QVBoxLayout* layout10;
    QVBoxLayout* layout12;
    QSpacerItem* spacer3;
    QHBoxLayout* layout12_2;
    QSpacerItem* m_spacer1;
    QSpacerItem* m_spacer2;

protected slots:
    virtual void languageChange();

};

#endif // UI_DMXADDRESSTOOL_H
