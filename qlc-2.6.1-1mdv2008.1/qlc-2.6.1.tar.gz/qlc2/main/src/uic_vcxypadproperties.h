/****************************************************************************
** Form interface generated from reading ui file 'src/vcxypadproperties.ui'
**
** Created: Thu Nov 30 00:55:14 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VCXYPADPROPERTIES_H
#define UI_VCXYPADPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QListView;
class QListViewItem;
class QLabel;
class QSpinBox;
class QComboBox;
class QPushButton;

class UI_VCXYPadProperties : public QDialog
{
    Q_OBJECT

public:
    UI_VCXYPadProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_VCXYPadProperties();

    QGroupBox* groupBox1_2;
    QListView* m_listX;
    QLabel* m_minXLabel;
    QSpinBox* m_minXSpin;
    QLabel* m_maxXLabel;
    QSpinBox* m_maxXSpin;
    QLabel* m_reverseXLabel;
    QComboBox* m_reverseXCombo;
    QPushButton* m_addX;
    QPushButton* m_removeX;
    QGroupBox* groupBox1;
    QListView* m_listY;
    QLabel* m_minYLabel;
    QSpinBox* m_minYSpin;
    QLabel* m_maxYLabel;
    QSpinBox* m_maxYSpin;
    QLabel* m_reverseYLabel;
    QComboBox* m_reverseYCombo;
    QPushButton* m_addY;
    QPushButton* m_removeY;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotAddX();
    virtual void slotAddY();
    virtual void slotRemoveX();
    virtual void slotRemoveY();
    virtual void slotContextMenuRequested(QListViewItem*, const QPoint&, int);
    virtual void slotOKClicked();
    virtual void slotMinXChanged(const QString&);
    virtual void slotMinYChanged(const QString&);
    virtual void slotMaxXChanged(const QString&);
    virtual void slotMaxYChanged(const QString &);
    virtual void slotReverseXActivated(const QString&);
    virtual void slotReverseYActivated(const QString&);
    virtual void slotSelectionXChanged(QListViewItem*);
    virtual void slotSelectionYChanged(QListViewItem*);

protected:
    QVBoxLayout* UI_VCXYPadPropertiesLayout;
    QHBoxLayout* groupBox1_2Layout;
    QVBoxLayout* layout5;
    QHBoxLayout* layout4;
    QVBoxLayout* layout7;
    QSpacerItem* spacer1;
    QHBoxLayout* groupBox1Layout;
    QVBoxLayout* layout7_2;
    QHBoxLayout* layout6;
    QVBoxLayout* layout6_2;
    QSpacerItem* spacer2;
    QHBoxLayout* layout3;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // UI_VCXYPADPROPERTIES_H
