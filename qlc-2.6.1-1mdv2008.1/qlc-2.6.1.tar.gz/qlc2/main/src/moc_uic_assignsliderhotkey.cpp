/****************************************************************************
** UI_AssignSliderHotKey meta object code from reading C++ file 'uic_assignsliderhotkey.h'
**
** Created: Thu Nov 30 00:55:19 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_assignsliderhotkey.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_AssignSliderHotKey::className() const
{
    return "UI_AssignSliderHotKey";
}

QMetaObject *UI_AssignSliderHotKey::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_AssignSliderHotKey( "UI_AssignSliderHotKey", &UI_AssignSliderHotKey::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_AssignSliderHotKey::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_AssignSliderHotKey", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_AssignSliderHotKey::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_AssignSliderHotKey", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_AssignSliderHotKey::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "languageChange()", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_AssignSliderHotKey", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_AssignSliderHotKey.setMetaObject( metaObj );
    return metaObj;
}

void* UI_AssignSliderHotKey::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_AssignSliderHotKey" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_AssignSliderHotKey::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_AssignSliderHotKey::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_AssignSliderHotKey::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_AssignSliderHotKey::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
