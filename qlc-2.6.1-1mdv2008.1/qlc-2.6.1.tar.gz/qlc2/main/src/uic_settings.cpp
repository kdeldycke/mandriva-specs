/****************************************************************************
** Form implementation generated from reading ui file 'src/settings.ui'
**
** Created: Thu Nov 30 00:55:05 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_settings.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_Settings as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_Settings::UI_Settings( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_Settings" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)3, 0, 0, sizePolicy().hasHeightForWidth() ) );
    UI_SettingsLayout = new QGridLayout( this, 1, 1, 11, 6, "UI_SettingsLayout"); 

    m_backgroundGroupBox = new QGroupBox( this, "m_backgroundGroupBox" );
    m_backgroundGroupBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_backgroundGroupBox->sizePolicy().hasHeightForWidth() ) );
    m_backgroundGroupBox->setFrameShape( QGroupBox::Box );
    m_backgroundGroupBox->setFrameShadow( QGroupBox::Sunken );
    m_backgroundGroupBox->setColumnLayout(0, Qt::Vertical );
    m_backgroundGroupBox->layout()->setSpacing( 6 );
    m_backgroundGroupBox->layout()->setMargin( 11 );
    m_backgroundGroupBoxLayout = new QVBoxLayout( m_backgroundGroupBox->layout() );
    m_backgroundGroupBoxLayout->setAlignment( Qt::AlignTop );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_backgroundEdit = new QLineEdit( m_backgroundGroupBox, "m_backgroundEdit" );
    m_backgroundEdit->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_backgroundEdit->sizePolicy().hasHeightForWidth() ) );
    m_backgroundEdit->setMinimumSize( QSize( 200, 0 ) );
    layout9->addWidget( m_backgroundEdit );

    m_backgroundBrowse = new QPushButton( m_backgroundGroupBox, "m_backgroundBrowse" );
    m_backgroundBrowse->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_backgroundBrowse->sizePolicy().hasHeightForWidth() ) );
    m_backgroundBrowse->setMinimumSize( QSize( 30, 23 ) );
    m_backgroundBrowse->setMaximumSize( QSize( 30, 23 ) );
    m_backgroundBrowse->setFlat( FALSE );
    layout9->addWidget( m_backgroundBrowse );
    m_backgroundGroupBoxLayout->addLayout( layout9 );

    UI_SettingsLayout->addWidget( m_backgroundGroupBox, 0, 0 );

    GroupBox4 = new QGroupBox( this, "GroupBox4" );
    GroupBox4->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, GroupBox4->sizePolicy().hasHeightForWidth() ) );
    GroupBox4->setColumnLayout(0, Qt::Vertical );
    GroupBox4->layout()->setSpacing( 6 );
    GroupBox4->layout()->setMargin( 11 );
    GroupBox4Layout = new QVBoxLayout( GroupBox4->layout() );
    GroupBox4Layout->setAlignment( Qt::AlignTop );

    layout5 = new QHBoxLayout( 0, 0, 6, "layout5"); 

    m_widgetStyleLabel = new QLabel( GroupBox4, "m_widgetStyleLabel" );
    m_widgetStyleLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, m_widgetStyleLabel->sizePolicy().hasHeightForWidth() ) );
    m_widgetStyleLabel->setMinimumSize( QSize( 80, 0 ) );
    layout5->addWidget( m_widgetStyleLabel );

    m_widgetStyleCombo = new QComboBox( FALSE, GroupBox4, "m_widgetStyleCombo" );
    m_widgetStyleCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_widgetStyleCombo->sizePolicy().hasHeightForWidth() ) );
    m_widgetStyleCombo->setMinimumSize( QSize( 200, 0 ) );
    layout5->addWidget( m_widgetStyleCombo );
    GroupBox4Layout->addLayout( layout5 );

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    m_MRUSizeLabel = new QLabel( GroupBox4, "m_MRUSizeLabel" );
    m_MRUSizeLabel->setMinimumSize( QSize( 80, 0 ) );
    layout4->addWidget( m_MRUSizeLabel );

    m_MRUSizeSpin = new QSpinBox( GroupBox4, "m_MRUSizeSpin" );
    m_MRUSizeSpin->setMaxValue( 10 );
    layout4->addWidget( m_MRUSizeSpin );
    spacer1 = new QSpacerItem( 140, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout4->addItem( spacer1 );
    GroupBox4Layout->addLayout( layout4 );

    UI_SettingsLayout->addWidget( GroupBox4, 1, 0 );

    layout4_2 = new QHBoxLayout( 0, 0, 6, "layout4_2"); 

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout4_2->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout4_2->addWidget( m_cancel );

    UI_SettingsLayout->addLayout( layout4_2, 5, 0 );

    groupBox7 = new QGroupBox( this, "groupBox7" );
    groupBox7->setColumnLayout(0, Qt::Vertical );
    groupBox7->layout()->setSpacing( 6 );
    groupBox7->layout()->setMargin( 11 );
    groupBox7Layout = new QGridLayout( groupBox7->layout() );
    groupBox7Layout->setAlignment( Qt::AlignTop );

    m_advancedList = new QListView( groupBox7, "m_advancedList" );
    m_advancedList->addColumn( tr( "Key" ) );
    m_advancedList->addColumn( tr( "Value" ) );
    m_advancedList->setAllColumnsShowFocus( TRUE );
    m_advancedList->setShowSortIndicator( TRUE );
    m_advancedList->setRootIsDecorated( FALSE );
    m_advancedList->setResizeMode( QListView::LastColumn );

    groupBox7Layout->addWidget( m_advancedList, 0, 0 );

    UI_SettingsLayout->addWidget( groupBox7, 4, 0 );

    m_startupGroupBox = new QGroupBox( this, "m_startupGroupBox" );
    m_startupGroupBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_startupGroupBox->sizePolicy().hasHeightForWidth() ) );
    m_startupGroupBox->setColumnLayout(0, Qt::Vertical );
    m_startupGroupBox->layout()->setSpacing( 6 );
    m_startupGroupBox->layout()->setMargin( 11 );
    m_startupGroupBoxLayout = new QHBoxLayout( m_startupGroupBox->layout() );
    m_startupGroupBoxLayout->setAlignment( Qt::AlignTop );

    m_openLastWorkspaceCheckBox = new QCheckBox( m_startupGroupBox, "m_openLastWorkspaceCheckBox" );
    m_openLastWorkspaceCheckBox->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)3, 0, 0, m_openLastWorkspaceCheckBox->sizePolicy().hasHeightForWidth() ) );
    m_startupGroupBoxLayout->addWidget( m_openLastWorkspaceCheckBox );

    UI_SettingsLayout->addWidget( m_startupGroupBox, 2, 0 );

    groupBox6 = new QGroupBox( this, "groupBox6" );
    groupBox6->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)0, 0, 0, groupBox6->sizePolicy().hasHeightForWidth() ) );
    groupBox6->setColumnLayout(0, Qt::Vertical );
    groupBox6->layout()->setSpacing( 6 );
    groupBox6->layout()->setMargin( 11 );
    groupBox6Layout = new QGridLayout( groupBox6->layout() );
    groupBox6Layout->setAlignment( Qt::AlignTop );

    textLabel1 = new QLabel( groupBox6, "textLabel1" );
    textLabel1->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, textLabel1->sizePolicy().hasHeightForWidth() ) );
    textLabel1->setMinimumSize( QSize( 80, 0 ) );

    groupBox6Layout->addWidget( textLabel1, 0, 0 );

    textLabel2 = new QLabel( groupBox6, "textLabel2" );
    textLabel2->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, textLabel2->sizePolicy().hasHeightForWidth() ) );
    textLabel2->setMinimumSize( QSize( 80, 0 ) );

    groupBox6Layout->addWidget( textLabel2, 1, 0 );

    m_outputPluginCombo = new QComboBox( FALSE, groupBox6, "m_outputPluginCombo" );
    m_outputPluginCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_outputPluginCombo->sizePolicy().hasHeightForWidth() ) );
    m_outputPluginCombo->setMinimumSize( QSize( 160, 0 ) );

    groupBox6Layout->addWidget( m_outputPluginCombo, 0, 1 );

    m_inputPluginCombo = new QComboBox( FALSE, groupBox6, "m_inputPluginCombo" );
    m_inputPluginCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)3, (QSizePolicy::SizeType)0, 0, 0, m_inputPluginCombo->sizePolicy().hasHeightForWidth() ) );
    m_inputPluginCombo->setMinimumSize( QSize( 160, 0 ) );

    groupBox6Layout->addWidget( m_inputPluginCombo, 1, 1 );

    m_configureInputPlugin = new QPushButton( groupBox6, "m_configureInputPlugin" );
    m_configureInputPlugin->setMinimumSize( QSize( 30, 23 ) );
    m_configureInputPlugin->setMaximumSize( QSize( 30, 23 ) );

    groupBox6Layout->addWidget( m_configureInputPlugin, 1, 2 );

    m_configureOutputPlugin = new QPushButton( groupBox6, "m_configureOutputPlugin" );
    m_configureOutputPlugin->setMinimumSize( QSize( 30, 23 ) );
    m_configureOutputPlugin->setMaximumSize( QSize( 30, 23 ) );

    groupBox6Layout->addWidget( m_configureOutputPlugin, 0, 2 );

    UI_SettingsLayout->addWidget( groupBox6, 3, 0 );
    languageChange();
    resize( QSize(372, 580).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );
    connect( m_widgetStyleCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotStyleChanged(const QString&) ) );
    connect( m_backgroundBrowse, SIGNAL( clicked() ), this, SLOT( slotBackgroundBrowseClicked() ) );
    connect( m_configureOutputPlugin, SIGNAL( clicked() ), this, SLOT( slotConfigureOutputPluginClicked() ) );
    connect( m_configureInputPlugin, SIGNAL( clicked() ), this, SLOT( slotConfigureInputPluginClicked() ) );

    // tab order
    setTabOrder( m_backgroundEdit, m_backgroundBrowse );
    setTabOrder( m_backgroundBrowse, m_widgetStyleCombo );
    setTabOrder( m_widgetStyleCombo, m_openLastWorkspaceCheckBox );
    setTabOrder( m_openLastWorkspaceCheckBox, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_Settings::~UI_Settings()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_Settings::languageChange()
{
    setCaption( tr( "Settings" ) );
    m_backgroundGroupBox->setTitle( tr( "Background Wallpaper" ) );
    QToolTip::add( m_backgroundEdit, tr( "The workspace background image." ) );
    m_backgroundBrowse->setText( tr( "..." ) );
    QToolTip::add( m_backgroundBrowse, tr( "Browse the workspace background image." ) );
    GroupBox4->setTitle( tr( "User Interface" ) );
    m_widgetStyleLabel->setText( tr( "Widget Style" ) );
    QToolTip::add( m_widgetStyleCombo, tr( "The general look of QLC." ) );
    m_MRUSizeLabel->setText( tr( "MRU Size:" ) );
    m_ok->setText( tr( "OK" ) );
    QToolTip::add( m_ok, tr( "Accept settings and close this window." ) );
    m_cancel->setText( tr( "Cancel" ) );
    QToolTip::add( m_cancel, tr( "Close this window without accepting settings." ) );
    groupBox7->setTitle( tr( "Advanced Settings (not yet modifiable)" ) );
    m_advancedList->header()->setLabel( 0, tr( "Key" ) );
    m_advancedList->header()->setLabel( 1, tr( "Value" ) );
    QToolTip::add( m_advancedList, tr( "List of settings" ) );
    m_startupGroupBox->setTitle( tr( "Startup" ) );
    m_openLastWorkspaceCheckBox->setText( tr( "Open Last Workspace" ) );
    QToolTip::add( m_openLastWorkspaceCheckBox, tr( "Open the last workspace file next time when you start QLC." ) );
    groupBox6->setTitle( tr( "Lighting Control Input/Output" ) );
    textLabel1->setText( tr( "Output Plugin" ) );
    textLabel2->setText( tr( "Input Plugin" ) );
    QToolTip::add( m_outputPluginCombo, tr( "The currently selected output plugin" ) );
    QToolTip::add( m_inputPluginCombo, tr( "The currently selected output plugin" ) );
    m_configureInputPlugin->setText( tr( "..." ) );
    QToolTip::add( m_configureInputPlugin, tr( "Configure the selected plugin" ) );
    m_configureOutputPlugin->setText( tr( "..." ) );
    QToolTip::add( m_configureOutputPlugin, tr( "Configure the selected plugin" ) );
}

void UI_Settings::slotCancelClicked()
{
    qWarning( "UI_Settings::slotCancelClicked(): Not implemented yet" );
}

void UI_Settings::slotOKClicked()
{
    qWarning( "UI_Settings::slotOKClicked(): Not implemented yet" );
}

void UI_Settings::slotStyleChanged(const QString&)
{
    qWarning( "UI_Settings::slotStyleChanged(const QString&): Not implemented yet" );
}

void UI_Settings::slotBackgroundBrowseClicked()
{
    qWarning( "UI_Settings::slotBackgroundBrowseClicked(): Not implemented yet" );
}

void UI_Settings::slotConfigureOutputPluginClicked()
{
    qWarning( "UI_Settings::slotConfigureOutputPluginClicked(): Not implemented yet" );
}

void UI_Settings::slotConfigureInputPluginClicked()
{
    qWarning( "UI_Settings::slotConfigureInputPluginClicked(): Not implemented yet" );
}

