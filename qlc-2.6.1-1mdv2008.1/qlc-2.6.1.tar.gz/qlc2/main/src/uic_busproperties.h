/****************************************************************************
** Form interface generated from reading ui file 'src/busproperties.ui'
**
** Created: Thu Nov 30 00:54:42 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_BUSPROPERTIES_H
#define UI_BUSPROPERTIES_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QListView;
class QListViewItem;
class QPushButton;

class UI_BusProperties : public QWidget
{
    Q_OBJECT

public:
    UI_BusProperties( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~UI_BusProperties();

    QListView* m_list;
    QPushButton* m_edit;
    QPushButton* m_close;

public slots:
    virtual void slotEditClicked();

protected:
    QVBoxLayout* UI_BusPropertiesLayout;
    QHBoxLayout* layout2;
    QSpacerItem* spacer1;

protected slots:
    virtual void languageChange();

};

#endif // UI_BUSPROPERTIES_H
