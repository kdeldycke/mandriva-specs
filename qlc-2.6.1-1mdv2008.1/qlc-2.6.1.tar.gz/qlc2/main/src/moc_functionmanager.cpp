/****************************************************************************
** FunctionManager meta object code from reading C++ file 'functionmanager.h'
**
** Created: Thu Nov 30 00:57:42 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "functionmanager.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *FunctionManager::className() const
{
    return "FunctionManager";
}

QMetaObject *FunctionManager::metaObj = 0;
static QMetaObjectCleanUp cleanUp_FunctionManager( "FunctionManager", &FunctionManager::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString FunctionManager::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FunctionManager", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString FunctionManager::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FunctionManager", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* FunctionManager::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUMethod slot_0 = {"show", 0, 0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotDeviceAdded", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotDeviceRemoved", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_ptr, "t_device_id", QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotDeviceChanged", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotFunctionAdded", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotFunctionRemoved", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ 0, &static_QUType_ptr, "t_function_id", QUParameter::In }
    };
    static const QUMethod slot_6 = {"slotFunctionChanged", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ "section", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotFixtureHeaderClicked", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ "section", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotFunctionHeaderClicked", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotFixtureTreeSelectionChanged", 1, param_slot_9 };
    static const QUMethod slot_10 = {"slotFunctionTreeSelectionChanged", 0, 0 };
    static const QUParameter param_slot_11[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotFixtureTreeContextMenuRequested", 3, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotFunctionTreeContextMenuRequested", 3, param_slot_12 };
    static const QUParameter param_slot_13[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "pos", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_13 = {"slotFunctionTreeDoubleClicked", 3, param_slot_13 };
    static const QUParameter param_slot_14[] = {
	{ "busID", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_14 = {"slotBusActivated", 1, param_slot_14 };
    static const QUMethod slot_15 = {"slotAddScene", 0, 0 };
    static const QUMethod slot_16 = {"slotAddChaser", 0, 0 };
    static const QUMethod slot_17 = {"slotAddCollection", 0, 0 };
    static const QUMethod slot_18 = {"slotAddSequence", 0, 0 };
    static const QUMethod slot_19 = {"slotAddEFX", 0, 0 };
    static const QUMethod slot_20 = {"slotCut", 0, 0 };
    static const QUMethod slot_21 = {"slotCopy", 0, 0 };
    static const QUMethod slot_22 = {"slotPaste", 0, 0 };
    static const QUParameter param_slot_23[] = {
	{ 0, &static_QUType_int, 0, QUParameter::Out }
    };
    static const QUMethod slot_23 = {"slotEdit", 1, param_slot_23 };
    static const QUMethod slot_24 = {"slotDelete", 0, 0 };
    static const QUParameter param_slot_25[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_25 = {"slotAddMenuCallback", 1, param_slot_25 };
    static const QUMethod slot_26 = {"slotUpdateBusMenu", 0, 0 };
    static const QUMethod slot_27 = {"slotSelectAll", 0, 0 };
    static const QUMethod slot_28 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_29 = {"slotCancelClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "show()", &slot_0, QMetaData::Public },
	{ "slotDeviceAdded(t_device_id)", &slot_1, QMetaData::Public },
	{ "slotDeviceRemoved(t_device_id)", &slot_2, QMetaData::Public },
	{ "slotDeviceChanged(t_device_id)", &slot_3, QMetaData::Public },
	{ "slotFunctionAdded(t_function_id)", &slot_4, QMetaData::Public },
	{ "slotFunctionRemoved(t_function_id)", &slot_5, QMetaData::Public },
	{ "slotFunctionChanged(t_function_id)", &slot_6, QMetaData::Public },
	{ "slotFixtureHeaderClicked(int)", &slot_7, QMetaData::Protected },
	{ "slotFunctionHeaderClicked(int)", &slot_8, QMetaData::Protected },
	{ "slotFixtureTreeSelectionChanged(QListViewItem*)", &slot_9, QMetaData::Protected },
	{ "slotFunctionTreeSelectionChanged()", &slot_10, QMetaData::Protected },
	{ "slotFixtureTreeContextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_11, QMetaData::Protected },
	{ "slotFunctionTreeContextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_12, QMetaData::Protected },
	{ "slotFunctionTreeDoubleClicked(QListViewItem*,const QPoint&,int)", &slot_13, QMetaData::Protected },
	{ "slotBusActivated(int)", &slot_14, QMetaData::Protected },
	{ "slotAddScene()", &slot_15, QMetaData::Protected },
	{ "slotAddChaser()", &slot_16, QMetaData::Protected },
	{ "slotAddCollection()", &slot_17, QMetaData::Protected },
	{ "slotAddSequence()", &slot_18, QMetaData::Protected },
	{ "slotAddEFX()", &slot_19, QMetaData::Protected },
	{ "slotCut()", &slot_20, QMetaData::Protected },
	{ "slotCopy()", &slot_21, QMetaData::Protected },
	{ "slotPaste()", &slot_22, QMetaData::Protected },
	{ "slotEdit()", &slot_23, QMetaData::Protected },
	{ "slotDelete()", &slot_24, QMetaData::Protected },
	{ "slotAddMenuCallback(int)", &slot_25, QMetaData::Protected },
	{ "slotUpdateBusMenu()", &slot_26, QMetaData::Protected },
	{ "slotSelectAll()", &slot_27, QMetaData::Protected },
	{ "slotOKClicked()", &slot_28, QMetaData::Protected },
	{ "slotCancelClicked()", &slot_29, QMetaData::Protected }
    };
    static const QUMethod signal_0 = {"closed", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "closed()", &signal_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"FunctionManager", parentObject,
	slot_tbl, 30,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_FunctionManager.setMetaObject( metaObj );
    return metaObj;
}

void* FunctionManager::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "FunctionManager" ) )
	return this;
    return QWidget::qt_cast( clname );
}

// SIGNAL closed
void FunctionManager::closed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool FunctionManager::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: show(); break;
    case 1: slotDeviceAdded((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 2: slotDeviceRemoved((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 3: slotDeviceChanged((t_device_id)(*((t_device_id*)static_QUType_ptr.get(_o+1)))); break;
    case 4: slotFunctionAdded((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 5: slotFunctionRemoved((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 6: slotFunctionChanged((t_function_id)(*((t_function_id*)static_QUType_ptr.get(_o+1)))); break;
    case 7: slotFixtureHeaderClicked((int)static_QUType_int.get(_o+1)); break;
    case 8: slotFunctionHeaderClicked((int)static_QUType_int.get(_o+1)); break;
    case 9: slotFixtureTreeSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 10: slotFunctionTreeSelectionChanged(); break;
    case 11: slotFixtureTreeContextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 12: slotFunctionTreeContextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 13: slotFunctionTreeDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 14: slotBusActivated((int)static_QUType_int.get(_o+1)); break;
    case 15: slotAddScene(); break;
    case 16: slotAddChaser(); break;
    case 17: slotAddCollection(); break;
    case 18: slotAddSequence(); break;
    case 19: slotAddEFX(); break;
    case 20: slotCut(); break;
    case 21: slotCopy(); break;
    case 22: slotPaste(); break;
    case 23: static_QUType_int.set(_o,slotEdit()); break;
    case 24: slotDelete(); break;
    case 25: slotAddMenuCallback((int)static_QUType_int.get(_o+1)); break;
    case 26: slotUpdateBusMenu(); break;
    case 27: slotSelectAll(); break;
    case 28: slotOKClicked(); break;
    case 29: slotCancelClicked(); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool FunctionManager::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed(); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool FunctionManager::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool FunctionManager::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
