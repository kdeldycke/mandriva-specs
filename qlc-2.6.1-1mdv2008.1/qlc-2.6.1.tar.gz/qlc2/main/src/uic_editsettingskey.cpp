/****************************************************************************
** Form implementation generated from reading ui file 'src/editsettingskey.ui'
**
** Created: Thu Nov 30 00:54:52 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_editsettingskey.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_EditSettingsKey as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 */
UI_EditSettingsKey::UI_EditSettingsKey( QWidget* parent, const char* name, WFlags fl )
    : QWidget( parent, name, fl )
{
    if ( !name )
	setName( "UI_EditSettingsKey" );
    UI_EditSettingsKeyLayout = new QVBoxLayout( this, 11, 6, "UI_EditSettingsKeyLayout"); 

    layout4 = new QHBoxLayout( 0, 0, 6, "layout4"); 

    layout1 = new QVBoxLayout( 0, 0, 6, "layout1"); 

    textLabel1 = new QLabel( this, "textLabel1" );
    layout1->addWidget( textLabel1 );

    m_keyEdit = new QLineEdit( this, "m_keyEdit" );
    m_keyEdit->setReadOnly( TRUE );
    layout1->addWidget( m_keyEdit );
    layout4->addLayout( layout1 );

    layout2 = new QVBoxLayout( 0, 0, 6, "layout2"); 

    textLabel2 = new QLabel( this, "textLabel2" );
    layout2->addWidget( textLabel2 );

    m_valueEdit = new QLineEdit( this, "m_valueEdit" );
    layout2->addWidget( m_valueEdit );
    layout4->addLayout( layout2 );
    UI_EditSettingsKeyLayout->addLayout( layout4 );

    m_typeGroup = new QButtonGroup( this, "m_typeGroup" );
    m_typeGroup->setFrameShadow( QButtonGroup::Sunken );
    m_typeGroup->setProperty( "selectedId", -1 );
    m_typeGroup->setColumnLayout(0, Qt::Vertical );
    m_typeGroup->layout()->setSpacing( 6 );
    m_typeGroup->layout()->setMargin( 11 );
    m_typeGroupLayout = new QHBoxLayout( m_typeGroup->layout() );
    m_typeGroupLayout->setAlignment( Qt::AlignTop );

    m_integerRadio = new QRadioButton( m_typeGroup, "m_integerRadio" );
    m_typeGroupLayout->addWidget( m_integerRadio );

    m_textRadio = new QRadioButton( m_typeGroup, "m_textRadio" );
    m_typeGroupLayout->addWidget( m_textRadio );
    UI_EditSettingsKeyLayout->addWidget( m_typeGroup );

    layout5 = new QHBoxLayout( 0, 0, 6, "layout5"); 
    spacer1 = new QSpacerItem( 200, 21, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout5->addItem( spacer1 );

    m_okButton = new QPushButton( this, "m_okButton" );
    m_okButton->setDefault( TRUE );
    layout5->addWidget( m_okButton );

    m_cancelButton = new QPushButton( this, "m_cancelButton" );
    layout5->addWidget( m_cancelButton );
    UI_EditSettingsKeyLayout->addLayout( layout5 );
    languageChange();
    resize( QSize(425, 171).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_EditSettingsKey::~UI_EditSettingsKey()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_EditSettingsKey::languageChange()
{
    setCaption( tr( "Edit Key Value" ) );
    textLabel1->setText( tr( "Key Name:" ) );
    textLabel2->setText( tr( "Key Value:" ) );
    m_typeGroup->setTitle( tr( "Value Type" ) );
    m_integerRadio->setText( tr( "Integer" ) );
    m_textRadio->setText( tr( "Text" ) );
    m_okButton->setText( tr( "&OK" ) );
    m_okButton->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    m_cancelButton->setText( tr( "&Cancel" ) );
    m_cancelButton->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

