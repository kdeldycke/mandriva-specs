/****************************************************************************
** Form interface generated from reading ui file 'src/devicelist.ui'
**
** Created: Thu Nov 30 00:54:46 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_DEVICELIST_H
#define UI_DEVICELIST_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QListView;
class QListViewItem;
class QPushButton;

class UI_DeviceList : public QDialog
{
    Q_OBJECT

public:
    UI_DeviceList( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_DeviceList();

    QGroupBox* groupBox9;
    QListView* m_listView;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotSelectionChanged(QListViewItem*);
    virtual void slotItemDoubleClicked(QListViewItem*);

protected:
    QVBoxLayout* UI_DeviceListLayout;
    QGridLayout* groupBox9Layout;
    QHBoxLayout* layout24;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // UI_DEVICELIST_H
