/****************************************************************************
** Form implementation generated from reading ui file 'src/editscenevalue.ui'
**
** Created: Thu Nov 30 00:54:50 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_editscenevalue.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_EditSceneValue as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_EditSceneValue::UI_EditSceneValue( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_EditSceneValue" );
    UI_EditSceneValueLayout = new QGridLayout( this, 1, 1, 11, 6, "UI_EditSceneValueLayout"); 

    m_cancel = new QPushButton( this, "m_cancel" );

    UI_EditSceneValueLayout->addWidget( m_cancel, 1, 1 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );

    UI_EditSceneValueLayout->addWidget( m_ok, 1, 0 );

    m_groupBox = new QGroupBox( this, "m_groupBox" );
    m_groupBox->setColumnLayout(0, Qt::Vertical );
    m_groupBox->layout()->setSpacing( 6 );
    m_groupBox->layout()->setMargin( 11 );
    m_groupBoxLayout = new QGridLayout( m_groupBox->layout() );
    m_groupBoxLayout->setAlignment( Qt::AlignTop );

    TextLabel2 = new QLabel( m_groupBox, "TextLabel2" );

    m_groupBoxLayout->addWidget( TextLabel2, 0, 0 );

    m_presetCombo = new QComboBox( FALSE, m_groupBox, "m_presetCombo" );

    m_groupBoxLayout->addWidget( m_presetCombo, 1, 0 );

    TextLabel3 = new QLabel( m_groupBox, "TextLabel3" );

    m_groupBoxLayout->addWidget( TextLabel3, 0, 1 );

    m_valueSpin = new QSpinBox( m_groupBox, "m_valueSpin" );
    m_valueSpin->setMaxValue( 255 );

    m_groupBoxLayout->addWidget( m_valueSpin, 1, 1 );

    m_typeCombo = new QComboBox( FALSE, m_groupBox, "m_typeCombo" );

    m_groupBoxLayout->addWidget( m_typeCombo, 1, 2 );

    TextLabel4 = new QLabel( m_groupBox, "TextLabel4" );

    m_groupBoxLayout->addWidget( TextLabel4, 0, 2 );

    UI_EditSceneValueLayout->addMultiCellWidget( m_groupBox, 0, 0, 0, 1 );
    languageChange();
    resize( QSize(381, 133).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_typeCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotTypeActivated(const QString&) ) );

    // tab order
    setTabOrder( m_presetCombo, m_valueSpin );
    setTabOrder( m_valueSpin, m_typeCombo );
    setTabOrder( m_typeCombo, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_EditSceneValue::~UI_EditSceneValue()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_EditSceneValue::languageChange()
{
    setCaption( tr( "Edit Scene Value" ) );
    m_cancel->setText( tr( "Cancel" ) );
    m_ok->setText( tr( "OK" ) );
    m_groupBox->setTitle( QString::null );
    TextLabel2->setText( tr( "Preset Value" ) );
    TextLabel3->setText( tr( "Value" ) );
    TextLabel4->setText( tr( "Type" ) );
}

void UI_EditSceneValue::slotTypeActivated(const QString&)
{
    qWarning( "UI_EditSceneValue::slotTypeActivated(const QString&): Not implemented yet" );
}

