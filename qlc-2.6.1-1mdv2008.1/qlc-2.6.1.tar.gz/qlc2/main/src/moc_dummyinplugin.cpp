/****************************************************************************
** DummyInPlugin meta object code from reading C++ file 'dummyinplugin.h'
**
** Created: Thu Nov 30 00:57:36 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "dummyinplugin.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *DummyInPlugin::className() const
{
    return "DummyInPlugin";
}

QMetaObject *DummyInPlugin::metaObj = 0;
static QMetaObjectCleanUp cleanUp_DummyInPlugin( "DummyInPlugin", &DummyInPlugin::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString DummyInPlugin::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DummyInPlugin", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString DummyInPlugin::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "DummyInPlugin", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* DummyInPlugin::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = InputPlugin::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotContextMenuCallback", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "slotContextMenuCallback(int)", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"DummyInPlugin", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_DummyInPlugin.setMetaObject( metaObj );
    return metaObj;
}

void* DummyInPlugin::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "DummyInPlugin" ) )
	return this;
    return InputPlugin::qt_cast( clname );
}

bool DummyInPlugin::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotContextMenuCallback((int)static_QUType_int.get(_o+1)); break;
    default:
	return InputPlugin::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool DummyInPlugin::qt_emit( int _id, QUObject* _o )
{
    return InputPlugin::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool DummyInPlugin::qt_property( int id, int f, QVariant* v)
{
    return InputPlugin::qt_property( id, f, v);
}

bool DummyInPlugin::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
