/****************************************************************************
** Form interface generated from reading ui file 'src/efxeditor.ui'
**
** Created: Thu Nov 30 00:54:53 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_EFXEDITOR_H
#define UI_EFXEDITOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QTabWidget;
class QWidget;
class QFrame;
class QGroupBox;
class QComboBox;
class QSpinBox;
class QButtonGroup;
class QRadioButton;
class QCheckBox;
class QListView;
class QListViewItem;
class QPushButton;
class QSlider;

class UI_EFXEditor : public QDialog
{
    Q_OBJECT

public:
    UI_EFXEditor( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_EFXEditor();

    QLabel* m_nameLabel;
    QLineEdit* m_nameEdit;
    QTabWidget* m_tab;
    QWidget* tab;
    QFrame* m_previewFrame;
    QGroupBox* m_axesGroup;
    QLabel* m_horizontalLabel;
    QComboBox* m_horizontalCombo;
    QLabel* m_verticalLabel;
    QComboBox* m_verticalCombo;
    QGroupBox* m_algorithmGroup;
    QComboBox* m_algorithmCombo;
    QGroupBox* m_parametersGroup;
    QLabel* m_widthLabel;
    QSpinBox* m_widthSpin;
    QLabel* m_heightLabel;
    QSpinBox* m_heightSpin;
    QLabel* m_xOffsetLabel;
    QSpinBox* m_xOffsetSpin;
    QLabel* m_yOffsetLabel;
    QSpinBox* m_yOffsetSpin;
    QLabel* m_rotationLabel;
    QSpinBox* m_rotationSpin;
    QLabel* m_xFrequencyLabel;
    QSpinBox* m_xFrequencySpin;
    QLabel* m_yFrequencyLabel;
    QSpinBox* m_yFrequencySpin;
    QLabel* m_xPhaseLabel;
    QSpinBox* m_xPhaseSpin;
    QLabel* m_yPhaseLabel;
    QSpinBox* m_yPhaseSpin;
    QWidget* tab_2;
    QButtonGroup* m_runOrderGroup;
    QRadioButton* m_loopModeButton;
    QRadioButton* m_singleShotModeButton;
    QRadioButton* m_pingPongModeButton;
    QButtonGroup* m_directionGroup;
    QRadioButton* m_forwardsDirectionButton;
    QRadioButton* m_backwardsDirectionButton;
    QGroupBox* m_blackoutFeatureGroup;
    QCheckBox* m_startSceneCheckbox;
    QListView* m_startSceneList;
    QGroupBox* m_blackoutFeatureGroup_2;
    QCheckBox* m_stopSceneCheckbox;
    QListView* m_stopSceneList;
    QWidget* TabPage;
    QButtonGroup* m_modulationParametersGroup;
    QCheckBox* m_widthButton;
    QCheckBox* m_heightButton;
    QCheckBox* m_xOffsetButton;
    QCheckBox* m_yOffsetButton;
    QCheckBox* m_xFrequencyButton;
    QCheckBox* m_yFrequencyButton;
    QCheckBox* m_xPhaseButton;
    QCheckBox* m_yPhaseButton;
    QGroupBox* m_modulationSpeedGroup;
    QLabel* m_modulationSpeedLabel;
    QComboBox* m_modulationBusCombo;
    QPushButton* m_testRunButton;
    QSlider* m_testRunSpeedSlider;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotHeightSpinChanged( int );
    virtual void slotXOffsetSpinChanged( int );
    virtual void slotYOffsetSpinChanged( int );
    virtual void slotWidthSpinChanged( int );
    virtual void slotHorizontalChannelSelected( int );
    virtual void slotVerticalChannelSelected( int );
    virtual void slotAlgorithmSelected( const QString & );
    virtual void slotNameChanged( const QString & );
    virtual void slotXFrequencySpinChanged(int);
    virtual void slotYFrequencySpinChanged(int);
    virtual void slotXPhaseSpinChanged(int);
    virtual void slotYPhaseSpinChanged(int);
    virtual void slotRotationSpinChanged(int);
    virtual void slotTestRunToggled(bool);
    virtual void slotTestRunSpeedSliderValueChanged(int);
    virtual void slotStartSceneCheckboxToggled( bool );
    virtual void slotStopSceneCheckboxToggled( bool );
    virtual void slotStartSceneListSelectionChanged(QListViewItem*);
    virtual void slotStopSceneListSelectionChanged(QListViewItem*);
    virtual void slotDirectionClicked(int);
    virtual void slotRunOrderClicked(int);

protected:
    QVBoxLayout* UI_EFXEditorLayout;
    QHBoxLayout* layout15;
    QGridLayout* tabLayout;
    QVBoxLayout* layout26;
    QVBoxLayout* m_axesGroupLayout;
    QHBoxLayout* layout14;
    QHBoxLayout* layout15_2;
    QVBoxLayout* layout37;
    QHBoxLayout* m_algorithmGroupLayout;
    QVBoxLayout* m_parametersGroupLayout;
    QSpacerItem* spacer2;
    QHBoxLayout* layout6;
    QHBoxLayout* layout7;
    QHBoxLayout* layout8;
    QHBoxLayout* layout36;
    QGridLayout* layout16;
    QHBoxLayout* layout9_2;
    QHBoxLayout* layout9_3;
    QHBoxLayout* layout9_4;
    QHBoxLayout* layout9_5;
    QVBoxLayout* tabLayout_2;
    QHBoxLayout* layout16_2;
    QVBoxLayout* m_runOrderGroupLayout;
    QVBoxLayout* m_directionGroupLayout;
    QHBoxLayout* layout21;
    QVBoxLayout* m_blackoutFeatureGroupLayout;
    QVBoxLayout* m_blackoutFeatureGroup_2Layout;
    QVBoxLayout* TabPageLayout;
    QGridLayout* m_modulationParametersGroupLayout;
    QVBoxLayout* m_modulationSpeedGroupLayout;
    QHBoxLayout* layout22;
    QHBoxLayout* layout19;
    QSpacerItem* spacer4;

protected slots:
    virtual void languageChange();

};

#endif // UI_EFXEDITOR_H
