/****************************************************************************
** Form implementation generated from reading ui file 'src/consolechannel.ui'
**
** Created: Thu Nov 30 00:54:45 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_consolechannel.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qslider.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_ConsoleChannel which is a child of 'parent', with the
 *  name 'name'.' 
 */
UI_ConsoleChannel::UI_ConsoleChannel( QWidget* parent,  const char* name )
    : QFrame( parent, name )
{
    if ( !name )
	setName( "UI_ConsoleChannel" );
    setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)7, 0, 0, sizePolicy().hasHeightForWidth() ) );
    setMaximumSize( QSize( 35, 32767 ) );
    setFrameShape( QFrame::StyledPanel );
    setFrameShadow( QFrame::Sunken );
    UI_ConsoleChannelLayout = new QVBoxLayout( this, 5, 5, "UI_ConsoleChannelLayout"); 

    m_presetButton = new QPushButton( this, "m_presetButton" );
    m_presetButton->setMinimumSize( QSize( 20, 20 ) );
    m_presetButton->setMaximumSize( QSize( 32767, 20 ) );
    UI_ConsoleChannelLayout->addWidget( m_presetButton );

    m_valueLabel = new QLabel( this, "m_valueLabel" );
    m_valueLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, m_valueLabel->sizePolicy().hasHeightForWidth() ) );
    m_valueLabel->setAlignment( int( QLabel::AlignCenter ) );
    UI_ConsoleChannelLayout->addWidget( m_valueLabel );

    m_valueSlider = new QSlider( this, "m_valueSlider" );
    m_valueSlider->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)5, (QSizePolicy::SizeType)7, 0, 0, m_valueSlider->sizePolicy().hasHeightForWidth() ) );
    m_valueSlider->setMaxValue( 255 );
    m_valueSlider->setOrientation( QSlider::Vertical );
    m_valueSlider->setTickInterval( 16 );
    UI_ConsoleChannelLayout->addWidget( m_valueSlider );

    m_statusButton = new QPushButton( this, "m_statusButton" );
    m_statusButton->setMinimumSize( QSize( 20, 20 ) );
    m_statusButton->setMaximumSize( QSize( 32767, 20 ) );
    m_statusButton->setPaletteForegroundColor( QColor( 255, 255, 255 ) );
    UI_ConsoleChannelLayout->addWidget( m_statusButton );

    m_numberLabel = new QLabel( this, "m_numberLabel" );
    m_numberLabel->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)1, 0, 0, m_numberLabel->sizePolicy().hasHeightForWidth() ) );
    m_numberLabel->setAlignment( int( QLabel::AlignCenter ) );
    UI_ConsoleChannelLayout->addWidget( m_numberLabel );
    languageChange();
    resize( QSize(35, 285).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_ConsoleChannel::~UI_ConsoleChannel()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_ConsoleChannel::languageChange()
{
    setCaption( tr( "UI_ConsoleChannel" ) );
    m_presetButton->setText( QString::null );
    QToolTip::add( m_presetButton, tr( "Presets" ) );
    m_valueLabel->setText( tr( "000" ) );
    m_statusButton->setText( QString::null );
    m_numberLabel->setText( tr( "000" ) );
}

