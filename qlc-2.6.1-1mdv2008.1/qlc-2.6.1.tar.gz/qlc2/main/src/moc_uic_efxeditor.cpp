/****************************************************************************
** UI_EFXEditor meta object code from reading C++ file 'uic_efxeditor.h'
**
** Created: Thu Nov 30 00:55:28 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_efxeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_EFXEditor::className() const
{
    return "UI_EFXEditor";
}

QMetaObject *UI_EFXEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_EFXEditor( "UI_EFXEditor", &UI_EFXEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_EFXEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_EFXEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_EFXEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_EFXEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_EFXEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotHeightSpinChanged", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotXOffsetSpinChanged", 1, param_slot_1 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotYOffsetSpinChanged", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotWidthSpinChanged", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotHorizontalChannelSelected", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotVerticalChannelSelected", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"slotAlgorithmSelected", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotNameChanged", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotXFrequencySpinChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotYFrequencySpinChanged", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotXPhaseSpinChanged", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotYPhaseSpinChanged", 1, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotRotationSpinChanged", 1, param_slot_12 };
    static const QUParameter param_slot_13[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_13 = {"slotTestRunToggled", 1, param_slot_13 };
    static const QUParameter param_slot_14[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_14 = {"slotTestRunSpeedSliderValueChanged", 1, param_slot_14 };
    static const QUParameter param_slot_15[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_15 = {"slotStartSceneCheckboxToggled", 1, param_slot_15 };
    static const QUParameter param_slot_16[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_16 = {"slotStopSceneCheckboxToggled", 1, param_slot_16 };
    static const QUParameter param_slot_17[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_17 = {"slotStartSceneListSelectionChanged", 1, param_slot_17 };
    static const QUParameter param_slot_18[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_18 = {"slotStopSceneListSelectionChanged", 1, param_slot_18 };
    static const QUParameter param_slot_19[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_19 = {"slotDirectionClicked", 1, param_slot_19 };
    static const QUParameter param_slot_20[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_20 = {"slotRunOrderClicked", 1, param_slot_20 };
    static const QUMethod slot_21 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotHeightSpinChanged(int)", &slot_0, QMetaData::Public },
	{ "slotXOffsetSpinChanged(int)", &slot_1, QMetaData::Public },
	{ "slotYOffsetSpinChanged(int)", &slot_2, QMetaData::Public },
	{ "slotWidthSpinChanged(int)", &slot_3, QMetaData::Public },
	{ "slotHorizontalChannelSelected(int)", &slot_4, QMetaData::Public },
	{ "slotVerticalChannelSelected(int)", &slot_5, QMetaData::Public },
	{ "slotAlgorithmSelected(const QString&)", &slot_6, QMetaData::Public },
	{ "slotNameChanged(const QString&)", &slot_7, QMetaData::Public },
	{ "slotXFrequencySpinChanged(int)", &slot_8, QMetaData::Public },
	{ "slotYFrequencySpinChanged(int)", &slot_9, QMetaData::Public },
	{ "slotXPhaseSpinChanged(int)", &slot_10, QMetaData::Public },
	{ "slotYPhaseSpinChanged(int)", &slot_11, QMetaData::Public },
	{ "slotRotationSpinChanged(int)", &slot_12, QMetaData::Public },
	{ "slotTestRunToggled(bool)", &slot_13, QMetaData::Public },
	{ "slotTestRunSpeedSliderValueChanged(int)", &slot_14, QMetaData::Public },
	{ "slotStartSceneCheckboxToggled(bool)", &slot_15, QMetaData::Public },
	{ "slotStopSceneCheckboxToggled(bool)", &slot_16, QMetaData::Public },
	{ "slotStartSceneListSelectionChanged(QListViewItem*)", &slot_17, QMetaData::Public },
	{ "slotStopSceneListSelectionChanged(QListViewItem*)", &slot_18, QMetaData::Public },
	{ "slotDirectionClicked(int)", &slot_19, QMetaData::Public },
	{ "slotRunOrderClicked(int)", &slot_20, QMetaData::Public },
	{ "languageChange()", &slot_21, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_EFXEditor", parentObject,
	slot_tbl, 22,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_EFXEditor.setMetaObject( metaObj );
    return metaObj;
}

void* UI_EFXEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_EFXEditor" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_EFXEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotHeightSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 1: slotXOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 2: slotYOffsetSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 3: slotWidthSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 4: slotHorizontalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    case 5: slotVerticalChannelSelected((int)static_QUType_int.get(_o+1)); break;
    case 6: slotAlgorithmSelected((const QString&)static_QUType_QString.get(_o+1)); break;
    case 7: slotNameChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 8: slotXFrequencySpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 9: slotYFrequencySpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 10: slotXPhaseSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 11: slotYPhaseSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 12: slotRotationSpinChanged((int)static_QUType_int.get(_o+1)); break;
    case 13: slotTestRunToggled((bool)static_QUType_bool.get(_o+1)); break;
    case 14: slotTestRunSpeedSliderValueChanged((int)static_QUType_int.get(_o+1)); break;
    case 15: slotStartSceneCheckboxToggled((bool)static_QUType_bool.get(_o+1)); break;
    case 16: slotStopSceneCheckboxToggled((bool)static_QUType_bool.get(_o+1)); break;
    case 17: slotStartSceneListSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 18: slotStopSceneListSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 19: slotDirectionClicked((int)static_QUType_int.get(_o+1)); break;
    case 20: slotRunOrderClicked((int)static_QUType_int.get(_o+1)); break;
    case 21: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_EFXEditor::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_EFXEditor::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_EFXEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
