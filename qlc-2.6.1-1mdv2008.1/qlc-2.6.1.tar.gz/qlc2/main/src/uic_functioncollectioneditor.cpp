/****************************************************************************
** Form implementation generated from reading ui file 'src/functioncollectioneditor.ui'
**
** Created: Thu Nov 30 00:54:56 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_functioncollectioneditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qheader.h>
#include <qlistview.h>
#include <qframe.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_FunctionCollectionEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_FunctionCollectionEditor::UI_FunctionCollectionEditor( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_FunctionCollectionEditor" );
    UI_FunctionCollectionEditorLayout = new QVBoxLayout( this, 11, 6, "UI_FunctionCollectionEditorLayout"); 

    layout1 = new QHBoxLayout( 0, 0, 6, "layout1"); 

    m_nameLabel = new QLabel( this, "m_nameLabel" );
    layout1->addWidget( m_nameLabel );

    m_nameEdit = new QLineEdit( this, "m_nameEdit" );
    layout1->addWidget( m_nameEdit );
    UI_FunctionCollectionEditorLayout->addLayout( layout1 );

    layout13 = new QHBoxLayout( 0, 0, 6, "layout13"); 

    m_functionList = new QListView( this, "m_functionList" );
    m_functionList->addColumn( tr( "Device" ) );
    m_functionList->addColumn( tr( "Function" ) );
    m_functionList->setAllColumnsShowFocus( TRUE );
    m_functionList->setResizeMode( QListView::AllColumns );
    layout13->addWidget( m_functionList );

    layout12 = new QVBoxLayout( 0, 0, 6, "layout12"); 

    m_addFunction = new QPushButton( this, "m_addFunction" );
    m_addFunction->setMaximumSize( QSize( 30, 30 ) );
    layout12->addWidget( m_addFunction );

    m_removeFunction = new QPushButton( this, "m_removeFunction" );
    m_removeFunction->setMaximumSize( QSize( 30, 30 ) );
    layout12->addWidget( m_removeFunction );
    spacer4 = new QSpacerItem( 20, 40, QSizePolicy::Minimum, QSizePolicy::Expanding );
    layout12->addItem( spacer4 );
    layout13->addLayout( layout12 );
    UI_FunctionCollectionEditorLayout->addLayout( layout13 );

    line1 = new QFrame( this, "line1" );
    line1->setFrameShape( QFrame::HLine );
    line1->setFrameShadow( QFrame::Sunken );
    line1->setFrameShape( QFrame::HLine );
    UI_FunctionCollectionEditorLayout->addWidget( line1 );

    layout14 = new QHBoxLayout( 0, 0, 6, "layout14"); 
    spacer1 = new QSpacerItem( 260, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout14->addItem( spacer1 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setMinimumSize( QSize( 70, 0 ) );
    m_ok->setDefault( TRUE );
    layout14->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout14->addWidget( m_cancel );
    UI_FunctionCollectionEditorLayout->addLayout( layout14 );
    languageChange();
    resize( QSize(500, 392).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_addFunction, SIGNAL( clicked() ), this, SLOT( slotAddFunctionClicked() ) );
    connect( m_removeFunction, SIGNAL( clicked() ), this, SLOT( slotRemoveFunctionClicked() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );

    // tab order
    setTabOrder( m_nameEdit, m_functionList );
    setTabOrder( m_functionList, m_addFunction );
    setTabOrder( m_addFunction, m_removeFunction );
    setTabOrder( m_removeFunction, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_FunctionCollectionEditor::~UI_FunctionCollectionEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_FunctionCollectionEditor::languageChange()
{
    setCaption( tr( "Function Collection Editor" ) );
    m_nameLabel->setText( tr( "Collection Name:" ) );
    QToolTip::add( m_nameEdit, tr( "Collection name" ) );
    m_functionList->header()->setLabel( 0, tr( "Device" ) );
    m_functionList->header()->setLabel( 1, tr( "Function" ) );
    QToolTip::add( m_functionList, tr( "Functions assigned to this collection" ) );
    m_addFunction->setText( tr( "+" ) );
    m_addFunction->setAccel( QKeySequence( tr( "Ins" ) ) );
    QToolTip::add( m_addFunction, tr( "Add new function" ) );
    m_removeFunction->setText( tr( "X" ) );
    m_removeFunction->setAccel( QKeySequence( tr( "Del" ) ) );
    QToolTip::add( m_removeFunction, tr( "Remove selected function" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_FunctionCollectionEditor::slotAddFunctionClicked()
{
    qWarning( "UI_FunctionCollectionEditor::slotAddFunctionClicked(): Not implemented yet" );
}

void UI_FunctionCollectionEditor::slotRemoveFunctionClicked()
{
    qWarning( "UI_FunctionCollectionEditor::slotRemoveFunctionClicked(): Not implemented yet" );
}

void UI_FunctionCollectionEditor::slotOKClicked()
{
    qWarning( "UI_FunctionCollectionEditor::slotOKClicked(): Not implemented yet" );
}

void UI_FunctionCollectionEditor::slotCancelClicked()
{
    qWarning( "UI_FunctionCollectionEditor::slotCancelClicked(): Not implemented yet" );
}

