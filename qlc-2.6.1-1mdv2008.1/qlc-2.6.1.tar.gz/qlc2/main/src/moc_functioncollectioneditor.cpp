/****************************************************************************
** FunctionCollectionEditor meta object code from reading C++ file 'functioncollectioneditor.h'
**
** Created: Thu Nov 30 00:57:40 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "functioncollectioneditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *FunctionCollectionEditor::className() const
{
    return "FunctionCollectionEditor";
}

QMetaObject *FunctionCollectionEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_FunctionCollectionEditor( "FunctionCollectionEditor", &FunctionCollectionEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString FunctionCollectionEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FunctionCollectionEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString FunctionCollectionEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FunctionCollectionEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* FunctionCollectionEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_FunctionCollectionEditor::staticMetaObject();
    static const QUMethod slot_0 = {"slotAddFunctionClicked", 0, 0 };
    static const QUMethod slot_1 = {"slotFunctionManagerClosed", 0, 0 };
    static const QUMethod slot_2 = {"slotAddAnother", 0, 0 };
    static const QUMethod slot_3 = {"slotRemoveFunctionClicked", 0, 0 };
    static const QUMethod slot_4 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_5 = {"slotCancelClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotAddFunctionClicked()", &slot_0, QMetaData::Private },
	{ "slotFunctionManagerClosed()", &slot_1, QMetaData::Private },
	{ "slotAddAnother()", &slot_2, QMetaData::Private },
	{ "slotRemoveFunctionClicked()", &slot_3, QMetaData::Private },
	{ "slotOKClicked()", &slot_4, QMetaData::Private },
	{ "slotCancelClicked()", &slot_5, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"FunctionCollectionEditor", parentObject,
	slot_tbl, 6,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_FunctionCollectionEditor.setMetaObject( metaObj );
    return metaObj;
}

void* FunctionCollectionEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "FunctionCollectionEditor" ) )
	return this;
    return UI_FunctionCollectionEditor::qt_cast( clname );
}

bool FunctionCollectionEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotAddFunctionClicked(); break;
    case 1: slotFunctionManagerClosed(); break;
    case 2: slotAddAnother(); break;
    case 3: slotRemoveFunctionClicked(); break;
    case 4: slotOKClicked(); break;
    case 5: slotCancelClicked(); break;
    default:
	return UI_FunctionCollectionEditor::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool FunctionCollectionEditor::qt_emit( int _id, QUObject* _o )
{
    return UI_FunctionCollectionEditor::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool FunctionCollectionEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_FunctionCollectionEditor::qt_property( id, f, v);
}

bool FunctionCollectionEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
