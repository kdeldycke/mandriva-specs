/****************************************************************************
** Form implementation generated from reading ui file 'src/vcbuttonproperties.ui'
**
** Created: Thu Nov 30 00:55:07 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_vcbuttonproperties.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_VCButtonProperties as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_VCButtonProperties::UI_VCButtonProperties( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_VCButtonProperties" );
    UI_VCButtonPropertiesLayout = new QVBoxLayout( this, 11, 6, "UI_VCButtonPropertiesLayout"); 

    m_generalInfoGroup = new QGroupBox( this, "m_generalInfoGroup" );
    m_generalInfoGroup->setColumnLayout(0, Qt::Vertical );
    m_generalInfoGroup->layout()->setSpacing( 6 );
    m_generalInfoGroup->layout()->setMargin( 11 );
    m_generalInfoGroupLayout = new QVBoxLayout( m_generalInfoGroup->layout() );
    m_generalInfoGroupLayout->setAlignment( Qt::AlignTop );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    m_nameLabel = new QLabel( m_generalInfoGroup, "m_nameLabel" );
    m_nameLabel->setMinimumSize( QSize( 80, 0 ) );
    layout8->addWidget( m_nameLabel );

    m_nameEdit = new QLineEdit( m_generalInfoGroup, "m_nameEdit" );
    layout8->addWidget( m_nameEdit );
    m_generalInfoGroupLayout->addLayout( layout8 );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    m_functionLabel = new QLabel( m_generalInfoGroup, "m_functionLabel" );
    m_functionLabel->setMinimumSize( QSize( 80, 0 ) );
    layout7->addWidget( m_functionLabel );

    m_functionEdit = new QLineEdit( m_generalInfoGroup, "m_functionEdit" );
    m_functionEdit->setFocusPolicy( QLineEdit::NoFocus );
    m_functionEdit->setReadOnly( TRUE );
    layout7->addWidget( m_functionEdit );

    m_attachFunction = new QPushButton( m_generalInfoGroup, "m_attachFunction" );
    m_attachFunction->setMinimumSize( QSize( 30, 30 ) );
    m_attachFunction->setMaximumSize( QSize( 30, 30 ) );
    m_attachFunction->setFlat( FALSE );
    layout7->addWidget( m_attachFunction );

    m_detachFunction = new QPushButton( m_generalInfoGroup, "m_detachFunction" );
    m_detachFunction->setMinimumSize( QSize( 30, 30 ) );
    m_detachFunction->setMaximumSize( QSize( 30, 30 ) );
    layout7->addWidget( m_detachFunction );
    m_generalInfoGroupLayout->addLayout( layout7 );
    UI_VCButtonPropertiesLayout->addWidget( m_generalInfoGroup );

    m_keyboardHotkeyGroup = new QGroupBox( this, "m_keyboardHotkeyGroup" );
    m_keyboardHotkeyGroup->setColumnLayout(0, Qt::Vertical );
    m_keyboardHotkeyGroup->layout()->setSpacing( 6 );
    m_keyboardHotkeyGroup->layout()->setMargin( 11 );
    m_keyboardHotkeyGroupLayout = new QHBoxLayout( m_keyboardHotkeyGroup->layout() );
    m_keyboardHotkeyGroupLayout->setAlignment( Qt::AlignTop );

    m_keyLabel = new QLabel( m_keyboardHotkeyGroup, "m_keyLabel" );
    m_keyLabel->setMinimumSize( QSize( 80, 0 ) );
    m_keyboardHotkeyGroupLayout->addWidget( m_keyLabel );

    m_keyEdit = new QLineEdit( m_keyboardHotkeyGroup, "m_keyEdit" );
    m_keyEdit->setFocusPolicy( QLineEdit::NoFocus );
    m_keyEdit->setReadOnly( TRUE );
    m_keyboardHotkeyGroupLayout->addWidget( m_keyEdit );

    m_attachKey = new QPushButton( m_keyboardHotkeyGroup, "m_attachKey" );
    m_attachKey->setMinimumSize( QSize( 30, 30 ) );
    m_attachKey->setMaximumSize( QSize( 30, 30 ) );
    m_keyboardHotkeyGroupLayout->addWidget( m_attachKey );

    m_detachKey = new QPushButton( m_keyboardHotkeyGroup, "m_detachKey" );
    m_detachKey->setMinimumSize( QSize( 30, 30 ) );
    m_detachKey->setMaximumSize( QSize( 30, 30 ) );
    m_keyboardHotkeyGroupLayout->addWidget( m_detachKey );
    UI_VCButtonPropertiesLayout->addWidget( m_keyboardHotkeyGroup );

    m_IDLabel = new QGroupBox( this, "m_IDLabel" );
    m_IDLabel->setColumnLayout(0, Qt::Vertical );
    m_IDLabel->layout()->setSpacing( 6 );
    m_IDLabel->layout()->setMargin( 11 );
    m_IDLabelLayout = new QGridLayout( m_IDLabel->layout() );
    m_IDLabelLayout->setAlignment( Qt::AlignTop );

    m_keyLabel_2 = new QLabel( m_IDLabel, "m_keyLabel_2" );
    m_keyLabel_2->setMinimumSize( QSize( 80, 0 ) );

    m_IDLabelLayout->addWidget( m_keyLabel_2, 0, 0 );

    m_IDCombo = new QComboBox( FALSE, m_IDLabel, "m_IDCombo" );
    m_IDCombo->setEnabled( TRUE );

    m_IDLabelLayout->addWidget( m_IDCombo, 0, 1 );

    m_channelLabel = new QLabel( m_IDLabel, "m_channelLabel" );
    m_channelLabel->setMinimumSize( QSize( 80, 0 ) );

    m_IDLabelLayout->addWidget( m_channelLabel, 1, 0 );

    m_channelSpinBox = new QSpinBox( m_IDLabel, "m_channelSpinBox" );
    m_channelSpinBox->setMaxValue( 127 );

    m_IDLabelLayout->addWidget( m_channelSpinBox, 1, 1 );
    UI_VCButtonPropertiesLayout->addWidget( m_IDLabel );

    m_onButtonPressGroup = new QButtonGroup( this, "m_onButtonPressGroup" );

    m_toggle = new QRadioButton( m_onButtonPressGroup, "m_toggle" );
    m_toggle->setGeometry( QRect( 11, 20, 266, 19 ) );
    m_onButtonPressGroup->insert( m_toggle, 1 );

    m_flash = new QRadioButton( m_onButtonPressGroup, "m_flash" );
    m_flash->setEnabled( TRUE );
    m_flash->setGeometry( QRect( 11, 45, 266, 19 ) );
    m_onButtonPressGroup->insert( m_flash, 2 );

    m_forward = new QRadioButton( m_onButtonPressGroup, "m_forward" );
    m_forward->setEnabled( FALSE );
    m_forward->setGeometry( QRect( 11, 70, 266, 19 ) );
    m_onButtonPressGroup->insert( m_forward, 3 );

    m_backward = new QRadioButton( m_onButtonPressGroup, "m_backward" );
    m_backward->setEnabled( FALSE );
    m_backward->setGeometry( QRect( 11, 95, 266, 19 ) );
    m_onButtonPressGroup->insert( m_backward, 4 );
    UI_VCButtonPropertiesLayout->addWidget( m_onButtonPressGroup );

    m_experimental = new QGroupBox( this, "m_experimental" );
    m_experimental->setColumnLayout(0, Qt::Vertical );
    m_experimental->layout()->setSpacing( 6 );
    m_experimental->layout()->setMargin( 11 );
    m_experimentalLayout = new QVBoxLayout( m_experimental->layout() );
    m_experimentalLayout->setAlignment( Qt::AlignTop );

    m_stopFunctionsCheck = new QCheckBox( m_experimental, "m_stopFunctionsCheck" );
    m_experimentalLayout->addWidget( m_stopFunctionsCheck );
    UI_VCButtonPropertiesLayout->addWidget( m_experimental );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 
    spacer8 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout9->addItem( spacer8 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout9->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout9->addWidget( m_cancel );
    UI_VCButtonPropertiesLayout->addLayout( layout9 );
    languageChange();
    resize( QSize(310, 493).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_onButtonPressGroup, SIGNAL( clicked(int) ), this, SLOT( slotPressGroupClicked(int) ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_attachFunction, SIGNAL( clicked() ), this, SLOT( slotAttachFunctionClicked() ) );
    connect( m_detachFunction, SIGNAL( clicked() ), this, SLOT( slotDetachFunctionClicked() ) );
    connect( m_attachKey, SIGNAL( clicked() ), this, SLOT( slotAttachKeyClicked() ) );
    connect( m_detachKey, SIGNAL( clicked() ), this, SLOT( slotDetachKeyClicked() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( slotOKClicked() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( slotCancelClicked() ) );

    // tab order
    setTabOrder( m_nameEdit, m_functionEdit );
    setTabOrder( m_functionEdit, m_attachFunction );
    setTabOrder( m_attachFunction, m_detachFunction );
    setTabOrder( m_detachFunction, m_keyEdit );
    setTabOrder( m_keyEdit, m_attachKey );
    setTabOrder( m_attachKey, m_detachKey );
    setTabOrder( m_detachKey, m_toggle );
    setTabOrder( m_toggle, m_flash );
    setTabOrder( m_flash, m_forward );
    setTabOrder( m_forward, m_backward );
    setTabOrder( m_backward, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_VCButtonProperties::~UI_VCButtonProperties()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_VCButtonProperties::languageChange()
{
    setCaption( tr( "Button Properties" ) );
    m_generalInfoGroup->setTitle( tr( "General Info" ) );
    m_nameLabel->setText( tr( "Name" ) );
    QToolTip::add( m_nameEdit, tr( "The name to be displayed on this button" ) );
    m_functionLabel->setText( tr( "Function" ) );
    QToolTip::add( m_functionEdit, tr( "Attached function and its device" ) );
    m_attachFunction->setText( QString::null );
    QToolTip::add( m_attachFunction, tr( "Attach a function to this button" ) );
    m_detachFunction->setText( QString::null );
    QToolTip::add( m_detachFunction, tr( "Detach the current function" ) );
    m_keyboardHotkeyGroup->setTitle( tr( "Keyboard Hotkey" ) );
    m_keyLabel->setText( tr( "Key" ) );
    QToolTip::add( m_keyEdit, tr( "The key (combination) that acts as if you would point and click on this button in virtual console" ) );
    m_attachKey->setText( QString::null );
    QToolTip::add( m_attachKey, tr( "Attach a keyboard key (combination) to this button" ) );
    m_detachKey->setText( QString::null );
    QToolTip::add( m_detachKey, tr( "Detach key (combination)" ) );
    m_IDLabel->setTitle( tr( "External Input/Output Settings" ) );
    m_keyLabel_2->setText( tr( "ID" ) );
    m_IDCombo->clear();
    m_IDCombo->insertItem( tr( "Midi 1 - ControlChange" ) );
    QToolTip::add( m_IDCombo, tr( "The device and type of control." ) );
    m_channelLabel->setText( tr( "Channel" ) );
    QToolTip::add( m_channelSpinBox, tr( "The control change number." ) );
    m_onButtonPressGroup->setTitle( tr( "On Button/Key Press..." ) );
    m_toggle->setText( tr( "Toggle Function on/off" ) );
    QToolTip::add( m_toggle, tr( "Every other key press starts and every other press stops the attached function." ) );
    m_flash->setText( tr( "Flash" ) );
    QToolTip::add( m_flash, tr( "Flash the selected function" ) );
    m_forward->setText( tr( "Step Forward (Chaser only)" ) );
    QToolTip::add( m_forward, tr( "Signal the function to take one step forward (available only for chasers)" ) );
    m_backward->setText( tr( "Step Backward (Chaser only)" ) );
    QToolTip::add( m_backward, tr( "Signal the function to take one step backward (available only for chasers)" ) );
    m_experimental->setTitle( tr( "Experimental Stuff" ) );
    m_stopFunctionsCheck->setText( tr( "Stop all running functions" ) );
    m_ok->setText( tr( "OK" ) );
    m_cancel->setText( tr( "Cancel" ) );
}

void UI_VCButtonProperties::slotCancelClicked()
{
    qWarning( "UI_VCButtonProperties::slotCancelClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotAttachFunctionClicked()
{
    qWarning( "UI_VCButtonProperties::slotAttachFunctionClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotDetachFunctionClicked()
{
    qWarning( "UI_VCButtonProperties::slotDetachFunctionClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotAttachKeyClicked()
{
    qWarning( "UI_VCButtonProperties::slotAttachKeyClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotDetachKeyClicked()
{
    qWarning( "UI_VCButtonProperties::slotDetachKeyClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotOKClicked()
{
    qWarning( "UI_VCButtonProperties::slotOKClicked(): Not implemented yet" );
}

void UI_VCButtonProperties::slotPressGroupClicked(int)
{
    qWarning( "UI_VCButtonProperties::slotPressGroupClicked(int): Not implemented yet" );
}

