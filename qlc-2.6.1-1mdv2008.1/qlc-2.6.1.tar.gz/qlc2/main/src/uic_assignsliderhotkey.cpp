/****************************************************************************
** Form implementation generated from reading ui file 'src/assignsliderhotkey.ui'
**
** Created: Thu Nov 30 00:54:40 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_assignsliderhotkey.h"

#include <qvariant.h>
#include <qtextview.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qlabel.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_AssignSliderHotKey as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_AssignSliderHotKey::UI_AssignSliderHotKey( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_AssignSliderHotKey" );
    UI_AssignSliderHotKeyLayout = new QVBoxLayout( this, 11, 6, "UI_AssignSliderHotKeyLayout"); 

    m_infoText = new QTextView( this, "m_infoText" );
    m_infoText->setTextFormat( QTextView::AutoText );
    UI_AssignSliderHotKeyLayout->addWidget( m_infoText );

    m_assignGroup = new QGroupBox( this, "m_assignGroup" );
    m_assignGroup->setColumnLayout(0, Qt::Vertical );
    m_assignGroup->layout()->setSpacing( 6 );
    m_assignGroup->layout()->setMargin( 11 );
    m_assignGroupLayout = new QGridLayout( m_assignGroup->layout() );
    m_assignGroupLayout->setAlignment( Qt::AlignTop );

    m_previewUpEdit = new QLineEdit( m_assignGroup, "m_previewUpEdit" );

    m_assignGroupLayout->addWidget( m_previewUpEdit, 1, 0 );

    m_previewDownLabel = new QLabel( m_assignGroup, "m_previewDownLabel" );
    m_previewDownLabel->setAlignment( int( QLabel::AlignCenter ) );

    m_assignGroupLayout->addWidget( m_previewDownLabel, 2, 0 );

    m_previewDownEdit = new QLineEdit( m_assignGroup, "m_previewDownEdit" );

    m_assignGroupLayout->addWidget( m_previewDownEdit, 3, 0 );

    m_previewUpLabel = new QLabel( m_assignGroup, "m_previewUpLabel" );
    m_previewUpLabel->setAlignment( int( QLabel::AlignCenter ) );

    m_assignGroupLayout->addWidget( m_previewUpLabel, 0, 0 );
    UI_AssignSliderHotKeyLayout->addWidget( m_assignGroup );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_ok = new QPushButton( this, "m_ok" );
    layout9->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout9->addWidget( m_cancel );
    UI_AssignSliderHotKeyLayout->addLayout( layout9 );
    languageChange();
    resize( QSize(282, 439).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_AssignSliderHotKey::~UI_AssignSliderHotKey()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_AssignSliderHotKey::languageChange()
{
    setCaption( tr( "Assign Hotkeys to Sliders" ) );
    m_assignGroup->setTitle( tr( "Assign keys for the slider" ) );
    m_previewDownLabel->setText( tr( "Preview hotkey down" ) );
    m_previewUpLabel->setText( tr( "Preview hotkey up" ) );
    m_ok->setText( tr( "OK" ) );
    m_cancel->setText( tr( "Cancel" ) );
}

