/****************************************************************************
** VCDockSliderProperties meta object code from reading C++ file 'vcdocksliderproperties.h'
**
** Created: Thu Nov 30 00:57:56 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "vcdocksliderproperties.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VCDockSliderProperties::className() const
{
    return "VCDockSliderProperties";
}

QMetaObject *VCDockSliderProperties::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCDockSliderProperties( "VCDockSliderProperties", &VCDockSliderProperties::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCDockSliderProperties::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCDockSliderProperties", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCDockSliderProperties::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCDockSliderProperties", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCDockSliderProperties::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_VCDockSliderProperties::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotBehaviourSelected", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotAllChannelsClicked", 0, 0 };
    static const QUMethod slot_2 = {"slotInvertChannelsClicked", 0, 0 };
    static const QUMethod slot_3 = {"slotClearChannelsClicked", 0, 0 };
    static const QUMethod slot_4 = {"slotDeviceChannelsClicked", 0, 0 };
    static const QUMethod slot_5 = {"slotRoleChannelsClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotAttachKeyClicked", 0, 0 };
    static const QUMethod slot_7 = {"slotDetachKeyClicked", 0, 0 };
    static const QUMethod slot_8 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_9 = {"slotCancelClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotBehaviourSelected(int)", &slot_0, QMetaData::Public },
	{ "slotAllChannelsClicked()", &slot_1, QMetaData::Public },
	{ "slotInvertChannelsClicked()", &slot_2, QMetaData::Public },
	{ "slotClearChannelsClicked()", &slot_3, QMetaData::Public },
	{ "slotDeviceChannelsClicked()", &slot_4, QMetaData::Public },
	{ "slotRoleChannelsClicked()", &slot_5, QMetaData::Public },
	{ "slotAttachKeyClicked()", &slot_6, QMetaData::Public },
	{ "slotDetachKeyClicked()", &slot_7, QMetaData::Public },
	{ "slotOKClicked()", &slot_8, QMetaData::Public },
	{ "slotCancelClicked()", &slot_9, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"VCDockSliderProperties", parentObject,
	slot_tbl, 10,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCDockSliderProperties.setMetaObject( metaObj );
    return metaObj;
}

void* VCDockSliderProperties::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCDockSliderProperties" ) )
	return this;
    return UI_VCDockSliderProperties::qt_cast( clname );
}

bool VCDockSliderProperties::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotBehaviourSelected((int)static_QUType_int.get(_o+1)); break;
    case 1: slotAllChannelsClicked(); break;
    case 2: slotInvertChannelsClicked(); break;
    case 3: slotClearChannelsClicked(); break;
    case 4: slotDeviceChannelsClicked(); break;
    case 5: slotRoleChannelsClicked(); break;
    case 6: slotAttachKeyClicked(); break;
    case 7: slotDetachKeyClicked(); break;
    case 8: slotOKClicked(); break;
    case 9: slotCancelClicked(); break;
    default:
	return UI_VCDockSliderProperties::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VCDockSliderProperties::qt_emit( int _id, QUObject* _o )
{
    return UI_VCDockSliderProperties::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCDockSliderProperties::qt_property( int id, int f, QVariant* v)
{
    return UI_VCDockSliderProperties::qt_property( id, f, v);
}

bool VCDockSliderProperties::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
