/****************************************************************************
** KeyBind meta object code from reading C++ file 'keybind.h'
**
** Created: Thu Nov 30 00:57:44 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "keybind.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *KeyBind::className() const
{
    return "KeyBind";
}

QMetaObject *KeyBind::metaObj = 0;
static QMetaObjectCleanUp cleanUp_KeyBind( "KeyBind", &KeyBind::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString KeyBind::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "KeyBind", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString KeyBind::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "KeyBind", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* KeyBind::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QObject::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "e", &static_QUType_ptr, "QKeyEvent", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotKeyPressed", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "e", &static_QUType_ptr, "QKeyEvent", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotKeyReleased", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "slotKeyPressed(QKeyEvent*)", &slot_0, QMetaData::Public },
	{ "slotKeyReleased(QKeyEvent*)", &slot_1, QMetaData::Public }
    };
    static const QUMethod signal_0 = {"pressed", 0, 0 };
    static const QUMethod signal_1 = {"released", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "pressed()", &signal_0, QMetaData::Public },
	{ "released()", &signal_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"KeyBind", parentObject,
	slot_tbl, 2,
	signal_tbl, 2,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_KeyBind.setMetaObject( metaObj );
    return metaObj;
}

void* KeyBind::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "KeyBind" ) )
	return this;
    return QObject::qt_cast( clname );
}

// SIGNAL pressed
void KeyBind::pressed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

// SIGNAL released
void KeyBind::released()
{
    activate_signal( staticMetaObject()->signalOffset() + 1 );
}

bool KeyBind::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotKeyPressed((QKeyEvent*)static_QUType_ptr.get(_o+1)); break;
    case 1: slotKeyReleased((QKeyEvent*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QObject::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool KeyBind::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: pressed(); break;
    case 1: released(); break;
    default:
	return QObject::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool KeyBind::qt_property( int id, int f, QVariant* v)
{
    return QObject::qt_property( id, f, v);
}

bool KeyBind::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
