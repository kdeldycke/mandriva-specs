/****************************************************************************
** Form interface generated from reading ui file 'src/assignhotkey.ui'
**
** Created: Thu Nov 30 00:54:39 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_ASSIGNHOTKEY_H
#define UI_ASSIGNHOTKEY_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QTextView;
class QLabel;
class QLineEdit;
class QPushButton;

class UI_AssignHotKey : public QDialog
{
    Q_OBJECT

public:
    UI_AssignHotKey( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_AssignHotKey();

    QTextView* m_infoText;
    QLabel* m_previewLabel;
    QLineEdit* m_previewEdit;
    QPushButton* m_ok;
    QPushButton* m_cancel;

protected:
    QVBoxLayout* UI_AssignHotKeyLayout;
    QHBoxLayout* layout9;

protected slots:
    virtual void languageChange();

};

#endif // UI_ASSIGNHOTKEY_H
