/****************************************************************************
** Form interface generated from reading ui file 'src/newdevice.ui'
**
** Created: Thu Nov 30 00:54:58 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_NEWDEVICE_H
#define UI_NEWDEVICE_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QListView;
class QListViewItem;
class QGroupBox;
class QLabel;
class QLineEdit;
class QSpinBox;
class QFrame;
class QCheckBox;
class QPushButton;

class UI_NewDevice : public QDialog
{
    Q_OBJECT

public:
    UI_NewDevice( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_NewDevice();

    QListView* m_tree;
    QGroupBox* groupBox1;
    QLabel* m_nameLabel;
    QLineEdit* m_nameEdit;
    QLabel* m_addressLabel;
    QSpinBox* m_addressSpin;
    QLabel* m_universeLabel;
    QSpinBox* m_universeSpin;
    QFrame* line2;
    QLabel* m_channelsLabel;
    QSpinBox* m_channelsSpin;
    QGroupBox* groupBox2;
    QLabel* textLabel1;
    QSpinBox* m_multipleNumberSpin;
    QLabel* textLabel2;
    QSpinBox* m_addressGapSpin;
    QCheckBox* m_treeOpenCheckBox;
    QFrame* line1;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotOKClicked();
    virtual void slotCancelClicked();
    virtual void slotSelectionChanged(QListViewItem*);
    virtual void slotNameChanged(const QString&);
    virtual void slotTreeDoubleClicked(QListViewItem*);
    virtual void slotTreeOpenCheckBoxClicked();
    virtual void slotDIPClicked();

protected:
    QVBoxLayout* UI_NewDeviceLayout;
    QHBoxLayout* layout11;
    QVBoxLayout* layout10;
    QSpacerItem* spacer1;
    QVBoxLayout* groupBox1Layout;
    QHBoxLayout* layout1;
    QHBoxLayout* layout3;
    QHBoxLayout* layout10_2;
    QHBoxLayout* layout10_2_2;
    QVBoxLayout* groupBox2Layout;
    QHBoxLayout* layout8;
    QHBoxLayout* layout9;
    QHBoxLayout* layout6;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // UI_NEWDEVICE_H
