/****************************************************************************
** Form interface generated from reading ui file 'src/chasereditor.ui'
**
** Created: Thu Nov 30 00:54:43 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_CHASEREDITOR_H
#define UI_CHASEREDITOR_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QLabel;
class QLineEdit;
class QListView;
class QListViewItem;
class QPushButton;
class QButtonGroup;
class QRadioButton;
class QFrame;

class UI_ChaserEditor : public QDialog
{
    Q_OBJECT

public:
    UI_ChaserEditor( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_ChaserEditor();

    QLabel* m_nameLabel;
    QLineEdit* m_nameEdit;
    QListView* m_stepList;
    QPushButton* m_addStep;
    QPushButton* m_removeStep;
    QPushButton* m_raiseButton;
    QPushButton* m_lowerButton;
    QButtonGroup* m_runOrderGroup;
    QRadioButton* m_looping;
    QRadioButton* m_singleShot;
    QRadioButton* m_pingPong;
    QButtonGroup* m_directionGroup;
    QRadioButton* m_forward;
    QRadioButton* m_backward;
    QFrame* line2;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotAddClicked();
    virtual void slotCancelClicked();
    virtual void slotLowerClicked();
    virtual void slotOKClicked();
    virtual void slotRaiseClicked();
    virtual void slotRemoveClicked();

protected:
    QVBoxLayout* UI_ChaserEditorLayout;
    QHBoxLayout* layout4;
    QHBoxLayout* layout9;
    QVBoxLayout* layout8;
    QSpacerItem* spacer2;
    QHBoxLayout* layout13;
    QHBoxLayout* m_runOrderGroupLayout;
    QHBoxLayout* m_directionGroupLayout;
    QHBoxLayout* layout6;
    QSpacerItem* spacer3;

protected slots:
    virtual void languageChange();

};

#endif // UI_CHASEREDITOR_H
