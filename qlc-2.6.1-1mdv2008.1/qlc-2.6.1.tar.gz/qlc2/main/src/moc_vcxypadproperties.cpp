/****************************************************************************
** VCXYPadProperties meta object code from reading C++ file 'vcxypadproperties.h'
**
** Created: Thu Nov 30 00:58:01 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "vcxypadproperties.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *VCXYPadProperties::className() const
{
    return "VCXYPadProperties";
}

QMetaObject *VCXYPadProperties::metaObj = 0;
static QMetaObjectCleanUp cleanUp_VCXYPadProperties( "VCXYPadProperties", &VCXYPadProperties::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString VCXYPadProperties::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCXYPadProperties", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString VCXYPadProperties::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "VCXYPadProperties", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* VCXYPadProperties::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_VCXYPadProperties::staticMetaObject();
    static const QUMethod slot_0 = {"slotAddX", 0, 0 };
    static const QUMethod slot_1 = {"slotRemoveX", 0, 0 };
    static const QUMethod slot_2 = {"slotAddY", 0, 0 };
    static const QUMethod slot_3 = {"slotRemoveY", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ "list", &static_QUType_ptr, "QListView", QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotAdd", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotMaxXChanged", 1, param_slot_5 };
    static const QUParameter param_slot_6[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_6 = {"slotMinXChanged", 1, param_slot_6 };
    static const QUParameter param_slot_7[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotMaxYChanged", 1, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotMinYChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotReverseXActivated", 1, param_slot_9 };
    static const QUParameter param_slot_10[] = {
	{ "text", &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_10 = {"slotReverseYActivated", 1, param_slot_10 };
    static const QUParameter param_slot_11[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotSelectionXChanged", 1, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotSelectionYChanged", 1, param_slot_12 };
    static const QUParameter param_slot_13[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "point", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "column", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_13 = {"slotContextMenuRequested", 3, param_slot_13 };
    static const QUMethod slot_14 = {"slotOKClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotAddX()", &slot_0, QMetaData::Protected },
	{ "slotRemoveX()", &slot_1, QMetaData::Protected },
	{ "slotAddY()", &slot_2, QMetaData::Protected },
	{ "slotRemoveY()", &slot_3, QMetaData::Protected },
	{ "slotAdd(QListView*)", &slot_4, QMetaData::Protected },
	{ "slotMaxXChanged(const QString&)", &slot_5, QMetaData::Protected },
	{ "slotMinXChanged(const QString&)", &slot_6, QMetaData::Protected },
	{ "slotMaxYChanged(const QString&)", &slot_7, QMetaData::Protected },
	{ "slotMinYChanged(const QString&)", &slot_8, QMetaData::Protected },
	{ "slotReverseXActivated(const QString&)", &slot_9, QMetaData::Protected },
	{ "slotReverseYActivated(const QString&)", &slot_10, QMetaData::Protected },
	{ "slotSelectionXChanged(QListViewItem*)", &slot_11, QMetaData::Protected },
	{ "slotSelectionYChanged(QListViewItem*)", &slot_12, QMetaData::Protected },
	{ "slotContextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_13, QMetaData::Protected },
	{ "slotOKClicked()", &slot_14, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"VCXYPadProperties", parentObject,
	slot_tbl, 15,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_VCXYPadProperties.setMetaObject( metaObj );
    return metaObj;
}

void* VCXYPadProperties::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "VCXYPadProperties" ) )
	return this;
    return UI_VCXYPadProperties::qt_cast( clname );
}

bool VCXYPadProperties::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotAddX(); break;
    case 1: slotRemoveX(); break;
    case 2: slotAddY(); break;
    case 3: slotRemoveY(); break;
    case 4: slotAdd((QListView*)static_QUType_ptr.get(_o+1)); break;
    case 5: slotMaxXChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 6: slotMinXChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 7: slotMaxYChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 8: slotMinYChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 9: slotReverseXActivated((const QString&)static_QUType_QString.get(_o+1)); break;
    case 10: slotReverseYActivated((const QString&)static_QUType_QString.get(_o+1)); break;
    case 11: slotSelectionXChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 12: slotSelectionYChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 13: slotContextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 14: slotOKClicked(); break;
    default:
	return UI_VCXYPadProperties::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool VCXYPadProperties::qt_emit( int _id, QUObject* _o )
{
    return UI_VCXYPadProperties::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool VCXYPadProperties::qt_property( int id, int f, QVariant* v)
{
    return UI_VCXYPadProperties::qt_property( id, f, v);
}

bool VCXYPadProperties::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
