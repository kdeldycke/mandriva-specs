/****************************************************************************
** Form interface generated from reading ui file 'src/editscenevalue.ui'
**
** Created: Thu Nov 30 00:54:50 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_EDITSCENEVALUE_H
#define UI_EDITSCENEVALUE_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QPushButton;
class QGroupBox;
class QLabel;
class QComboBox;
class QSpinBox;

class UI_EditSceneValue : public QDialog
{
    Q_OBJECT

public:
    UI_EditSceneValue( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_EditSceneValue();

    QPushButton* m_cancel;
    QPushButton* m_ok;
    QGroupBox* m_groupBox;
    QLabel* TextLabel2;
    QComboBox* m_presetCombo;
    QLabel* TextLabel3;
    QSpinBox* m_valueSpin;
    QComboBox* m_typeCombo;
    QLabel* TextLabel4;

public slots:
    virtual void slotTypeActivated(const QString &);

protected:
    QGridLayout* UI_EditSceneValueLayout;
    QGridLayout* m_groupBoxLayout;

protected slots:
    virtual void languageChange();

};

#endif // UI_EDITSCENEVALUE_H
