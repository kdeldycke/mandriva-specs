/****************************************************************************
** Form implementation generated from reading ui file 'src/efxeditor.ui'
**
** Created: Thu Nov 30 00:54:53 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "src/uic_efxeditor.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qtabwidget.h>
#include <qwidget.h>
#include <qframe.h>
#include <qgroupbox.h>
#include <qcombobox.h>
#include <qspinbox.h>
#include <qbuttongroup.h>
#include <qradiobutton.h>
#include <qcheckbox.h>
#include <qheader.h>
#include <qlistview.h>
#include <qslider.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_EFXEditor as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_EFXEditor::UI_EFXEditor( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_EFXEditor" );
    UI_EFXEditorLayout = new QVBoxLayout( this, 11, 6, "UI_EFXEditorLayout"); 

    layout15 = new QHBoxLayout( 0, 0, 6, "layout15"); 

    m_nameLabel = new QLabel( this, "m_nameLabel" );
    layout15->addWidget( m_nameLabel );

    m_nameEdit = new QLineEdit( this, "m_nameEdit" );
    layout15->addWidget( m_nameEdit );
    UI_EFXEditorLayout->addLayout( layout15 );

    m_tab = new QTabWidget( this, "m_tab" );

    tab = new QWidget( m_tab, "tab" );
    tabLayout = new QGridLayout( tab, 1, 1, 11, 6, "tabLayout"); 

    layout26 = new QVBoxLayout( 0, 0, 6, "layout26"); 

    m_previewFrame = new QFrame( tab, "m_previewFrame" );
    m_previewFrame->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_previewFrame->sizePolicy().hasHeightForWidth() ) );
    m_previewFrame->setMinimumSize( QSize( 255, 255 ) );
    m_previewFrame->setMaximumSize( QSize( 255, 255 ) );
    m_previewFrame->setFrameShape( QFrame::StyledPanel );
    m_previewFrame->setFrameShadow( QFrame::Sunken );
    layout26->addWidget( m_previewFrame );

    m_axesGroup = new QGroupBox( tab, "m_axesGroup" );
    m_axesGroup->setColumnLayout(0, Qt::Vertical );
    m_axesGroup->layout()->setSpacing( 6 );
    m_axesGroup->layout()->setMargin( 11 );
    m_axesGroupLayout = new QVBoxLayout( m_axesGroup->layout() );
    m_axesGroupLayout->setAlignment( Qt::AlignTop );

    layout14 = new QHBoxLayout( 0, 0, 6, "layout14"); 

    m_horizontalLabel = new QLabel( m_axesGroup, "m_horizontalLabel" );
    m_horizontalLabel->setMinimumSize( QSize( 70, 0 ) );
    layout14->addWidget( m_horizontalLabel );

    m_horizontalCombo = new QComboBox( FALSE, m_axesGroup, "m_horizontalCombo" );
    layout14->addWidget( m_horizontalCombo );
    m_axesGroupLayout->addLayout( layout14 );

    layout15_2 = new QHBoxLayout( 0, 0, 6, "layout15_2"); 

    m_verticalLabel = new QLabel( m_axesGroup, "m_verticalLabel" );
    m_verticalLabel->setMinimumSize( QSize( 70, 0 ) );
    layout15_2->addWidget( m_verticalLabel );

    m_verticalCombo = new QComboBox( FALSE, m_axesGroup, "m_verticalCombo" );
    layout15_2->addWidget( m_verticalCombo );
    m_axesGroupLayout->addLayout( layout15_2 );
    layout26->addWidget( m_axesGroup );

    tabLayout->addLayout( layout26, 0, 0 );

    layout37 = new QVBoxLayout( 0, 0, 6, "layout37"); 

    m_algorithmGroup = new QGroupBox( tab, "m_algorithmGroup" );
    m_algorithmGroup->setColumnLayout(0, Qt::Vertical );
    m_algorithmGroup->layout()->setSpacing( 6 );
    m_algorithmGroup->layout()->setMargin( 11 );
    m_algorithmGroupLayout = new QHBoxLayout( m_algorithmGroup->layout() );
    m_algorithmGroupLayout->setAlignment( Qt::AlignTop );

    m_algorithmCombo = new QComboBox( FALSE, m_algorithmGroup, "m_algorithmCombo" );
    m_algorithmCombo->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)7, (QSizePolicy::SizeType)0, 0, 0, m_algorithmCombo->sizePolicy().hasHeightForWidth() ) );
    m_algorithmGroupLayout->addWidget( m_algorithmCombo );
    layout37->addWidget( m_algorithmGroup );

    m_parametersGroup = new QGroupBox( tab, "m_parametersGroup" );
    m_parametersGroup->setColumnLayout(0, Qt::Vertical );
    m_parametersGroup->layout()->setSpacing( 6 );
    m_parametersGroup->layout()->setMargin( 11 );
    m_parametersGroupLayout = new QVBoxLayout( m_parametersGroup->layout() );
    m_parametersGroupLayout->setAlignment( Qt::AlignTop );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 

    m_widthLabel = new QLabel( m_parametersGroup, "m_widthLabel" );
    layout6->addWidget( m_widthLabel );

    m_widthSpin = new QSpinBox( m_parametersGroup, "m_widthSpin" );
    m_widthSpin->setMaxValue( 127 );
    m_widthSpin->setValue( 127 );
    layout6->addWidget( m_widthSpin );
    m_parametersGroupLayout->addLayout( layout6 );

    layout7 = new QHBoxLayout( 0, 0, 6, "layout7"); 

    m_heightLabel = new QLabel( m_parametersGroup, "m_heightLabel" );
    layout7->addWidget( m_heightLabel );

    m_heightSpin = new QSpinBox( m_parametersGroup, "m_heightSpin" );
    m_heightSpin->setMaxValue( 127 );
    m_heightSpin->setValue( 127 );
    layout7->addWidget( m_heightSpin );
    m_parametersGroupLayout->addLayout( layout7 );

    layout8 = new QHBoxLayout( 0, 0, 6, "layout8"); 

    m_xOffsetLabel = new QLabel( m_parametersGroup, "m_xOffsetLabel" );
    layout8->addWidget( m_xOffsetLabel );

    m_xOffsetSpin = new QSpinBox( m_parametersGroup, "m_xOffsetSpin" );
    m_xOffsetSpin->setMaxValue( 255 );
    m_xOffsetSpin->setValue( 127 );
    layout8->addWidget( m_xOffsetSpin );
    m_parametersGroupLayout->addLayout( layout8 );

    layout36 = new QHBoxLayout( 0, 0, 6, "layout36"); 

    m_yOffsetLabel = new QLabel( m_parametersGroup, "m_yOffsetLabel" );
    layout36->addWidget( m_yOffsetLabel );

    m_yOffsetSpin = new QSpinBox( m_parametersGroup, "m_yOffsetSpin" );
    m_yOffsetSpin->setMaxValue( 255 );
    m_yOffsetSpin->setValue( 127 );
    layout36->addWidget( m_yOffsetSpin );
    m_parametersGroupLayout->addLayout( layout36 );

    layout16 = new QGridLayout( 0, 1, 1, 0, 6, "layout16"); 

    m_rotationLabel = new QLabel( m_parametersGroup, "m_rotationLabel" );

    layout16->addWidget( m_rotationLabel, 0, 0 );

    m_rotationSpin = new QSpinBox( m_parametersGroup, "m_rotationSpin" );
    m_rotationSpin->setMaxValue( 359 );
    m_rotationSpin->setValue( 0 );

    layout16->addWidget( m_rotationSpin, 0, 1 );
    m_parametersGroupLayout->addLayout( layout16 );
    spacer2 = new QSpacerItem( 20, 10, QSizePolicy::Minimum, QSizePolicy::Expanding );
    m_parametersGroupLayout->addItem( spacer2 );

    layout9_2 = new QHBoxLayout( 0, 0, 6, "layout9_2"); 

    m_xFrequencyLabel = new QLabel( m_parametersGroup, "m_xFrequencyLabel" );
    m_xFrequencyLabel->setEnabled( FALSE );
    layout9_2->addWidget( m_xFrequencyLabel );

    m_xFrequencySpin = new QSpinBox( m_parametersGroup, "m_xFrequencySpin" );
    m_xFrequencySpin->setEnabled( FALSE );
    m_xFrequencySpin->setMaxValue( 5 );
    m_xFrequencySpin->setValue( 2 );
    layout9_2->addWidget( m_xFrequencySpin );
    m_parametersGroupLayout->addLayout( layout9_2 );

    layout9_3 = new QHBoxLayout( 0, 0, 6, "layout9_3"); 

    m_yFrequencyLabel = new QLabel( m_parametersGroup, "m_yFrequencyLabel" );
    m_yFrequencyLabel->setEnabled( FALSE );
    layout9_3->addWidget( m_yFrequencyLabel );

    m_yFrequencySpin = new QSpinBox( m_parametersGroup, "m_yFrequencySpin" );
    m_yFrequencySpin->setEnabled( FALSE );
    m_yFrequencySpin->setMaxValue( 5 );
    m_yFrequencySpin->setValue( 1 );
    layout9_3->addWidget( m_yFrequencySpin );
    m_parametersGroupLayout->addLayout( layout9_3 );

    layout9_4 = new QHBoxLayout( 0, 0, 6, "layout9_4"); 

    m_xPhaseLabel = new QLabel( m_parametersGroup, "m_xPhaseLabel" );
    m_xPhaseLabel->setEnabled( FALSE );
    layout9_4->addWidget( m_xPhaseLabel );

    m_xPhaseSpin = new QSpinBox( m_parametersGroup, "m_xPhaseSpin" );
    m_xPhaseSpin->setEnabled( FALSE );
    m_xPhaseSpin->setWrapping( TRUE );
    m_xPhaseSpin->setMaxValue( 360 );
    m_xPhaseSpin->setValue( 90 );
    layout9_4->addWidget( m_xPhaseSpin );
    m_parametersGroupLayout->addLayout( layout9_4 );

    layout9_5 = new QHBoxLayout( 0, 0, 6, "layout9_5"); 

    m_yPhaseLabel = new QLabel( m_parametersGroup, "m_yPhaseLabel" );
    m_yPhaseLabel->setEnabled( FALSE );
    layout9_5->addWidget( m_yPhaseLabel );

    m_yPhaseSpin = new QSpinBox( m_parametersGroup, "m_yPhaseSpin" );
    m_yPhaseSpin->setEnabled( FALSE );
    m_yPhaseSpin->setWrapping( TRUE );
    m_yPhaseSpin->setMaxValue( 360 );
    m_yPhaseSpin->setValue( 90 );
    layout9_5->addWidget( m_yPhaseSpin );
    m_parametersGroupLayout->addLayout( layout9_5 );
    layout37->addWidget( m_parametersGroup );

    tabLayout->addLayout( layout37, 0, 1 );
    m_tab->insertTab( tab, QString::fromLatin1("") );

    tab_2 = new QWidget( m_tab, "tab_2" );
    tabLayout_2 = new QVBoxLayout( tab_2, 11, 6, "tabLayout_2"); 

    layout16_2 = new QHBoxLayout( 0, 0, 6, "layout16_2"); 

    m_runOrderGroup = new QButtonGroup( tab_2, "m_runOrderGroup" );
    m_runOrderGroup->setEnabled( TRUE );
    m_runOrderGroup->setProperty( "selectedId", -1 );
    m_runOrderGroup->setColumnLayout(0, Qt::Vertical );
    m_runOrderGroup->layout()->setSpacing( 6 );
    m_runOrderGroup->layout()->setMargin( 11 );
    m_runOrderGroupLayout = new QVBoxLayout( m_runOrderGroup->layout() );
    m_runOrderGroupLayout->setAlignment( Qt::AlignTop );

    m_loopModeButton = new QRadioButton( m_runOrderGroup, "m_loopModeButton" );
    m_runOrderGroupLayout->addWidget( m_loopModeButton );

    m_singleShotModeButton = new QRadioButton( m_runOrderGroup, "m_singleShotModeButton" );
    m_singleShotModeButton->setEnabled( TRUE );
    m_runOrderGroup->insert( m_singleShotModeButton, 1 );
    m_runOrderGroupLayout->addWidget( m_singleShotModeButton );

    m_pingPongModeButton = new QRadioButton( m_runOrderGroup, "m_pingPongModeButton" );
    m_runOrderGroup->insert( m_pingPongModeButton, 2 );
    m_runOrderGroupLayout->addWidget( m_pingPongModeButton );
    layout16_2->addWidget( m_runOrderGroup );

    m_directionGroup = new QButtonGroup( tab_2, "m_directionGroup" );
    m_directionGroup->setEnabled( TRUE );
    m_directionGroup->setProperty( "selectedId", -1 );
    m_directionGroup->setColumnLayout(0, Qt::Vertical );
    m_directionGroup->layout()->setSpacing( 6 );
    m_directionGroup->layout()->setMargin( 11 );
    m_directionGroupLayout = new QVBoxLayout( m_directionGroup->layout() );
    m_directionGroupLayout->setAlignment( Qt::AlignTop );

    m_forwardsDirectionButton = new QRadioButton( m_directionGroup, "m_forwardsDirectionButton" );
    m_directionGroupLayout->addWidget( m_forwardsDirectionButton );

    m_backwardsDirectionButton = new QRadioButton( m_directionGroup, "m_backwardsDirectionButton" );
    m_directionGroupLayout->addWidget( m_backwardsDirectionButton );
    layout16_2->addWidget( m_directionGroup );
    tabLayout_2->addLayout( layout16_2 );

    layout21 = new QHBoxLayout( 0, 0, 6, "layout21"); 

    m_blackoutFeatureGroup = new QGroupBox( tab_2, "m_blackoutFeatureGroup" );
    m_blackoutFeatureGroup->setEnabled( TRUE );
    m_blackoutFeatureGroup->setColumnLayout(0, Qt::Vertical );
    m_blackoutFeatureGroup->layout()->setSpacing( 6 );
    m_blackoutFeatureGroup->layout()->setMargin( 11 );
    m_blackoutFeatureGroupLayout = new QVBoxLayout( m_blackoutFeatureGroup->layout() );
    m_blackoutFeatureGroupLayout->setAlignment( Qt::AlignTop );

    m_startSceneCheckbox = new QCheckBox( m_blackoutFeatureGroup, "m_startSceneCheckbox" );
    m_startSceneCheckbox->setEnabled( TRUE );
    m_blackoutFeatureGroupLayout->addWidget( m_startSceneCheckbox );

    m_startSceneList = new QListView( m_blackoutFeatureGroup, "m_startSceneList" );
    m_startSceneList->addColumn( tr( "Scene" ) );
    m_startSceneList->setEnabled( FALSE );
    m_startSceneList->setResizeMode( QListView::LastColumn );
    m_blackoutFeatureGroupLayout->addWidget( m_startSceneList );
    layout21->addWidget( m_blackoutFeatureGroup );

    m_blackoutFeatureGroup_2 = new QGroupBox( tab_2, "m_blackoutFeatureGroup_2" );
    m_blackoutFeatureGroup_2->setEnabled( TRUE );
    m_blackoutFeatureGroup_2->setColumnLayout(0, Qt::Vertical );
    m_blackoutFeatureGroup_2->layout()->setSpacing( 6 );
    m_blackoutFeatureGroup_2->layout()->setMargin( 11 );
    m_blackoutFeatureGroup_2Layout = new QVBoxLayout( m_blackoutFeatureGroup_2->layout() );
    m_blackoutFeatureGroup_2Layout->setAlignment( Qt::AlignTop );

    m_stopSceneCheckbox = new QCheckBox( m_blackoutFeatureGroup_2, "m_stopSceneCheckbox" );
    m_stopSceneCheckbox->setEnabled( TRUE );
    m_blackoutFeatureGroup_2Layout->addWidget( m_stopSceneCheckbox );

    m_stopSceneList = new QListView( m_blackoutFeatureGroup_2, "m_stopSceneList" );
    m_stopSceneList->addColumn( tr( "Scene" ) );
    m_stopSceneList->setEnabled( FALSE );
    m_stopSceneList->setResizeMode( QListView::LastColumn );
    m_blackoutFeatureGroup_2Layout->addWidget( m_stopSceneList );
    layout21->addWidget( m_blackoutFeatureGroup_2 );
    tabLayout_2->addLayout( layout21 );
    m_tab->insertTab( tab_2, QString::fromLatin1("") );

    TabPage = new QWidget( m_tab, "TabPage" );
    TabPageLayout = new QVBoxLayout( TabPage, 11, 6, "TabPageLayout"); 

    m_modulationParametersGroup = new QButtonGroup( TabPage, "m_modulationParametersGroup" );
    m_modulationParametersGroup->setEnabled( FALSE );
    m_modulationParametersGroup->setColumnLayout(0, Qt::Vertical );
    m_modulationParametersGroup->layout()->setSpacing( 6 );
    m_modulationParametersGroup->layout()->setMargin( 11 );
    m_modulationParametersGroupLayout = new QGridLayout( m_modulationParametersGroup->layout() );
    m_modulationParametersGroupLayout->setAlignment( Qt::AlignTop );

    m_widthButton = new QCheckBox( m_modulationParametersGroup, "m_widthButton" );

    m_modulationParametersGroupLayout->addWidget( m_widthButton, 0, 0 );

    m_heightButton = new QCheckBox( m_modulationParametersGroup, "m_heightButton" );

    m_modulationParametersGroupLayout->addWidget( m_heightButton, 1, 0 );

    m_xOffsetButton = new QCheckBox( m_modulationParametersGroup, "m_xOffsetButton" );

    m_modulationParametersGroupLayout->addWidget( m_xOffsetButton, 2, 0 );

    m_yOffsetButton = new QCheckBox( m_modulationParametersGroup, "m_yOffsetButton" );

    m_modulationParametersGroupLayout->addWidget( m_yOffsetButton, 3, 0 );

    m_xFrequencyButton = new QCheckBox( m_modulationParametersGroup, "m_xFrequencyButton" );

    m_modulationParametersGroupLayout->addWidget( m_xFrequencyButton, 0, 1 );

    m_yFrequencyButton = new QCheckBox( m_modulationParametersGroup, "m_yFrequencyButton" );

    m_modulationParametersGroupLayout->addWidget( m_yFrequencyButton, 1, 1 );

    m_xPhaseButton = new QCheckBox( m_modulationParametersGroup, "m_xPhaseButton" );

    m_modulationParametersGroupLayout->addWidget( m_xPhaseButton, 2, 1 );

    m_yPhaseButton = new QCheckBox( m_modulationParametersGroup, "m_yPhaseButton" );

    m_modulationParametersGroupLayout->addWidget( m_yPhaseButton, 3, 1 );
    TabPageLayout->addWidget( m_modulationParametersGroup );

    m_modulationSpeedGroup = new QGroupBox( TabPage, "m_modulationSpeedGroup" );
    m_modulationSpeedGroup->setEnabled( FALSE );
    m_modulationSpeedGroup->setColumnLayout(0, Qt::Vertical );
    m_modulationSpeedGroup->layout()->setSpacing( 6 );
    m_modulationSpeedGroup->layout()->setMargin( 11 );
    m_modulationSpeedGroupLayout = new QVBoxLayout( m_modulationSpeedGroup->layout() );
    m_modulationSpeedGroupLayout->setAlignment( Qt::AlignTop );

    layout22 = new QHBoxLayout( 0, 0, 6, "layout22"); 

    m_modulationSpeedLabel = new QLabel( m_modulationSpeedGroup, "m_modulationSpeedLabel" );
    layout22->addWidget( m_modulationSpeedLabel );

    m_modulationBusCombo = new QComboBox( FALSE, m_modulationSpeedGroup, "m_modulationBusCombo" );
    layout22->addWidget( m_modulationBusCombo );
    m_modulationSpeedGroupLayout->addLayout( layout22 );
    TabPageLayout->addWidget( m_modulationSpeedGroup );
    m_tab->insertTab( TabPage, QString::fromLatin1("") );
    UI_EFXEditorLayout->addWidget( m_tab );

    layout19 = new QHBoxLayout( 0, 0, 6, "layout19"); 

    m_testRunButton = new QPushButton( this, "m_testRunButton" );
    m_testRunButton->setEnabled( FALSE );
    layout19->addWidget( m_testRunButton );

    m_testRunSpeedSlider = new QSlider( this, "m_testRunSpeedSlider" );
    m_testRunSpeedSlider->setEnabled( FALSE );
    m_testRunSpeedSlider->setMinValue( 1 );
    m_testRunSpeedSlider->setMaxValue( 1280 );
    m_testRunSpeedSlider->setValue( 256 );
    m_testRunSpeedSlider->setOrientation( QSlider::Horizontal );
    m_testRunSpeedSlider->setTickmarks( QSlider::NoMarks );
    layout19->addWidget( m_testRunSpeedSlider );
    spacer4 = new QSpacerItem( 152, 20, QSizePolicy::Preferred, QSizePolicy::Minimum );
    layout19->addItem( spacer4 );

    m_ok = new QPushButton( this, "m_ok" );
    layout19->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout19->addWidget( m_cancel );
    UI_EFXEditorLayout->addLayout( layout19 );
    languageChange();
    resize( QSize(468, 550).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_horizontalCombo, SIGNAL( activated(int) ), this, SLOT( slotHorizontalChannelSelected(int) ) );
    connect( m_verticalCombo, SIGNAL( activated(int) ), this, SLOT( slotVerticalChannelSelected(int) ) );
    connect( m_algorithmCombo, SIGNAL( activated(const QString&) ), this, SLOT( slotAlgorithmSelected(const QString&) ) );
    connect( m_yOffsetSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotYOffsetSpinChanged(int) ) );
    connect( m_xOffsetSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotXOffsetSpinChanged(int) ) );
    connect( m_heightSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotHeightSpinChanged(int) ) );
    connect( m_widthSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotWidthSpinChanged(int) ) );
    connect( m_nameEdit, SIGNAL( textChanged(const QString&) ), this, SLOT( slotNameChanged(const QString&) ) );
    connect( m_xFrequencySpin, SIGNAL( valueChanged(int) ), this, SLOT( slotXFrequencySpinChanged(int) ) );
    connect( m_yFrequencySpin, SIGNAL( valueChanged(int) ), this, SLOT( slotYFrequencySpinChanged(int) ) );
    connect( m_xPhaseSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotXPhaseSpinChanged(int) ) );
    connect( m_yPhaseSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotYPhaseSpinChanged(int) ) );
    connect( m_rotationSpin, SIGNAL( valueChanged(int) ), this, SLOT( slotRotationSpinChanged(int) ) );
    connect( m_testRunButton, SIGNAL( toggled(bool) ), this, SLOT( slotTestRunToggled(bool) ) );
    connect( m_testRunSpeedSlider, SIGNAL( valueChanged(int) ), this, SLOT( slotTestRunSpeedSliderValueChanged(int) ) );
    connect( m_startSceneCheckbox, SIGNAL( toggled(bool) ), this, SLOT( slotStartSceneCheckboxToggled(bool) ) );
    connect( m_startSceneList, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotStartSceneListSelectionChanged(QListViewItem*) ) );
    connect( m_stopSceneList, SIGNAL( selectionChanged(QListViewItem*) ), this, SLOT( slotStopSceneListSelectionChanged(QListViewItem*) ) );
    connect( m_stopSceneCheckbox, SIGNAL( toggled(bool) ), this, SLOT( slotStopSceneCheckboxToggled(bool) ) );
    connect( m_directionGroup, SIGNAL( clicked(int) ), this, SLOT( slotDirectionClicked(int) ) );
    connect( m_runOrderGroup, SIGNAL( clicked(int) ), this, SLOT( slotRunOrderClicked(int) ) );

    // tab order
    setTabOrder( m_nameEdit, m_algorithmCombo );
    setTabOrder( m_algorithmCombo, m_widthSpin );
    setTabOrder( m_widthSpin, m_heightSpin );
    setTabOrder( m_heightSpin, m_xOffsetSpin );
    setTabOrder( m_xOffsetSpin, m_yOffsetSpin );
    setTabOrder( m_yOffsetSpin, m_xFrequencySpin );
    setTabOrder( m_xFrequencySpin, m_yFrequencySpin );
    setTabOrder( m_yFrequencySpin, m_xPhaseSpin );
    setTabOrder( m_xPhaseSpin, m_yPhaseSpin );
    setTabOrder( m_yPhaseSpin, m_horizontalCombo );
    setTabOrder( m_horizontalCombo, m_verticalCombo );
    setTabOrder( m_verticalCombo, m_loopModeButton );
    setTabOrder( m_loopModeButton, m_forwardsDirectionButton );
    setTabOrder( m_forwardsDirectionButton, m_ok );
    setTabOrder( m_ok, m_cancel );
    setTabOrder( m_cancel, m_tab );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_EFXEditor::~UI_EFXEditor()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_EFXEditor::languageChange()
{
    setCaption( tr( "EFX Editor" ) );
    m_nameLabel->setText( tr( "Name:" ) );
    QToolTip::add( m_nameEdit, tr( "The EFX name" ) );
    m_axesGroup->setTitle( tr( "Axes" ) );
    m_horizontalLabel->setText( tr( "Horizontal (X)" ) );
    QToolTip::add( m_horizontalCombo, tr( "Horizontal (X) axis channel (usually pan)" ) );
    m_verticalLabel->setText( tr( "Vertical (Y)" ) );
    QToolTip::add( m_verticalCombo, tr( "Vertical (Y) axis channel (usually tilt)" ) );
    m_algorithmGroup->setTitle( tr( "Algorithm" ) );
    QToolTip::add( m_algorithmCombo, tr( "Selected EFX algorithm" ) );
    m_parametersGroup->setTitle( tr( "Parameters" ) );
    m_widthLabel->setText( tr( "Width" ) );
    QToolTip::add( m_widthSpin, tr( "The width of the pattern" ) );
    m_heightLabel->setText( tr( "Height" ) );
    QToolTip::add( m_heightSpin, tr( "The height of the pattern" ) );
    m_xOffsetLabel->setText( tr( "X Offset" ) );
    QToolTip::add( m_xOffsetSpin, tr( "The horizontal center point of the pattern" ) );
    m_yOffsetLabel->setText( tr( "Y Offset" ) );
    QToolTip::add( m_yOffsetSpin, tr( "The vertical center point of the pattern" ) );
    m_rotationLabel->setText( tr( "Rotation" ) );
    QToolTip::add( m_rotationSpin, tr( "The vertical center point of the pattern" ) );
    m_xFrequencyLabel->setText( tr( "X Frequency" ) );
    m_yFrequencyLabel->setText( tr( "Y Frequency" ) );
    m_xPhaseLabel->setText( tr( "X Phase" ) );
    m_yPhaseLabel->setText( tr( "Y Phase" ) );
    m_tab->changeTab( tab, tr( "Basic Movement" ) );
    m_runOrderGroup->setTitle( tr( "Run Order" ) );
    m_loopModeButton->setText( tr( "Loop" ) );
    QToolTip::add( m_loopModeButton, tr( "Loop continuously" ) );
    m_singleShotModeButton->setText( tr( "Single-Shot" ) );
    QToolTip::add( m_singleShotModeButton, tr( "Run thru only once and stop" ) );
    m_pingPongModeButton->setText( tr( "Ping-Pong" ) );
    QToolTip::add( m_pingPongModeButton, tr( "Reverse direction at both ends" ) );
    m_directionGroup->setTitle( tr( "Direction" ) );
    m_forwardsDirectionButton->setText( tr( "Forwards" ) );
    QToolTip::add( m_forwardsDirectionButton, tr( "Normal direction" ) );
    m_backwardsDirectionButton->setText( tr( "Backwards" ) );
    QToolTip::add( m_backwardsDirectionButton, tr( "Reversed direction" ) );
    m_blackoutFeatureGroup->setTitle( QString::null );
    m_startSceneCheckbox->setText( tr( "Initialise fixture with:" ) );
    QToolTip::add( m_startSceneCheckbox, tr( "Initialise the fixture with the selected scene values before the EFX starts" ) );
    m_startSceneList->header()->setLabel( 0, tr( "Scene" ) );
    m_blackoutFeatureGroup_2->setTitle( QString::null );
    m_stopSceneCheckbox->setText( tr( "De-initialise fixture with:" ) );
    QToolTip::add( m_stopSceneCheckbox, tr( "De-initialise the fixture with the selected scene values after the EFX stops" ) );
    m_stopSceneList->header()->setLabel( 0, tr( "Scene" ) );
    m_tab->changeTab( tab_2, tr( "Advanced Options" ) );
    m_modulationParametersGroup->setTitle( tr( "Modulation Parameters" ) );
    m_widthButton->setText( tr( "Width" ) );
    m_heightButton->setText( tr( "Height" ) );
    m_xOffsetButton->setText( tr( "X Offset" ) );
    m_yOffsetButton->setText( tr( "Y Offset" ) );
    m_xFrequencyButton->setText( tr( "X Frequency" ) );
    m_yFrequencyButton->setText( tr( "Y Frequency" ) );
    m_xPhaseButton->setText( tr( "X Phase" ) );
    m_yPhaseButton->setText( tr( "Y Phase" ) );
    m_modulationSpeedGroup->setTitle( tr( "Modulation Speed" ) );
    m_modulationSpeedLabel->setText( tr( "Speed Bus:" ) );
    QToolTip::add( m_modulationBusCombo, tr( "The bus that adjusts the parameter modulation speed" ) );
    m_tab->changeTab( TabPage, tr( "Modulation" ) );
    m_testRunButton->setText( tr( "Test Run" ) );
    QToolTip::add( m_testRunButton, tr( "Run the EFX" ) );
    QToolTip::add( m_testRunSpeedSlider, tr( "Test run speed setting" ) );
    m_ok->setText( tr( "OK" ) );
    QToolTip::add( m_ok, tr( "Accept changes and close" ) );
    m_cancel->setText( tr( "Cancel" ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close" ) );
}

void UI_EFXEditor::slotHeightSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotHeightSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotXOffsetSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotXOffsetSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotYOffsetSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotYOffsetSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotWidthSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotWidthSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotHorizontalChannelSelected(int)
{
    qWarning( "UI_EFXEditor::slotHorizontalChannelSelected(int): Not implemented yet" );
}

void UI_EFXEditor::slotVerticalChannelSelected(int)
{
    qWarning( "UI_EFXEditor::slotVerticalChannelSelected(int): Not implemented yet" );
}

void UI_EFXEditor::slotAlgorithmSelected(const QString&)
{
    qWarning( "UI_EFXEditor::slotAlgorithmSelected(const QString&): Not implemented yet" );
}

void UI_EFXEditor::slotNameChanged(const QString&)
{
    qWarning( "UI_EFXEditor::slotNameChanged(const QString&): Not implemented yet" );
}

void UI_EFXEditor::slotXFrequencySpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotXFrequencySpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotYFrequencySpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotYFrequencySpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotXPhaseSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotXPhaseSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotYPhaseSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotYPhaseSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotRotationSpinChanged(int)
{
    qWarning( "UI_EFXEditor::slotRotationSpinChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotTestRunToggled(bool)
{
    qWarning( "UI_EFXEditor::slotTestRunToggled(bool): Not implemented yet" );
}

void UI_EFXEditor::slotTestRunSpeedSliderValueChanged(int)
{
    qWarning( "UI_EFXEditor::slotTestRunSpeedSliderValueChanged(int): Not implemented yet" );
}

void UI_EFXEditor::slotStartSceneCheckboxToggled(bool)
{
    qWarning( "UI_EFXEditor::slotStartSceneCheckboxToggled(bool): Not implemented yet" );
}

void UI_EFXEditor::slotStopSceneCheckboxToggled(bool)
{
    qWarning( "UI_EFXEditor::slotStopSceneCheckboxToggled(bool): Not implemented yet" );
}

void UI_EFXEditor::slotStartSceneListSelectionChanged(QListViewItem*)
{
    qWarning( "UI_EFXEditor::slotStartSceneListSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_EFXEditor::slotStopSceneListSelectionChanged(QListViewItem*)
{
    qWarning( "UI_EFXEditor::slotStopSceneListSelectionChanged(QListViewItem*): Not implemented yet" );
}

void UI_EFXEditor::slotDirectionClicked(int)
{
    qWarning( "UI_EFXEditor::slotDirectionClicked(int): Not implemented yet" );
}

void UI_EFXEditor::slotRunOrderClicked(int)
{
    qWarning( "UI_EFXEditor::slotRunOrderClicked(int): Not implemented yet" );
}

