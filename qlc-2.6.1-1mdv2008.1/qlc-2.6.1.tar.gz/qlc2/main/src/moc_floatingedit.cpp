/****************************************************************************
** FloatingEdit meta object code from reading C++ file 'floatingedit.h'
**
** Created: Thu Nov 30 00:57:39 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "floatingedit.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *FloatingEdit::className() const
{
    return "FloatingEdit";
}

QMetaObject *FloatingEdit::metaObj = 0;
static QMetaObjectCleanUp cleanUp_FloatingEdit( "FloatingEdit", &FloatingEdit::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString FloatingEdit::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FloatingEdit", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString FloatingEdit::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "FloatingEdit", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* FloatingEdit::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QLineEdit::staticMetaObject();
    static const QUMethod signal_0 = {"cancelled", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "cancelled()", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"FloatingEdit", parentObject,
	0, 0,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_FloatingEdit.setMetaObject( metaObj );
    return metaObj;
}

void* FloatingEdit::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "FloatingEdit" ) )
	return this;
    return QLineEdit::qt_cast( clname );
}

// SIGNAL cancelled
void FloatingEdit::cancelled()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool FloatingEdit::qt_invoke( int _id, QUObject* _o )
{
    return QLineEdit::qt_invoke(_id,_o);
}

bool FloatingEdit::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: cancelled(); break;
    default:
	return QLineEdit::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool FloatingEdit::qt_property( int id, int f, QVariant* v)
{
    return QLineEdit::qt_property( id, f, v);
}

bool FloatingEdit::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
