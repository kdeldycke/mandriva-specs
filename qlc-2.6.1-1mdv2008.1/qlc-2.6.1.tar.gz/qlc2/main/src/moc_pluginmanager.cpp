/****************************************************************************
** PluginManager meta object code from reading C++ file 'pluginmanager.h'
**
** Created: Thu Nov 30 00:57:48 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "pluginmanager.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *PluginManager::className() const
{
    return "PluginManager";
}

QMetaObject *PluginManager::metaObj = 0;
static QMetaObjectCleanUp cleanUp_PluginManager( "PluginManager", &PluginManager::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString PluginManager::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PluginManager", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString PluginManager::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "PluginManager", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* PluginManager::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QWidget::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotDoubleClicked", 1, param_slot_0 };
    static const QUMethod slot_1 = {"slotConfigure", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotSelectionChanged", 1, param_slot_2 };
    static const QUParameter param_slot_3[] = {
	{ "plugin", &static_QUType_ptr, "Plugin", QUParameter::In }
    };
    static const QUMethod slot_3 = {"slotPluginActivated", 1, param_slot_3 };
    static const QUParameter param_slot_4[] = {
	{ "item", &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ "point", &static_QUType_varptr, "\x0e", QUParameter::In },
	{ "col", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotRightButtonClicked", 3, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ "e", &static_QUType_ptr, "QCloseEvent", QUParameter::In }
    };
    static const QUMethod slot_5 = {"closeEvent", 1, param_slot_5 };
    static const QMetaData slot_tbl[] = {
	{ "slotDoubleClicked(QListViewItem*)", &slot_0, QMetaData::Public },
	{ "slotConfigure()", &slot_1, QMetaData::Public },
	{ "slotSelectionChanged(QListViewItem*)", &slot_2, QMetaData::Public },
	{ "slotPluginActivated(Plugin*)", &slot_3, QMetaData::Public },
	{ "slotRightButtonClicked(QListViewItem*,const QPoint&,int)", &slot_4, QMetaData::Public },
	{ "closeEvent(QCloseEvent*)", &slot_5, QMetaData::Protected }
    };
    static const QUMethod signal_0 = {"closed", 0, 0 };
    static const QMetaData signal_tbl[] = {
	{ "closed()", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"PluginManager", parentObject,
	slot_tbl, 6,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_PluginManager.setMetaObject( metaObj );
    return metaObj;
}

void* PluginManager::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "PluginManager" ) )
	return this;
    return QWidget::qt_cast( clname );
}

// SIGNAL closed
void PluginManager::closed()
{
    activate_signal( staticMetaObject()->signalOffset() + 0 );
}

bool PluginManager::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 1: slotConfigure(); break;
    case 2: slotSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 3: slotPluginActivated((Plugin*)static_QUType_ptr.get(_o+1)); break;
    case 4: slotRightButtonClicked((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 5: closeEvent((QCloseEvent*)static_QUType_ptr.get(_o+1)); break;
    default:
	return QWidget::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool PluginManager::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: closed(); break;
    default:
	return QWidget::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool PluginManager::qt_property( int id, int f, QVariant* v)
{
    return QWidget::qt_property( id, f, v);
}

bool PluginManager::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
