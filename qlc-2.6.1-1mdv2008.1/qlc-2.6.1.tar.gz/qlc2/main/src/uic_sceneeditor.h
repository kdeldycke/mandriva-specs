/****************************************************************************
** Form interface generated from reading ui file 'src/sceneeditor.ui'
**
** Created: Thu Nov 30 00:55:01 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_SCENEEDITOR_H
#define UI_SCENEEDITOR_H

#include <qvariant.h>
#include <qwidget.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QToolButton;
class QListBox;
class QListBoxItem;
class QLabel;

class UI_SceneEditor : public QWidget
{
    Q_OBJECT

public:
    UI_SceneEditor( QWidget* parent = 0, const char* name = 0, WFlags fl = 0 );
    ~UI_SceneEditor();

    QToolButton* m_tools;
    QListBox* m_sceneList;
    QLabel* m_statusLabel;

public slots:
    virtual void slotActivate();
    virtual void slotSceneListContextMenu(QListBoxItem*, const QPoint&);

protected:
    QVBoxLayout* UI_SceneEditorLayout;

protected slots:
    virtual void languageChange();

};

#endif // UI_SCENEEDITOR_H
