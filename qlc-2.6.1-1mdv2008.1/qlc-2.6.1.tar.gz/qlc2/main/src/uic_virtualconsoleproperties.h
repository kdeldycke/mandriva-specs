/****************************************************************************
** Form interface generated from reading ui file 'src/virtualconsoleproperties.ui'
**
** Created: Thu Nov 30 00:55:16 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_VIRTUALCONSOLEPROPERTIES_H
#define UI_VIRTUALCONSOLEPROPERTIES_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QCheckBox;
class QLabel;
class QSpinBox;
class QPushButton;

class UI_VirtualConsoleProperties : public QDialog
{
    Q_OBJECT

public:
    UI_VirtualConsoleProperties( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_VirtualConsoleProperties();

    QGroupBox* m_keyboardGroup;
    QCheckBox* m_grabKeyboard;
    QCheckBox* m_keyRepeat;
    QGroupBox* m_gridBox;
    QCheckBox* m_snapToGrid;
    QLabel* textLabel1;
    QSpinBox* m_xSpin;
    QLabel* textLabel1_2;
    QSpinBox* m_ySpin;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotSnapToGridToggled(bool);
    virtual void slotOKClicked();
    virtual void slotCancelClicked();

protected:
    QVBoxLayout* UI_VirtualConsolePropertiesLayout;
    QHBoxLayout* layout4;
    QVBoxLayout* m_keyboardGroupLayout;
    QVBoxLayout* m_gridBoxLayout;
    QHBoxLayout* layout1;
    QHBoxLayout* layout2;
    QHBoxLayout* layout3;
    QSpacerItem* spacer1;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

};

#endif // UI_VIRTUALCONSOLEPROPERTIES_H
