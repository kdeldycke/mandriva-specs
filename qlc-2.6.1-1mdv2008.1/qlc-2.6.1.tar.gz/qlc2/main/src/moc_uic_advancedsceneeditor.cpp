/****************************************************************************
** UI_AdvancedSceneEditor meta object code from reading C++ file 'uic_advancedsceneeditor.h'
**
** Created: Thu Nov 30 00:55:18 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_advancedsceneeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_AdvancedSceneEditor::className() const
{
    return "UI_AdvancedSceneEditor";
}

QMetaObject *UI_AdvancedSceneEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_AdvancedSceneEditor( "UI_AdvancedSceneEditor", &UI_AdvancedSceneEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_AdvancedSceneEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_AdvancedSceneEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_AdvancedSceneEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_AdvancedSceneEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_AdvancedSceneEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ 0, &static_QUType_varptr, "\x0e", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotChannelsContextMenuRequested", 3, param_slot_0 };
    static const QUMethod slot_1 = {"slotAddSceneClicked", 0, 0 };
    static const QUMethod slot_2 = {"slotApplyClicked", 0, 0 };
    static const QUMethod slot_3 = {"slotCancelClicked", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotContentsClicked", 1, param_slot_4 };
    static const QUParameter param_slot_5[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_5 = {"slotContentsDoubleClicked", 1, param_slot_5 };
    static const QUMethod slot_6 = {"slotEditSceneNameClicked", 0, 0 };
    static const QUMethod slot_7 = {"slotEditValueClicked", 0, 0 };
    static const QUMethod slot_8 = {"slotOKClicked", 0, 0 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotOutputDeviceActivated", 1, param_slot_9 };
    static const QUMethod slot_10 = {"slotRemoveSceneClicked", 0, 0 };
    static const QUParameter param_slot_11[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_11 = {"slotSceneDoubleClicked", 1, param_slot_11 };
    static const QUParameter param_slot_12[] = {
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_12 = {"slotSceneNameTextChanged", 1, param_slot_12 };
    static const QUParameter param_slot_13[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_13 = {"slotSceneSelected", 1, param_slot_13 };
    static const QUMethod slot_14 = {"slotStoreButtonClicked", 0, 0 };
    static const QUParameter param_slot_15[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_15 = {"slotStoreSceneInGroupClicked", 1, param_slot_15 };
    static const QUParameter param_slot_16[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_16 = {"slotItemRenamed", 2, param_slot_16 };
    static const QUMethod slot_17 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotChannelsContextMenuRequested(QListViewItem*,const QPoint&,int)", &slot_0, QMetaData::Public },
	{ "slotAddSceneClicked()", &slot_1, QMetaData::Public },
	{ "slotApplyClicked()", &slot_2, QMetaData::Public },
	{ "slotCancelClicked()", &slot_3, QMetaData::Public },
	{ "slotContentsClicked(QListViewItem*)", &slot_4, QMetaData::Public },
	{ "slotContentsDoubleClicked(QListViewItem*)", &slot_5, QMetaData::Public },
	{ "slotEditSceneNameClicked()", &slot_6, QMetaData::Public },
	{ "slotEditValueClicked()", &slot_7, QMetaData::Public },
	{ "slotOKClicked()", &slot_8, QMetaData::Public },
	{ "slotOutputDeviceActivated(const QString&)", &slot_9, QMetaData::Public },
	{ "slotRemoveSceneClicked()", &slot_10, QMetaData::Public },
	{ "slotSceneDoubleClicked(QListViewItem*)", &slot_11, QMetaData::Public },
	{ "slotSceneNameTextChanged(const QString&)", &slot_12, QMetaData::Public },
	{ "slotSceneSelected(QListViewItem*)", &slot_13, QMetaData::Public },
	{ "slotStoreButtonClicked()", &slot_14, QMetaData::Public },
	{ "slotStoreSceneInGroupClicked(int)", &slot_15, QMetaData::Public },
	{ "slotItemRenamed(QListViewItem*,int)", &slot_16, QMetaData::Public },
	{ "languageChange()", &slot_17, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_AdvancedSceneEditor", parentObject,
	slot_tbl, 18,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_AdvancedSceneEditor.setMetaObject( metaObj );
    return metaObj;
}

void* UI_AdvancedSceneEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_AdvancedSceneEditor" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_AdvancedSceneEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotChannelsContextMenuRequested((QListViewItem*)static_QUType_ptr.get(_o+1),(const QPoint&)*((const QPoint*)static_QUType_ptr.get(_o+2)),(int)static_QUType_int.get(_o+3)); break;
    case 1: slotAddSceneClicked(); break;
    case 2: slotApplyClicked(); break;
    case 3: slotCancelClicked(); break;
    case 4: slotContentsClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 5: slotContentsDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 6: slotEditSceneNameClicked(); break;
    case 7: slotEditValueClicked(); break;
    case 8: slotOKClicked(); break;
    case 9: slotOutputDeviceActivated((const QString&)static_QUType_QString.get(_o+1)); break;
    case 10: slotRemoveSceneClicked(); break;
    case 11: slotSceneDoubleClicked((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 12: slotSceneNameTextChanged((const QString&)static_QUType_QString.get(_o+1)); break;
    case 13: slotSceneSelected((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 14: slotStoreButtonClicked(); break;
    case 15: slotStoreSceneInGroupClicked((int)static_QUType_int.get(_o+1)); break;
    case 16: slotItemRenamed((QListViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2)); break;
    case 17: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_AdvancedSceneEditor::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_AdvancedSceneEditor::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_AdvancedSceneEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
