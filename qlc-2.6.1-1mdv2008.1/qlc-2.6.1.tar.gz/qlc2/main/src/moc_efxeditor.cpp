/****************************************************************************
** EFXEditor meta object code from reading C++ file 'efxeditor.h'
**
** Created: Thu Nov 30 00:57:38 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "efxeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *EFXEditor::className() const
{
    return "EFXEditor";
}

QMetaObject *EFXEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_EFXEditor( "EFXEditor", &EFXEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString EFXEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "EFXEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString EFXEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "EFXEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* EFXEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_EFXEditor::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"EFXEditor", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_EFXEditor.setMetaObject( metaObj );
    return metaObj;
}

void* EFXEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "EFXEditor" ) )
	return this;
    return UI_EFXEditor::qt_cast( clname );
}

bool EFXEditor::qt_invoke( int _id, QUObject* _o )
{
    return UI_EFXEditor::qt_invoke(_id,_o);
}

bool EFXEditor::qt_emit( int _id, QUObject* _o )
{
    return UI_EFXEditor::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool EFXEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_EFXEditor::qt_property( id, f, v);
}

bool EFXEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES


const char *EFXPreviewArea::className() const
{
    return "EFXPreviewArea";
}

QMetaObject *EFXPreviewArea::metaObj = 0;
static QMetaObjectCleanUp cleanUp_EFXPreviewArea( "EFXPreviewArea", &EFXPreviewArea::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString EFXPreviewArea::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "EFXPreviewArea", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString EFXPreviewArea::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "EFXPreviewArea", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* EFXPreviewArea::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    metaObj = QMetaObject::new_metaobject(
	"EFXPreviewArea", parentObject,
	0, 0,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_EFXPreviewArea.setMetaObject( metaObj );
    return metaObj;
}

void* EFXPreviewArea::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "EFXPreviewArea" ) )
	return this;
    return QFrame::qt_cast( clname );
}

bool EFXPreviewArea::qt_invoke( int _id, QUObject* _o )
{
    return QFrame::qt_invoke(_id,_o);
}

bool EFXPreviewArea::qt_emit( int _id, QUObject* _o )
{
    return QFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool EFXPreviewArea::qt_property( int id, int f, QVariant* v)
{
    return QFrame::qt_property( id, f, v);
}

bool EFXPreviewArea::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
