/****************************************************************************
** UI_VCDockSliderProperties meta object code from reading C++ file 'uic_vcdocksliderproperties.h'
**
** Created: Thu Nov 30 00:55:35 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "uic_vcdocksliderproperties.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *UI_VCDockSliderProperties::className() const
{
    return "UI_VCDockSliderProperties";
}

QMetaObject *UI_VCDockSliderProperties::metaObj = 0;
static QMetaObjectCleanUp cleanUp_UI_VCDockSliderProperties( "UI_VCDockSliderProperties", &UI_VCDockSliderProperties::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString UI_VCDockSliderProperties::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_VCDockSliderProperties", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString UI_VCDockSliderProperties::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "UI_VCDockSliderProperties", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* UI_VCDockSliderProperties::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QDialog::staticMetaObject();
    static const QUMethod slot_0 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_1 = {"slotCancelClicked", 0, 0 };
    static const QUParameter param_slot_2[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_2 = {"slotBehaviourSelected", 1, param_slot_2 };
    static const QUMethod slot_3 = {"slotAllChannelsClicked", 0, 0 };
    static const QUMethod slot_4 = {"slotClearChannelsClicked", 0, 0 };
    static const QUMethod slot_5 = {"slotInvertChannelsClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotDeviceChannelsClicked", 0, 0 };
    static const QUMethod slot_7 = {"slotRoleChannelsClicked", 0, 0 };
    static const QUMethod slot_8 = {"slotAttachKeyClicked", 0, 0 };
    static const QUMethod slot_9 = {"slotDetachKeyClicked", 0, 0 };
    static const QUMethod slot_10 = {"languageChange", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotOKClicked()", &slot_0, QMetaData::Public },
	{ "slotCancelClicked()", &slot_1, QMetaData::Public },
	{ "slotBehaviourSelected(int)", &slot_2, QMetaData::Public },
	{ "slotAllChannelsClicked()", &slot_3, QMetaData::Public },
	{ "slotClearChannelsClicked()", &slot_4, QMetaData::Public },
	{ "slotInvertChannelsClicked()", &slot_5, QMetaData::Public },
	{ "slotDeviceChannelsClicked()", &slot_6, QMetaData::Public },
	{ "slotRoleChannelsClicked()", &slot_7, QMetaData::Public },
	{ "slotAttachKeyClicked()", &slot_8, QMetaData::Public },
	{ "slotDetachKeyClicked()", &slot_9, QMetaData::Public },
	{ "languageChange()", &slot_10, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"UI_VCDockSliderProperties", parentObject,
	slot_tbl, 11,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_UI_VCDockSliderProperties.setMetaObject( metaObj );
    return metaObj;
}

void* UI_VCDockSliderProperties::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "UI_VCDockSliderProperties" ) )
	return this;
    return QDialog::qt_cast( clname );
}

bool UI_VCDockSliderProperties::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotOKClicked(); break;
    case 1: slotCancelClicked(); break;
    case 2: slotBehaviourSelected((int)static_QUType_int.get(_o+1)); break;
    case 3: slotAllChannelsClicked(); break;
    case 4: slotClearChannelsClicked(); break;
    case 5: slotInvertChannelsClicked(); break;
    case 6: slotDeviceChannelsClicked(); break;
    case 7: slotRoleChannelsClicked(); break;
    case 8: slotAttachKeyClicked(); break;
    case 9: slotDetachKeyClicked(); break;
    case 10: languageChange(); break;
    default:
	return QDialog::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool UI_VCDockSliderProperties::qt_emit( int _id, QUObject* _o )
{
    return QDialog::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool UI_VCDockSliderProperties::qt_property( int id, int f, QVariant* v)
{
    return QDialog::qt_property( id, f, v);
}

bool UI_VCDockSliderProperties::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
