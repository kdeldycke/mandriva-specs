/****************************************************************************
** SequenceEditor meta object code from reading C++ file 'sequenceeditor.h'
**
** Created: Thu Nov 30 00:57:51 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "sequenceeditor.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *SequenceEditor::className() const
{
    return "SequenceEditor";
}

QMetaObject *SequenceEditor::metaObj = 0;
static QMetaObjectCleanUp cleanUp_SequenceEditor( "SequenceEditor", &SequenceEditor::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString SequenceEditor::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SequenceEditor", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString SequenceEditor::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SequenceEditor", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* SequenceEditor::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_SequenceEditor::staticMetaObject();
    static const QUMethod slot_0 = {"slotInsert", 0, 0 };
    static const QUMethod slot_1 = {"slotRemove", 0, 0 };
    static const QUMethod slot_2 = {"slotRaise", 0, 0 };
    static const QUMethod slot_3 = {"slotLower", 0, 0 };
    static const QUParameter param_slot_4[] = {
	{ 0, &static_QUType_bool, 0, QUParameter::In }
    };
    static const QUMethod slot_4 = {"slotSlidersToggled", 1, param_slot_4 };
    static const QUMethod slot_5 = {"slotOKClicked", 0, 0 };
    static const QUMethod slot_6 = {"slotCancelClicked", 0, 0 };
    static const QUParameter param_slot_7[] = {
	{ 0, &static_QUType_ptr, "t_channel", QUParameter::In },
	{ 0, &static_QUType_ptr, "t_value", QUParameter::In },
	{ 0, &static_QUType_ptr, "Scene::ValueType", QUParameter::In }
    };
    static const QUMethod slot_7 = {"slotChannelChanged", 3, param_slot_7 };
    static const QUParameter param_slot_8[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In }
    };
    static const QUMethod slot_8 = {"slotSelectionChanged", 1, param_slot_8 };
    static const QUParameter param_slot_9[] = {
	{ 0, &static_QUType_ptr, "QListViewItem", QUParameter::In },
	{ 0, &static_QUType_int, 0, QUParameter::In },
	{ 0, &static_QUType_QString, 0, QUParameter::In }
    };
    static const QUMethod slot_9 = {"slotItemRenamed", 3, param_slot_9 };
    static const QUMethod slot_10 = {"slotGeneratorButtonClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotInsert()", &slot_0, QMetaData::Public },
	{ "slotRemove()", &slot_1, QMetaData::Public },
	{ "slotRaise()", &slot_2, QMetaData::Public },
	{ "slotLower()", &slot_3, QMetaData::Public },
	{ "slotSlidersToggled(bool)", &slot_4, QMetaData::Public },
	{ "slotOKClicked()", &slot_5, QMetaData::Public },
	{ "slotCancelClicked()", &slot_6, QMetaData::Public },
	{ "slotChannelChanged(t_channel,t_value,Scene::ValueType)", &slot_7, QMetaData::Public },
	{ "slotSelectionChanged(QListViewItem*)", &slot_8, QMetaData::Public },
	{ "slotItemRenamed(QListViewItem*,int,const QString&)", &slot_9, QMetaData::Public },
	{ "slotGeneratorButtonClicked()", &slot_10, QMetaData::Public }
    };
    static const QUParameter param_signal_0[] = {
	{ "values", &static_QUType_ptr, "SceneValue", QUParameter::In },
	{ "channels", &static_QUType_ptr, "t_channel", QUParameter::In }
    };
    static const QUMethod signal_0 = {"sceneActivated", 2, param_signal_0 };
    static const QMetaData signal_tbl[] = {
	{ "sceneActivated(SceneValue*,t_channel)", &signal_0, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"SequenceEditor", parentObject,
	slot_tbl, 11,
	signal_tbl, 1,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_SequenceEditor.setMetaObject( metaObj );
    return metaObj;
}

void* SequenceEditor::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "SequenceEditor" ) )
	return this;
    return UI_SequenceEditor::qt_cast( clname );
}

#include <qobjectdefs.h>
#include <qsignalslotimp.h>

// SIGNAL sceneActivated
void SequenceEditor::sceneActivated( SceneValue* t0, t_channel t1 )
{
    if ( signalsBlocked() )
	return;
    QConnectionList *clist = receivers( staticMetaObject()->signalOffset() + 0 );
    if ( !clist )
	return;
    QUObject o[3];
    static_QUType_ptr.set(o+1,t0);
    static_QUType_ptr.set(o+2,&t1);
    activate_signal( clist, o );
}

bool SequenceEditor::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotInsert(); break;
    case 1: slotRemove(); break;
    case 2: slotRaise(); break;
    case 3: slotLower(); break;
    case 4: slotSlidersToggled((bool)static_QUType_bool.get(_o+1)); break;
    case 5: slotOKClicked(); break;
    case 6: slotCancelClicked(); break;
    case 7: slotChannelChanged((t_channel)(*((t_channel*)static_QUType_ptr.get(_o+1))),(t_value)(*((t_value*)static_QUType_ptr.get(_o+2))),(Scene::ValueType)(*((Scene::ValueType*)static_QUType_ptr.get(_o+3)))); break;
    case 8: slotSelectionChanged((QListViewItem*)static_QUType_ptr.get(_o+1)); break;
    case 9: slotItemRenamed((QListViewItem*)static_QUType_ptr.get(_o+1),(int)static_QUType_int.get(_o+2),(const QString&)static_QUType_QString.get(_o+3)); break;
    case 10: slotGeneratorButtonClicked(); break;
    default:
	return UI_SequenceEditor::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool SequenceEditor::qt_emit( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->signalOffset() ) {
    case 0: sceneActivated((SceneValue*)static_QUType_ptr.get(_o+1),(t_channel)(*((t_channel*)static_QUType_ptr.get(_o+2)))); break;
    default:
	return UI_SequenceEditor::qt_emit(_id,_o);
    }
    return TRUE;
}
#ifndef QT_NO_PROPERTIES

bool SequenceEditor::qt_property( int id, int f, QVariant* v)
{
    return UI_SequenceEditor::qt_property( id, f, v);
}

bool SequenceEditor::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
