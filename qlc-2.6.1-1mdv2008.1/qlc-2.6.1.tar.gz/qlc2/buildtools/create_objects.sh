#!/bin/sh
#
# Q Light Controller
# create_objects.sh
#
# Copyright (c) Heikki Junnila
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# Version 2 as published by the Free Software Foundation.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details. The license is
# in the file "COPYING".
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

############################
#         UI FILES         #
############################

rm -f uifiles

for f in `ls -1 *.ui`;
  do
  if [ -f $f ];
      then
      echo -n " " >> uifiles
      echo -n $f >> uifiles
  fi
done

rm -f uicofiles
rm -f uichfiles
rm -f mocuicofiles

if [ -f "uifiles" ]; then

    echo "Create moc_, uic_, .cpp and .h files from ui definitions"

    # Change .ui suffix to .h and add prefix uic_
    sed 's/\.ui/\.h/g;s/ / uic_/g;s/^/UICH =/g' uifiles > uichfiles
    
    # Change .h to .o
    sed 's/\.h/\.o/g;s/UICH/UICO/g' uichfiles > uicofiles
    
    # Prefix moc_ to uic_
    sed 's/uic_/moc_uic_/g;s/UICO/MOCUICO/g' uicofiles > mocuicofiles
    
    # Put a carriage return to each file
    echo >> uicofiles
    echo >> uichfiles
    echo >> mocuicofiles
else
    echo "No UI definitions found. Creating dummy files to satisfy make."
    
    echo "UICO =" > uicofiles
    echo "UICH =" > uichfiles
    echo "MOCUICO =" > mocuicofiles
fi

############################
#     NORMAL CPP FILES     #
############################

rm -f cppfiles

for f in "*.cpp";
do
	echo -n " " >> cppfiles
	echo -n $f >> cppfiles
done

rm -f objfiles

if [ -f "cppfiles" ];
then
	echo "Create a list of regular object files from .cpp files"

	# Prepend with "OBJS =" and change .cpp to .o
	sed 's/^/OBJS =/g;s/\.cpp/\.o/g' cppfiles > objfiles

	# Put a carriage return to the file
	echo >> objfiles
else
	echo "No CPP files found. Creating dummy files to satisfy make."

	echo "OBJS =" > objfiles
fi


############################
#   NORMAL HEADER FILES    #
############################

rm -f hfiles

for f in "*.h";
do
	echo -n " " >> hfiles
	echo -n $f >> hfiles
done

rm -f mocfiles
rm -f mocofiles

if [ -f "hfiles" ];
then
	echo "Create a list of moc_ files from .h files"

	# Prepend with moc_ and change .h to .o
	sed 's/ / moc_/g;s/\.h/\.o/g;s/^/MOCO =/g' hfiles > mocofiles

	# Prepend with "MOCO ="
	# sed 's/^/MOCO =/g' mocfiles > mocofiles

	# Put a carriage return to each file
	echo >> mocfiles
	echo >> mocofiles
else
	echo "No header files found. Creating dummy files to satisfy make."

	echo "MOCO =" > mocofiles
fi
