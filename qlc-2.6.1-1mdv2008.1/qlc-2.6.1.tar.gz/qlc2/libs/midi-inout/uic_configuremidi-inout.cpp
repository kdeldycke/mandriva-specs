/****************************************************************************
** Form implementation generated from reading ui file 'configuremidi-inout.ui'
**
** Created: Thu Nov 30 00:54:00 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "uic_configuremidi-inout.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlabel.h>
#include <qlineedit.h>
#include <qspinbox.h>
#include <qcombobox.h>
#include <qcheckbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_ConfigureMidiInOut as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_ConfigureMidiInOut::UI_ConfigureMidiInOut( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_ConfigureMidiInOut" );
    UI_ConfigureMidiInOutLayout = new QVBoxLayout( this, 11, 6, "UI_ConfigureMidiInOutLayout"); 

    m_deviceGroup = new QGroupBox( this, "m_deviceGroup" );
    m_deviceGroup->setFrameShape( QGroupBox::Box );
    m_deviceGroup->setFrameShadow( QGroupBox::Sunken );
    m_deviceGroup->setColumnLayout(0, Qt::Vertical );
    m_deviceGroup->layout()->setSpacing( 6 );
    m_deviceGroup->layout()->setMargin( 11 );
    m_deviceGroupLayout = new QGridLayout( m_deviceGroup->layout() );
    m_deviceGroupLayout->setAlignment( Qt::AlignTop );

    textLabel1 = new QLabel( m_deviceGroup, "textLabel1" );

    m_deviceGroupLayout->addWidget( textLabel1, 0, 0 );

    m_deviceEdit = new QLineEdit( m_deviceGroup, "m_deviceEdit" );

    m_deviceGroupLayout->addWidget( m_deviceEdit, 0, 1 );

    m_channelSpinBox = new QSpinBox( m_deviceGroup, "m_channelSpinBox" );

    m_deviceGroupLayout->addWidget( m_channelSpinBox, 1, 1 );

    textLabel1_2 = new QLabel( m_deviceGroup, "textLabel1_2" );

    m_deviceGroupLayout->addWidget( textLabel1_2, 1, 0 );

    m_controlCombo = new QComboBox( FALSE, m_deviceGroup, "m_controlCombo" );

    m_deviceGroupLayout->addWidget( m_controlCombo, 2, 1 );

    textLabel1_2_2 = new QLabel( m_deviceGroup, "textLabel1_2_2" );

    m_deviceGroupLayout->addWidget( textLabel1_2_2, 2, 0 );

    m_feedbackCheckBox = new QCheckBox( m_deviceGroup, "m_feedbackCheckBox" );

    m_deviceGroupLayout->addMultiCellWidget( m_feedbackCheckBox, 3, 3, 0, 1 );

    textLabel1_2_2_2 = new QLabel( m_deviceGroup, "textLabel1_2_2_2" );

    m_deviceGroupLayout->addWidget( textLabel1_2_2_2, 4, 0 );

    m_debugLevelCombo = new QComboBox( FALSE, m_deviceGroup, "m_debugLevelCombo" );

    m_deviceGroupLayout->addWidget( m_debugLevelCombo, 4, 1 );
    UI_ConfigureMidiInOutLayout->addWidget( m_deviceGroup );

    m_statusGroup = new QGroupBox( this, "m_statusGroup" );
    m_statusGroup->setColumnLayout(0, Qt::Vertical );
    m_statusGroup->layout()->setSpacing( 6 );
    m_statusGroup->layout()->setMargin( 11 );
    m_statusGroupLayout = new QHBoxLayout( m_statusGroup->layout() );
    m_statusGroupLayout->setAlignment( Qt::AlignTop );

    m_statusLabel = new QLabel( m_statusGroup, "m_statusLabel" );
    QFont m_statusLabel_font(  m_statusLabel->font() );
    m_statusLabel_font.setBold( TRUE );
    m_statusLabel->setFont( m_statusLabel_font ); 
    m_statusLabel->setFrameShape( QLabel::StyledPanel );
    m_statusLabel->setFrameShadow( QLabel::Sunken );
    m_statusLabel->setAlignment( int( QLabel::AlignCenter ) );
    m_statusGroupLayout->addWidget( m_statusLabel );

    m_activate = new QPushButton( m_statusGroup, "m_activate" );
    m_statusGroupLayout->addWidget( m_activate );

    m_deactivate = new QPushButton( m_statusGroup, "m_deactivate" );
    m_statusGroupLayout->addWidget( m_deactivate );
    UI_ConfigureMidiInOutLayout->addWidget( m_statusGroup );

    layout6 = new QHBoxLayout( 0, 0, 6, "layout6"); 
    spacer2 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout6->addItem( spacer2 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout6->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout6->addWidget( m_cancel );
    UI_ConfigureMidiInOutLayout->addLayout( layout6 );
    languageChange();
    resize( QSize(332, 283).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_activate, SIGNAL( clicked() ), this, SLOT( slotActivateClicked() ) );
    connect( m_deactivate, SIGNAL( clicked() ), this, SLOT( slotDeactivateClicked() ) );

    // tab order
    setTabOrder( m_cancel, m_deviceEdit );
    setTabOrder( m_deviceEdit, m_activate );
    setTabOrder( m_activate, m_ok );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_ConfigureMidiInOut::~UI_ConfigureMidiInOut()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_ConfigureMidiInOut::languageChange()
{
    setCaption( tr( "Configure Midi Input/Output Plugin" ) );
    m_deviceGroup->setTitle( tr( "Settings" ) );
    textLabel1->setText( tr( "Device" ) );
    QToolTip::add( m_deviceEdit, tr( "The device file that is the interface for MIDI. Usually /dev/midi00." ) );
    QToolTip::add( m_channelSpinBox, tr( "The MIDI channel to listen to. \"0\" will listen to all channels." ) );
    textLabel1_2->setText( tr( "Channel" ) );
    m_controlCombo->clear();
    m_controlCombo->insertItem( tr( "Control Change" ) );
    m_controlCombo->insertItem( tr( "Program Change" ) );
    m_controlCombo->insertItem( tr( "Note on" ) );
    m_controlCombo->insertItem( tr( "Any" ) );
    QToolTip::add( m_controlCombo, tr( "The MIDI control type to use for communication." ) );
    textLabel1_2_2->setText( tr( "Control" ) );
    m_feedbackCheckBox->setText( tr( "Activate Parameter Feedback To Control Unit" ) );
    QToolTip::add( m_feedbackCheckBox, tr( "Move motorized faders when a slider is dragged in Virtual Console." ) );
    textLabel1_2_2_2->setText( tr( "Debug" ) );
    m_debugLevelCombo->clear();
    m_debugLevelCombo->insertItem( tr( "Off" ) );
    m_debugLevelCombo->insertItem( tr( "Midi Messages" ) );
    m_debugLevelCombo->insertItem( tr( "Full Midi Input" ) );
    QToolTip::add( m_debugLevelCombo, tr( "Use only if something is wrong." ) );
    m_statusGroup->setTitle( tr( "Status" ) );
    m_statusLabel->setText( tr( "Not Active" ) );
    QToolTip::add( m_statusLabel, tr( "Current interface status." ) );
    m_activate->setText( tr( "&Activate" ) );
    m_activate->setAccel( QKeySequence( tr( "Alt+A" ) ) );
    QToolTip::add( m_activate, tr( "Activate the interface. Pressing this button also saves settings." ) );
    m_deactivate->setText( tr( "&Deactivate" ) );
    m_deactivate->setAccel( QKeySequence( tr( "Alt+D" ) ) );
    QToolTip::add( m_deactivate, tr( "Deactivate the interface." ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
}

void UI_ConfigureMidiInOut::slotActivateClicked()
{
    qWarning( "UI_ConfigureMidiInOut::slotActivateClicked(): Not implemented yet" );
}

void UI_ConfigureMidiInOut::slotDeactivateClicked()
{
    qWarning( "UI_ConfigureMidiInOut::slotDeactivateClicked(): Not implemented yet" );
}

