/****************************************************************************
** Form interface generated from reading ui file 'configuredmx4linuxout.ui'
**
** Created: Thu Nov 30 00:53:01 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_CONFIGUREDMX4LINUXOUT_H
#define UI_CONFIGUREDMX4LINUXOUT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLineEdit;
class QLabel;
class QPushButton;

class UI_ConfigureDMX4LinuxOut : public QDialog
{
    Q_OBJECT

public:
    UI_ConfigureDMX4LinuxOut( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_ConfigureDMX4LinuxOut();

    QGroupBox* m_deviceGroup;
    QLineEdit* m_deviceEdit;
    QGroupBox* m_statusGroup;
    QLabel* m_statusLabel;
    QPushButton* m_activate;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotActivateClicked();

protected:
    QVBoxLayout* UI_ConfigureDMX4LinuxOutLayout;
    QVBoxLayout* m_deviceGroupLayout;
    QHBoxLayout* m_statusGroupLayout;
    QHBoxLayout* layout6;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

};

#endif // UI_CONFIGUREDMX4LINUXOUT_H
