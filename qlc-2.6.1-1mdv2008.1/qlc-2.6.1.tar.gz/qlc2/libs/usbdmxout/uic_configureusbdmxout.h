/****************************************************************************
** Form interface generated from reading ui file 'configureusbdmxout.ui'
**
** Created: Thu Nov 30 00:53:45 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_CONFIGUREUSBDMXOUT_H
#define UI_CONFIGUREUSBDMXOUT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLineEdit;
class QLabel;
class QSpinBox;
class QPushButton;

class UI_ConfigureUsbDmxOut : public QDialog
{
    Q_OBJECT

public:
    UI_ConfigureUsbDmxOut( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_ConfigureUsbDmxOut();

    QGroupBox* m_deviceGroup;
    QLineEdit* m_deviceEdit;
    QLabel* textLabel1;
    QSpinBox* m_firstNumberSpinBox;
    QLabel* textLabel1_2;
    QGroupBox* m_statusGroup;
    QLabel* m_statusLabel;
    QPushButton* m_activate;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotActivateClicked();

protected:
    QVBoxLayout* UI_ConfigureUsbDmxOutLayout;
    QGridLayout* m_deviceGroupLayout;
    QHBoxLayout* m_statusGroupLayout;
    QHBoxLayout* layout6;
    QSpacerItem* spacer2;

protected slots:
    virtual void languageChange();

};

#endif // UI_CONFIGUREUSBDMXOUT_H
