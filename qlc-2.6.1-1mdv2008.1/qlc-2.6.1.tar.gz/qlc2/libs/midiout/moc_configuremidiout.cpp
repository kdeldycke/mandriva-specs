/****************************************************************************
** ConfigureMidiOut meta object code from reading C++ file 'configuremidiout.h'
**
** Created: Thu Nov 30 00:53:28 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "configuremidiout.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *ConfigureMidiOut::className() const
{
    return "ConfigureMidiOut";
}

QMetaObject *ConfigureMidiOut::metaObj = 0;
static QMetaObjectCleanUp cleanUp_ConfigureMidiOut( "ConfigureMidiOut", &ConfigureMidiOut::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString ConfigureMidiOut::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ConfigureMidiOut", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString ConfigureMidiOut::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "ConfigureMidiOut", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* ConfigureMidiOut::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = UI_ConfigureMidiOut::staticMetaObject();
    static const QUMethod slot_0 = {"slotActivateClicked", 0, 0 };
    static const QMetaData slot_tbl[] = {
	{ "slotActivateClicked()", &slot_0, QMetaData::Private }
    };
    metaObj = QMetaObject::new_metaobject(
	"ConfigureMidiOut", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_ConfigureMidiOut.setMetaObject( metaObj );
    return metaObj;
}

void* ConfigureMidiOut::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "ConfigureMidiOut" ) )
	return this;
    return UI_ConfigureMidiOut::qt_cast( clname );
}

bool ConfigureMidiOut::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotActivateClicked(); break;
    default:
	return UI_ConfigureMidiOut::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool ConfigureMidiOut::qt_emit( int _id, QUObject* _o )
{
    return UI_ConfigureMidiOut::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool ConfigureMidiOut::qt_property( int id, int f, QVariant* v)
{
    return UI_ConfigureMidiOut::qt_property( id, f, v);
}

bool ConfigureMidiOut::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
