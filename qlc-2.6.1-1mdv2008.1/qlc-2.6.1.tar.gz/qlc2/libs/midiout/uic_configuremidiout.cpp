/****************************************************************************
** Form implementation generated from reading ui file 'configuremidiout.ui'
**
** Created: Thu Nov 30 00:53:16 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#include "uic_configuremidiout.h"

#include <qvariant.h>
#include <qpushbutton.h>
#include <qgroupbox.h>
#include <qlineedit.h>
#include <qlabel.h>
#include <qspinbox.h>
#include <qlayout.h>
#include <qtooltip.h>
#include <qwhatsthis.h>

/*
 *  Constructs a UI_ConfigureMidiOut as a child of 'parent', with the
 *  name 'name' and widget flags set to 'f'.
 *
 *  The dialog will by default be modeless, unless you set 'modal' to
 *  TRUE to construct a modal dialog.
 */
UI_ConfigureMidiOut::UI_ConfigureMidiOut( QWidget* parent, const char* name, bool modal, WFlags fl )
    : QDialog( parent, name, modal, fl )
{
    if ( !name )
	setName( "UI_ConfigureMidiOut" );
    UI_ConfigureMidiOutLayout = new QVBoxLayout( this, 11, 6, "UI_ConfigureMidiOutLayout"); 

    m_deviceGroup = new QGroupBox( this, "m_deviceGroup" );
    m_deviceGroup->setFrameShape( QGroupBox::Box );
    m_deviceGroup->setFrameShadow( QGroupBox::Sunken );
    m_deviceGroup->setColumnLayout(0, Qt::Vertical );
    m_deviceGroup->layout()->setSpacing( 6 );
    m_deviceGroup->layout()->setMargin( 11 );
    m_deviceGroupLayout = new QVBoxLayout( m_deviceGroup->layout() );
    m_deviceGroupLayout->setAlignment( Qt::AlignTop );

    m_deviceEdit = new QLineEdit( m_deviceGroup, "m_deviceEdit" );
    m_deviceGroupLayout->addWidget( m_deviceEdit );
    UI_ConfigureMidiOutLayout->addWidget( m_deviceGroup );

    m_statusGroup = new QGroupBox( this, "m_statusGroup" );
    m_statusGroup->setColumnLayout(0, Qt::Vertical );
    m_statusGroup->layout()->setSpacing( 6 );
    m_statusGroup->layout()->setMargin( 11 );
    m_statusGroupLayout = new QHBoxLayout( m_statusGroup->layout() );
    m_statusGroupLayout->setAlignment( Qt::AlignTop );

    m_statusLabel = new QLabel( m_statusGroup, "m_statusLabel" );
    QFont m_statusLabel_font(  m_statusLabel->font() );
    m_statusLabel_font.setBold( TRUE );
    m_statusLabel->setFont( m_statusLabel_font ); 
    m_statusLabel->setFrameShape( QLabel::StyledPanel );
    m_statusLabel->setFrameShadow( QLabel::Sunken );
    m_statusLabel->setAlignment( int( QLabel::AlignCenter ) );
    m_statusGroupLayout->addWidget( m_statusLabel );

    m_activate = new QPushButton( m_statusGroup, "m_activate" );
    m_statusGroupLayout->addWidget( m_activate );
    UI_ConfigureMidiOutLayout->addWidget( m_statusGroup );

    GroupBox5 = new QGroupBox( this, "GroupBox5" );
    GroupBox5->setColumnLayout(0, Qt::Vertical );
    GroupBox5->layout()->setSpacing( 6 );
    GroupBox5->layout()->setMargin( 11 );
    GroupBox5Layout = new QVBoxLayout( GroupBox5->layout() );
    GroupBox5Layout->setAlignment( Qt::AlignTop );

    layout9 = new QHBoxLayout( 0, 0, 6, "layout9"); 

    m_midiOutputLabel = new QLabel( GroupBox5, "m_midiOutputLabel" );
    layout9->addWidget( m_midiOutputLabel );

    m_midiChannelSpin = new QSpinBox( GroupBox5, "m_midiChannelSpin" );
    m_midiChannelSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_midiChannelSpin->sizePolicy().hasHeightForWidth() ) );
    m_midiChannelSpin->setMaxValue( 16 );
    m_midiChannelSpin->setMinValue( 1 );
    layout9->addWidget( m_midiChannelSpin );
    GroupBox5Layout->addLayout( layout9 );

    layout10 = new QHBoxLayout( 0, 0, 6, "layout10"); 

    m_firstNoteNumber = new QLabel( GroupBox5, "m_firstNoteNumber" );
    layout10->addWidget( m_firstNoteNumber );

    m_firstNoteSpin = new QSpinBox( GroupBox5, "m_firstNoteSpin" );
    m_firstNoteSpin->setSizePolicy( QSizePolicy( (QSizePolicy::SizeType)0, (QSizePolicy::SizeType)0, 0, 0, m_firstNoteSpin->sizePolicy().hasHeightForWidth() ) );
    m_firstNoteSpin->setMaxValue( 127 );
    layout10->addWidget( m_firstNoteSpin );
    GroupBox5Layout->addLayout( layout10 );
    UI_ConfigureMidiOutLayout->addWidget( GroupBox5 );

    layout11 = new QHBoxLayout( 0, 0, 6, "layout11"); 
    spacer4 = new QSpacerItem( 40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum );
    layout11->addItem( spacer4 );

    m_ok = new QPushButton( this, "m_ok" );
    m_ok->setDefault( TRUE );
    layout11->addWidget( m_ok );

    m_cancel = new QPushButton( this, "m_cancel" );
    layout11->addWidget( m_cancel );
    UI_ConfigureMidiOutLayout->addLayout( layout11 );
    languageChange();
    resize( QSize(263, 282).expandedTo(minimumSizeHint()) );
    clearWState( WState_Polished );

    // signals and slots connections
    connect( m_activate, SIGNAL( clicked() ), this, SLOT( slotActivateClicked() ) );
    connect( m_ok, SIGNAL( clicked() ), this, SLOT( accept() ) );
    connect( m_cancel, SIGNAL( clicked() ), this, SLOT( reject() ) );

    // tab order
    setTabOrder( m_deviceEdit, m_activate );
    setTabOrder( m_activate, m_midiChannelSpin );
    setTabOrder( m_midiChannelSpin, m_firstNoteSpin );
    setTabOrder( m_firstNoteSpin, m_ok );
    setTabOrder( m_ok, m_cancel );
}

/*
 *  Destroys the object and frees any allocated resources
 */
UI_ConfigureMidiOut::~UI_ConfigureMidiOut()
{
    // no need to delete child widgets, Qt does it all for us
}

/*
 *  Sets the strings of the subwidgets using the current
 *  language.
 */
void UI_ConfigureMidiOut::languageChange()
{
    setCaption( tr( "Configure Midi Output Plugin" ) );
    m_deviceGroup->setTitle( tr( "Device" ) );
    QToolTip::add( m_deviceEdit, tr( "The device file that is the interface for DMX-MIDI. Usually /dev/midi00." ) );
    m_statusGroup->setTitle( tr( "Status" ) );
    m_statusLabel->setText( tr( "Not Active" ) );
    QToolTip::add( m_statusLabel, tr( "Current interface status" ) );
    m_activate->setText( tr( "&Activate" ) );
    m_activate->setAccel( QKeySequence( tr( "Alt+A" ) ) );
    QToolTip::add( m_activate, tr( "Activate the interface. Pressing this button also saves settings." ) );
    GroupBox5->setTitle( tr( "Midi Settings" ) );
    m_midiOutputLabel->setText( tr( "Midi Output Channel" ) );
    QToolTip::add( m_midiChannelSpin, tr( "The MIDI channel that receives DMX commands from QLC." ) );
    m_firstNoteNumber->setText( tr( "First Note Number" ) );
    QToolTip::add( m_firstNoteSpin, tr( "Each MIDI note represents a DMX channel" ) );
    m_ok->setText( tr( "&OK" ) );
    m_ok->setAccel( QKeySequence( tr( "Alt+O" ) ) );
    QToolTip::add( m_ok, tr( "Accept changes and close the dialog" ) );
    m_cancel->setText( tr( "&Cancel" ) );
    m_cancel->setAccel( QKeySequence( tr( "Alt+C" ) ) );
    QToolTip::add( m_cancel, tr( "Reject changes and close the dialog" ) );
}

void UI_ConfigureMidiOut::slotActivateClicked()
{
    qWarning( "UI_ConfigureMidiOut::slotActivateClicked(): Not implemented yet" );
}

