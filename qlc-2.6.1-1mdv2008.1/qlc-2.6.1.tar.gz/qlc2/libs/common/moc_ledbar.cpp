/****************************************************************************
** LedBar meta object code from reading C++ file 'ledbar.h'
**
** Created: Thu Nov 30 00:52:52 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "ledbar.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *LedBar::className() const
{
    return "LedBar";
}

QMetaObject *LedBar::metaObj = 0;
static QMetaObjectCleanUp cleanUp_LedBar( "LedBar", &LedBar::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString LedBar::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "LedBar", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString LedBar::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "LedBar", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* LedBar::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = QFrame::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ "value", &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotSetValue", 1, param_slot_0 };
    static const QUParameter param_slot_1[] = {
	{ "value", &static_QUType_ptr, "unsigned char", QUParameter::In }
    };
    static const QUMethod slot_1 = {"slotSetValue", 1, param_slot_1 };
    static const QMetaData slot_tbl[] = {
	{ "slotSetValue(int)", &slot_0, QMetaData::Public },
	{ "slotSetValue(unsigned char)", &slot_1, QMetaData::Public }
    };
    metaObj = QMetaObject::new_metaobject(
	"LedBar", parentObject,
	slot_tbl, 2,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_LedBar.setMetaObject( metaObj );
    return metaObj;
}

void* LedBar::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "LedBar" ) )
	return this;
    return QFrame::qt_cast( clname );
}

bool LedBar::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotSetValue((int)static_QUType_int.get(_o+1)); break;
    case 1: slotSetValue((unsigned char)(*((unsigned char*)static_QUType_ptr.get(_o+1)))); break;
    default:
	return QFrame::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool LedBar::qt_emit( int _id, QUObject* _o )
{
    return QFrame::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool LedBar::qt_property( int id, int f, QVariant* v)
{
    return QFrame::qt_property( id, f, v);
}

bool LedBar::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
