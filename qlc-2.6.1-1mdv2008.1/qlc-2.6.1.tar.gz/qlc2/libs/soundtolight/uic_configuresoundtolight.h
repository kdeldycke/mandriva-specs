/****************************************************************************
** Form interface generated from reading ui file 'configuresoundtolight.ui'
**
** Created: Thu Nov 30 00:53:31 2006
**      by: The User Interface Compiler ($Id: qt/main.cpp   3.3.7   edited Aug 31 2005 $)
**
** WARNING! All changes made in this file will be lost!
****************************************************************************/

#ifndef UI_CONFIGURESOUNDTOLIGHT_H
#define UI_CONFIGURESOUNDTOLIGHT_H

#include <qvariant.h>
#include <qdialog.h>

class QVBoxLayout;
class QHBoxLayout;
class QGridLayout;
class QSpacerItem;
class QGroupBox;
class QLabel;
class QPushButton;
class QLineEdit;

class UI_ConfigureSoundToLight : public QDialog
{
    Q_OBJECT

public:
    UI_ConfigureSoundToLight( QWidget* parent = 0, const char* name = 0, bool modal = FALSE, WFlags fl = 0 );
    ~UI_ConfigureSoundToLight();

    QGroupBox* m_statusGroup;
    QLabel* m_statusLabel;
    QPushButton* m_activate;
    QGroupBox* m_deviceGroup;
    QLineEdit* m_deviceEdit;
    QPushButton* m_ok;
    QPushButton* m_cancel;

public slots:
    virtual void slotActivateClicked();

protected:
    QGridLayout* UI_ConfigureSoundToLightLayout;
    QGridLayout* m_statusGroupLayout;
    QVBoxLayout* m_deviceGroupLayout;
    QHBoxLayout* layout11;
    QSpacerItem* spacer4;

protected slots:
    virtual void languageChange();

};

#endif // UI_CONFIGURESOUNDTOLIGHT_H
