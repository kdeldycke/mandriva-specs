/****************************************************************************
** SoundToLight meta object code from reading C++ file 'soundtolight.h'
**
** Created: Thu Nov 30 00:53:41 2006
**      by: The Qt MOC ($Id: qt/moc_yacc.cpp   3.3.7   edited Oct 19 16:22 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#undef QT_NO_COMPAT
#include "soundtolight.h"
#include <qmetaobject.h>
#include <qapplication.h>

#include <private/qucomextra_p.h>
#if !defined(Q_MOC_OUTPUT_REVISION) || (Q_MOC_OUTPUT_REVISION != 26)
#error "This file was generated using the moc from 3.3.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

const char *SoundToLight::className() const
{
    return "SoundToLight";
}

QMetaObject *SoundToLight::metaObj = 0;
static QMetaObjectCleanUp cleanUp_SoundToLight( "SoundToLight", &SoundToLight::staticMetaObject );

#ifndef QT_NO_TRANSLATION
QString SoundToLight::tr( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SoundToLight", s, c, QApplication::DefaultCodec );
    else
	return QString::fromLatin1( s );
}
#ifndef QT_NO_TRANSLATION_UTF8
QString SoundToLight::trUtf8( const char *s, const char *c )
{
    if ( qApp )
	return qApp->translate( "SoundToLight", s, c, QApplication::UnicodeUTF8 );
    else
	return QString::fromUtf8( s );
}
#endif // QT_NO_TRANSLATION_UTF8

#endif // QT_NO_TRANSLATION

QMetaObject* SoundToLight::staticMetaObject()
{
    if ( metaObj )
	return metaObj;
    QMetaObject* parentObject = InputPlugin::staticMetaObject();
    static const QUParameter param_slot_0[] = {
	{ 0, &static_QUType_int, 0, QUParameter::In }
    };
    static const QUMethod slot_0 = {"slotContextMenuCallback", 1, param_slot_0 };
    static const QMetaData slot_tbl[] = {
	{ "slotContextMenuCallback(int)", &slot_0, QMetaData::Protected }
    };
    metaObj = QMetaObject::new_metaobject(
	"SoundToLight", parentObject,
	slot_tbl, 1,
	0, 0,
#ifndef QT_NO_PROPERTIES
	0, 0,
	0, 0,
#endif // QT_NO_PROPERTIES
	0, 0 );
    cleanUp_SoundToLight.setMetaObject( metaObj );
    return metaObj;
}

void* SoundToLight::qt_cast( const char* clname )
{
    if ( !qstrcmp( clname, "SoundToLight" ) )
	return this;
    return InputPlugin::qt_cast( clname );
}

bool SoundToLight::qt_invoke( int _id, QUObject* _o )
{
    switch ( _id - staticMetaObject()->slotOffset() ) {
    case 0: slotContextMenuCallback((int)static_QUType_int.get(_o+1)); break;
    default:
	return InputPlugin::qt_invoke( _id, _o );
    }
    return TRUE;
}

bool SoundToLight::qt_emit( int _id, QUObject* _o )
{
    return InputPlugin::qt_emit(_id,_o);
}
#ifndef QT_NO_PROPERTIES

bool SoundToLight::qt_property( int id, int f, QVariant* v)
{
    return InputPlugin::qt_property( id, f, v);
}

bool SoundToLight::qt_static_property( QObject* , int , int , QVariant* ){ return FALSE; }
#endif // QT_NO_PROPERTIES
