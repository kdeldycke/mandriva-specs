#!/bin/sh
#
# This little script builds debian packages as specified in
# ./debian/*.install
#

dpkg-buildpackage -rfakeroot -ICVS
