?package(dmg2img):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="dmg2img" command="/usr/bin/dmg2img"
