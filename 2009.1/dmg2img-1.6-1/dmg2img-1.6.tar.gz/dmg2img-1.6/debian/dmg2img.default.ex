# Defaults for dmg2img initscript
# sourced by /etc/init.d/dmg2img
# installed at /etc/default/dmg2img by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
