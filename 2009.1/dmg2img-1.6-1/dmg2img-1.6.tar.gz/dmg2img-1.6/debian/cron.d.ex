#
# Regular cron jobs for the dmg2img package
#
0 4	* * *	root	[ -x /usr/bin/dmg2img_maintenance ] && /usr/bin/dmg2img_maintenance
